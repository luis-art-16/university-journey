import numpy as np
import matplotlib.pyplot as plt

from Transmitter import main as generate_tx
from Channel import combine_cdma_signals
from Receiver import recover_cdma_signals
from BER_Meter import calculate_ber

SNR_START_DB = -20
SNR_END_DB = 20
SNR_STEP_DB = 2
NUM_TRIALS = 1

NUM_TRANSMITTERS = 3
ATTENUATION_COEFFICIENTS = np.array([1.0, 0.8, 0.6])
CODE_INDICES = [i for i in range(NUM_TRANSMITTERS)]
OUTPUT_CSV = 'ber_results.csv'
OUTPUT_PLOT = 'ber_vs_snr.png'

def simulate_ber_vs_snr(snr_values, num_trials):
    tx_data = [
        generate_tx(
            code_index=CODE_INDICES[i],
            in_memory=True,
            output_filename=f"transmitted_cdma_signal_{i+1}.txt"
        ) for i in range(NUM_TRANSMITTERS)
    ]
    ber_records = {snr: [] for snr in snr_values}
    for snr in snr_values:
        print(f"\n=== Simulating for SNR = {snr} dB ===")
        for _ in range(num_trials):
            combined_signal, metadata = combine_cdma_signals(
                attenuation_coeffs=ATTENUATION_COEFFICIENTS,
                snr_db=snr,
                use_in_memory=True,
                transmitter_data_list=tx_data
            )
            recovered = recover_cdma_signals(
                use_in_memory=True,
                combined_signal=combined_signal,
                metadata=metadata
            )
            ber_for_trial = [
                calculate_ber(tx_data[i]['message'], recovered[i])
                for i in range(NUM_TRANSMITTERS)
            ]
            ber_records[snr].append(ber_for_trial)
    avg_ber = { snr: np.mean(np.array(vals), axis=0) for snr, vals in ber_records.items() }
    return avg_ber

def plot_ber_vs_snr(ber_data):
    snr_list = sorted(ber_data.keys())
    for i in range(NUM_TRANSMITTERS):
        plt.semilogy(
            snr_list,
            [ber_data[s][i] for s in snr_list],
            marker='o',
            label=f'Tx{i+1}'
        )
    plt.title('BER vs SNR')
    plt.xlabel('SNR (dB)')
    plt.ylabel('Bit Error Rate (BER)')
    plt.grid(True, which='both', linestyle='--')
    plt.legend()
    plt.tight_layout()
    plt.savefig(OUTPUT_PLOT)
    plt.show()

if __name__ == '__main__':
    snr_vals = np.arange(SNR_START_DB, SNR_END_DB + SNR_STEP_DB, SNR_STEP_DB)
    average_ber = simulate_ber_vs_snr(snr_vals, NUM_TRIALS)
    print("\n--- Average BER Summary ---")
    for snr in sorted(average_ber.keys()):
        print("SNR={:>5.1f} dB  | ".format(snr) +
              "  ".join([f"Tx{i+1}: {average_ber[snr][i]:.6f}" for i in range(NUM_TRANSMITTERS)]))
    with open(OUTPUT_CSV, 'w') as csvfile:
        csvfile.write('SNR,' + ','.join([f'Tx{i+1}_BER' for i in range(NUM_TRANSMITTERS)]) + '\n')
        for snr in sorted(average_ber.keys()):
            bers = ','.join([f"{average_ber[snr][i]:.6f}" for i in range(NUM_TRANSMITTERS)])
            csvfile.write(f"{snr},{bers}\n")
    plot_ber_vs_snr(average_ber)
