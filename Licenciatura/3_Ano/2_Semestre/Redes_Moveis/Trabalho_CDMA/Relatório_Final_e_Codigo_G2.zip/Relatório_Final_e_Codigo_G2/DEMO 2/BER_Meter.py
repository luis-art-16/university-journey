import numpy as np

TRANSMITTER_FILES = [
    'transmitted_cdma_signal_1.txt', 
    'transmitted_cdma_signal_2.txt', 
    'transmitted_cdma_signal_3.txt',
    'transmitted_cdma_signal_4.txt',
    'transmitted_cdma_signal_5.txt',
    'transmitted_cdma_signal_6.txt',
    'transmitted_cdma_signal_7.txt'
]
RECEIVER_FILE = 'recovered_messages.txt'
OUTPUT_FILENAME = 'ber_results.txt'

def calculate_ber(original_message, recovered_message):
    errors = np.sum(original_message != recovered_message)
    total_bits = len(original_message)
    return errors / total_bits

def ber_meter(transmitter_files, receiver_file, output_filename):
    original_messages = []
    for tx_file in transmitter_files:
        with open(tx_file, 'r') as f:
            lines = f.readlines()
            original_messages.append([int(x) for x in lines[1].strip().split(',')])
    with open(receiver_file, 'r') as f:
        recovered_messages = [list(map(int, line.strip().split(','))) for line in f.readlines()]
    ber_results = {}
    for i, (orig_msg, recv_msg) in enumerate(zip(original_messages, recovered_messages), 1):
        ber = calculate_ber(np.array(orig_msg), np.array(recv_msg))
        ber_results[f"Tx{i}"] = ber
    print("\nBER Results:")
    for tx, ber in ber_results.items():
        num_errors = int(ber * len(original_messages[0]))
        total_bits = len(original_messages[0])
        print(f"- {tx}: BER = {ber:.2%} ({num_errors} errors in {total_bits} bits)")
    with open(output_filename, 'w') as f:
        for tx, ber in ber_results.items():
            f.write(f"{tx}: {ber:.6f}\n")
    return ber_results

if __name__ == "__main__":
    ber_meter(TRANSMITTER_FILES, RECEIVER_FILE, OUTPUT_FILENAME)
