import numpy as np

COMBINED_SIGNAL_FILE = 'combined_cdma_signal.txt'
SAMPLING_RATE = 5
RECOVERED_MESSAGES_FILE = 'recovered_messages.txt'

def despread_signal(combined_signal, spreading_code, spreading_factor, sampling_rate):
    segment_length = spreading_factor * sampling_rate
    num_bits = combined_signal.size // segment_length
    reshaped = combined_signal.reshape(num_bits, segment_length)
    sampled_code = np.repeat(spreading_code, sampling_rate)
    return np.sum(reshaped * sampled_code, axis=1)

def recover_bits(correlation_values):
    return (correlation_values > 0).astype(int)

def save_recovered_messages(messages, filename = RECOVERED_MESSAGES_FILE):
    with open(filename, 'w') as f:
        for msg in messages:
            f.write(','.join(map(str, msg.tolist())) + '\n')
    print(f"Recovered messages written to '{filename}'")

def recover_cdma_signals(use_in_memory=False, combined_signal=None, metadata=None):
    if use_in_memory:
        assert combined_signal is not None and metadata is not None, \
            "combined_signal and metadata must be provided in in-memory mode"
        codes = metadata['codes']
        spreading_factors = metadata['spreading_factors']
    else:
        with open(COMBINED_SIGNAL_FILE, 'r') as f:
            lines = f.readlines()
        combined_signal = np.fromstring(lines[0], sep=',')
        codes, spreading_factors = [], []
        idx = 1
        while idx < len(lines):
            code = np.fromstring(lines[idx+1], sep=',', dtype=int)
            factor = int(lines[idx+2].strip())
            codes.append(code)
            spreading_factors.append(factor)
            idx += 3

    recovered = []
    for code, factor in zip(codes, spreading_factors):
        corr = despread_signal(combined_signal, code, factor, SAMPLING_RATE)
        bits = recover_bits(corr)
        recovered.append(bits)

    if not use_in_memory:
        save_recovered_messages(recovered)
        print("Recovered messages:")
        for i, bits in enumerate(recovered, start=1):
            print(f"Transmitter {i}: {bits}")

    return recovered

if __name__ == '__main__':
    recover_cdma_signals(use_in_memory=False)
