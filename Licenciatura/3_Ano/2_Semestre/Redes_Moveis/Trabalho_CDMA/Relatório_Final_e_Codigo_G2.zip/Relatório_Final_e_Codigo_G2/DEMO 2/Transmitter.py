import numpy as np
import sys

def generate_message(length):
    return np.random.randint(0, 2, length)

def generate_walsh_matrix(n):
    if n == 1:
        return np.array([[1]])
    else:
        H = generate_walsh_matrix(n // 2)
        top = np.hstack((H, H))
        bottom = np.hstack((H, -H))
        return np.vstack((top, bottom))

def generate_spreading_code(order, index):
    walsh_matrix = generate_walsh_matrix(order)
    return walsh_matrix[index]

def spread_signal(message, spreading_code):
    mapped_message = message * 2 - 1
    return np.kron(mapped_message, spreading_code)

def apply_sampling_rate(signal, sampling_rate):
    return np.repeat(signal, sampling_rate)

def save_to_file(filename, cdma_signal, message, spreading_code, spreading_factor):
    with open(filename, 'w') as file:
        file.write(','.join(map(str, cdma_signal)) + '\n')
        file.write(','.join(map(str, message)) + '\n')
        file.write(','.join(map(str, spreading_code)) + '\n')
        file.write(str(spreading_factor) + '\n')

def main(
    code_index=0,
    output_filename="transmitted_cdma_signal.txt",
    message_length=10064,
    walsh_order=16,
    spreading_factor=16,
    sampling_rate=5,
    in_memory=False
):
    message = generate_message(message_length)
    spreading_code = generate_spreading_code(walsh_order, code_index)
    cdma_signal = spread_signal(message, spreading_code)
    sampled_signal = apply_sampling_rate(cdma_signal, sampling_rate)
    
    if in_memory:
        return {
            'signal': sampled_signal,
            'message': message,
            'code': spreading_code,
            'spreading_factor': spreading_factor
        }
    else:
        save_to_file(output_filename, sampled_signal, message, spreading_code, spreading_factor)

if __name__ == "__main__":
    if len(sys.argv) == 3:
        # Modo individual
        code_index = int(sys.argv[1])
        output_filename = sys.argv[2]
        main(code_index=code_index, output_filename=output_filename)
        print(f"Transmissor {code_index+1} criado em {output_filename}")
    else:
        # Modo batch: gerar todos!
        NUM_TRANSMITTERS = 7
        print("A gerar todos os transmissores...")
        for idx in range(NUM_TRANSMITTERS):
            out = f"transmitted_cdma_signal_{idx+1}.txt"
            main(code_index=idx, output_filename=out)
            print(f"Transmissor {idx+1} criado em {out}")
        print("Todos os transmissores foram gerados!")
