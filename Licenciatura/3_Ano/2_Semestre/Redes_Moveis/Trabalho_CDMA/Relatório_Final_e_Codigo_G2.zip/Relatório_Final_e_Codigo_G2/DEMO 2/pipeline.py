# pipeline.py
import os
os.system("python Transmitter.py")
os.system("python Channel.py")
os.system("python Receiver.py")
os.system("python BER_Meter.py")