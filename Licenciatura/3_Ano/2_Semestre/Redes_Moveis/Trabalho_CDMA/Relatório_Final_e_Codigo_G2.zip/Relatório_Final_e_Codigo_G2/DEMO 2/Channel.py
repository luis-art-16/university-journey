import numpy as np  # Numerical operations

ATTENUATION_COEFFICIENTS = np.array([1.0, 0.9, 0.8, 0.6, 0.4, 0.3, 0.8])
TRANSMITTER_SIGNAL_FILES = [
    'transmitted_cdma_signal_1.txt',
    'transmitted_cdma_signal_2.txt',
    'transmitted_cdma_signal_3.txt',
    'transmitted_cdma_signal_4.txt',
    'transmitted_cdma_signal_5.txt',
    'transmitted_cdma_signal_6.txt',
    'transmitted_cdma_signal_7.txt'
]
SNR_DB_FILE_MODE = -10
COMBINED_SIGNAL_FILE = 'combined_cdma_signal.txt'

def compute_signal_power(signal):
    return np.mean(signal ** 2)

def add_awgn_noise(signal, snr_db):
    power = compute_signal_power(signal)
    snr_linear = 10 ** (snr_db / 10)
    noise_power = power / snr_linear
    noise_std_dev = np.sqrt(noise_power)
    noise = np.random.normal(0, noise_std_dev, size=signal.shape)
    return signal + noise, noise_std_dev

def combine_cdma_signals(attenuation_coeffs, snr_db, use_in_memory=False, signal_file_list=None, transmitter_data_list=None):
    if use_in_memory:
        assert transmitter_data_list is not None, "transmitter_data_list required for in-memory mode"
        signals = [entry['signal'] for entry in transmitter_data_list]
        messages = [entry['message'] for entry in transmitter_data_list]
        codes = [entry['code'] for entry in transmitter_data_list]
        spreading_factors = [entry['spreading_factor'] for entry in transmitter_data_list]
    else:
        assert signal_file_list is not None, "signal_file_list required for file-based mode"
        signals, messages, codes, spreading_factors = [], [], [], []
        for file_path in signal_file_list:
            with open(file_path, 'r') as file_handle:
                lines = file_handle.readlines()
                signals.append(np.fromstring(lines[0], sep=','))
                messages.append(list(map(int, lines[1].split(','))))
                codes.append(list(map(int, lines[2].split(','))))
                spreading_factors.append(int(lines[3].strip()))

    max_signal_length = max(signal.size for signal in signals)
    composite_signal = np.zeros(max_signal_length)
    for sig, coeff in zip(signals, attenuation_coeffs):
        padded = np.pad(sig, (0, max_signal_length - sig.size), 'constant')
        composite_signal += coeff * padded

    noisy_composite, noise_std = add_awgn_noise(composite_signal, snr_db)

    if not use_in_memory:
        with open(COMBINED_SIGNAL_FILE, 'w') as out_file:
            out_file.write(','.join(map(str, noisy_composite)) + '\n')
            for msg, code, sf in zip(messages, codes, spreading_factors):
                out_file.write(','.join(map(str, msg)) + '\n')
                out_file.write(','.join(map(str, code)) + '\n')
                out_file.write(str(sf) + '\n')
        print(
            f"Combined CDMA signal written to '{COMBINED_SIGNAL_FILE}' "
            f"with SNR={snr_db} dB (noise_std={noise_std:.4f})"
        )

    metadata = {
        'messages': messages,
        'codes': codes,
        'spreading_factors': spreading_factors
    }
    return noisy_composite, metadata

if __name__ == '__main__':
    combine_cdma_signals(
        attenuation_coeffs=ATTENUATION_COEFFICIENTS,
        snr_db=SNR_DB_FILE_MODE,
        use_in_memory=False,
        signal_file_list=TRANSMITTER_SIGNAL_FILES
    )
