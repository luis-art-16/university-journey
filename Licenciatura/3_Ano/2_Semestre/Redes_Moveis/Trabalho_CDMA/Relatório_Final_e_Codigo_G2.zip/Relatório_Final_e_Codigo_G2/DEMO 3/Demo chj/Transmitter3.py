# ============================
# PARAMETERS & CONFIGURATION
# ============================

import numpy as np

# Transmission Parameters
MESSAGE_LENGTH = 10064      # Total bits (including sync preamble)
WALSH_ORDER = 16               # Walsh matrix order (power of 2)
CODE_INDEX = 3                 # Spreading code index (0 for Tx1)
SPREADING_FACTOR = 16          # Chips per bit  
SAMPLING_RATE = 5              # Samples per chip
LEADING_ZEROS = 50

# Synchronization Configuration
SYNC_PATTERN = np.tile([1,0,1,0,1,1,0,0], 8)  # 64-bit alternating pattern
SYNC_PREAMBLE_LENGTH = len(SYNC_PATTERN)       # Derive length from pattern

# Output Configuration
OUTPUT_FILENAME = 'transmitted_cdma_signal_3.txt'

# ============================
# FUNCTION DEFINITIONS
# ============================

def generate_message(length):
    """
    Generates message with built-in sync preamble.
    Structure: [SYNC_PATTERN | random payload]
    """
    payload = np.random.randint(0, 2, length - SYNC_PREAMBLE_LENGTH)
    return np.concatenate([SYNC_PATTERN, payload])

def generate_walsh_matrix(n):
    """Recursively generates n x n Walsh-Hadamard matrix"""
    if n == 1:
        return np.array([[1]])
    H = generate_walsh_matrix(n//2)
    return np.block([[H, H], [H, -H]])

def generate_spreading_code(order, index):
    """
    Generate an orthogonal spreading code by selecting one row of the Walsh matrix.
    
    Parameters:
        order (int): The order of the Walsh matrix (must be a power of 2).
        index (int): The row index to select as the spreading code.
    
    Returns:
        numpy array: The selected spreading code (a row from the Walsh matrix).
    """
    walsh_matrix = generate_walsh_matrix(order)
    return walsh_matrix[index]

def spread_signal(message, spreading_code):
    """
    Spread the message using the provided orthogonal spreading code.
    Adds leading zeros to simulate unknown start point.
    
    The message bits (0,1) are mapped to (-1,1) and then spread by taking 
    the Kronecker product with the spreading code.
    """
    # Map bits: 0 -> -1, 1 -> 1
    mapped_message = message * 2 - 1
    cdma_signal = np.kron(mapped_message, spreading_code)
    zeros = np.zeros(LEADING_ZEROS)  # Note: single parentheses for np.zeros
    return np.concatenate([zeros, cdma_signal])  # Note: needs to be a list/tuple of arrays


def apply_sampling_rate(signal, sampling_rate):
    """Upsamples by repeating each value sampling_rate times"""
    return np.repeat(signal, sampling_rate)

def save_to_file(filename, cdma_signal, message, spreading_code, spreading_factor):
    """
    Saves signal and metadata in 4-line format:
    1. Sampled CDMA signal
    2. Message bits (sync + payload)
    3. Spreading code
    4. Spreading factor
    """
    with open(filename, 'w') as f:
        np.savetxt(f, [cdma_signal], delimiter=',', fmt='%d')
        np.savetxt(f, [message], delimiter=',', fmt='%d')
        np.savetxt(f, [spreading_code], delimiter=',', fmt='%d')
        f.write(f"{spreading_factor}\n")

# ============================
# MAIN EXECUTION
# ============================

def main(in_memory=False):
    """Generates and outputs CDMA signal with built-in sync"""
    message = generate_message(MESSAGE_LENGTH)
    spreading_code = generate_spreading_code(WALSH_ORDER, CODE_INDEX)
    cdma_signal = spread_signal(message, spreading_code)
    sampled_signal = apply_sampling_rate(cdma_signal, SAMPLING_RATE)
    
    if in_memory:
        return {
            'signal': sampled_signal,
            'message': message,
            'code': spreading_code,
            'spreading_factor': SPREADING_FACTOR
            # Sync pattern is implied in message
        }
    else:
        save_to_file(OUTPUT_FILENAME, sampled_signal, message, 
                   spreading_code, SPREADING_FACTOR)

if __name__ == "__main__":
    main()