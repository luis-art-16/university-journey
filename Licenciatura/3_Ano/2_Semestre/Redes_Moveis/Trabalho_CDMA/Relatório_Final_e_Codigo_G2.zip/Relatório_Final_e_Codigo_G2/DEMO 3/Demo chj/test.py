from Transmitter1 import generate_walsh_matrix
import numpy as np
walsh = generate_walsh_matrix(16)  # Your WALSH_ORDER

# Check orthogonality between Tx1 (row 0), Tx2 (row 1), Tx3 (row 2)
print("Tx1 vs Tx2:", np.dot(walsh[0], walsh[1]))  # Should be 0
print("Tx1 vs Tx3:", np.dot(walsh[0], walsh[2]))  # Should be 0
print("Tx2 vs Tx3:", np.dot(walsh[1], walsh[2]))  # Should be 0