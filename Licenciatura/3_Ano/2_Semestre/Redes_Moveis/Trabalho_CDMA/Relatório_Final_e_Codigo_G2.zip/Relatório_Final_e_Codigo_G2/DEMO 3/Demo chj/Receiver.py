# Receiver.py

import numpy as np

# Parâmetros de ficheiro e de amostragem
COMBINED_SIGNAL_FILE      = 'combined_cdma_signal.txt'
RECOVERED_MESSAGES_FILE   = 'recovered_messages.txt'
SAMPLING_RATE             = 5

# Padrão de sincronização (preâmbulo) – 64 bits
SYNC_PATTERN              = np.tile([1, 0, 1, 0, 1, 1, 0, 0], 8)
SYNC_PREAMBLE_LENGTH      = len(SYNC_PATTERN)
SYNC_CORR_THRESHOLD       = 0.5


def detect_sync(signal, spreading_code, sampling_rate):
    """
    Detecta a posição do padrão de sincronização num sinal CDMA recebido,
    usando correlação direta em domínio do tempo com early exit.

    Retorna:
        peak_position (int): índice onde o padrão começa no vetor de amostras
        peak_value (float): valor normalizado da correlação no pico
    """
    # 1) Converter preâmbulo para bipolar e gerar template amostrado
    bipolar_sync = SYNC_PATTERN * 2 - 1
    spread_sync  = np.kron(bipolar_sync, spreading_code)
    template      = np.repeat(spread_sync, sampling_rate)
    N             = len(template)
    # Energia do template para normalização (valores ±1 → energia = N)
    norm_factor   = float(N)

    # 2) Percorrer o sinal e calcular correlação ponto a ponto com early exit
    max_index = len(signal) - N + 1
    for k in range(max_index):
        segment = signal[k:k+N]
        corr_val = np.dot(segment, template) / norm_factor
        if abs(corr_val) >= SYNC_CORR_THRESHOLD:
            return k, corr_val

    # Se não encontrou nenhum pico acima do limiar
    raise ValueError("Sincronização não detectada (correlação fraca)")


def despread_signal(combined_signal, spreading_code, spreading_factor, sampling_rate):
    # Detectar sync e obter valor da correlação
    sync_pos, sync_corr_val = detect_sync(combined_signal, spreading_code, sampling_rate)
    
    # Determinar polaridade (1 = normal, -1 = invertido)
    polarity = 1 if sync_corr_val >= 0 else -1
    
    payload_start = sync_pos + SYNC_PREAMBLE_LENGTH * spreading_factor * sampling_rate
    payload_signal = combined_signal[payload_start:] * polarity  # Aplica correção de polaridade

    # 3) Determina quantos bits completos temos no payload
    segment_len = spreading_factor * sampling_rate
    num_bits    = len(payload_signal) // segment_len

    # 4) Reorganiza em matriz [num_bits x segment_len]
    reshaped = payload_signal[:num_bits * segment_len].reshape(num_bits, segment_len)

    # 5) Cria código amostrado (cada chip repetido sampling_rate vezes)
    sampled_code = np.repeat(spreading_code, sampling_rate)

    # 6) Correla cada linha (bit) com o sampled_code — soma produto interno
    correlation_values = np.sum(reshaped * sampled_code, axis=1)
    return correlation_values


def recover_bits(correlation_values):
    """Converte valores de correlação para bits (1 se >0, senão 0)."""
    return (correlation_values > 0).astype(int)


def save_recovered_messages(messages, filename=RECOVERED_MESSAGES_FILE):
    """Grava cada vetor de bits recuperado num ficheiro de texto."""
    with open(filename, 'w') as f:
        for msg in messages:
            line = ','.join(map(str, msg.tolist()))
            f.write(line + '\n')
    print(f"Mensagens recuperadas guardadas em '{filename}'")


def recover_cdma_signals(use_in_memory=False, combined_signal=None, metadata=None):
    """Função principal de receção CDMA."""
    # 1) Obter códigos e fatores
    if use_in_memory:
        codes = metadata['codes']
        spreading_factors = metadata['spreading_factors']
    else:
        with open(COMBINED_SIGNAL_FILE, 'r') as f:
            lines = f.readlines()
        combined_signal = np.fromstring(lines[0], sep=',')
        codes, spreading_factors = [], []
        idx = 1
        while idx < len(lines):
            code_line   = np.fromstring(lines[idx+1], sep=',', dtype=int)
            factor_line = int(lines[idx+2].strip())
            codes.append(code_line)
            spreading_factors.append(factor_line)
            idx += 3

    # 2) Desespalhar e recuperar bits para cada transmissor
    recovered = []
    for code, factor in zip(codes, spreading_factors):
        corr_vals = despread_signal(combined_signal, code, factor, SAMPLING_RATE)
        bits      = recover_bits(corr_vals)
        recovered.append(bits)

    # 3) Guardar e visualizar resultados se for do ficheiro
    if not use_in_memory:
        save_recovered_messages(recovered)
        print("\nVisualização inicial das mensagens recuperadas:")
        for i, bits in enumerate(recovered, start=1):
            print(f"Transmissor {i}: {bits[:16]}...")

    return recovered


if __name__ == '__main__':
    recover_cdma_signals(use_in_memory=False)
