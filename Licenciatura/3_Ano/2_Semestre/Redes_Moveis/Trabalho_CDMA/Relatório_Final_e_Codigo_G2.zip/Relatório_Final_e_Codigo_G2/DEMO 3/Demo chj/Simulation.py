"""
Motor de simulação para avaliar o desempenho de um sistema CDMA com um único transmissor.
O objetivo principal do script é calcular a taxa de erro de bits (BER - Bit Error Rate) em função da relação sinal-ruído (SNR - Signal-to-Noise Ratio), e visualizar os resultados."""



# ============================
# PARAMETERS & CONFIGURATION
# ============================

import numpy as np
import matplotlib.pyplot as plt

# Importa funções de outros scripts (módulos do sistema CDMA)

from Transmitter1 import main as generate_tx1 # Gera sinal do transmissor 1 com mensagem e código.
from Channel import combine_cdma_signals # Simula o canal com ruído e mistura os sinais.
from Receiver import recover_cdma_signals # plica técnicas de desespalhamento e sincronização para recuperar a mensagem.
from BER_Meter import calculate_ber # Compara mensagem original com a recuperada para calcular erros.

 #Configurações da simulação (SRN variado entre -20 e 20 dB)
SNR_START_DB = -20    # SNR mínimo (muito ruidoso)
SNR_END_DB = 20       # SNR máximo (sinal claro)
SNR_STEP_DB = 2       # Passo entre valores de SNR
NUM_TRIALS = 1        # Número de simulações por ponto de SNR
ATTENUATION = 1       # Atenuação (ganho fixo do canal)

# Ficheiros de saída
OUTPUT_CSV = 'ber_results_single.csv'
OUTPUT_PLOT = 'ber_vs_snr_single.png'

# ============================
# SIMULATION FUNCTION (SIMPLIFIED)
# ============================

# Simulation.py

def simulate_ber_vs_snr(snr_values, num_trials):
    tx_data = generate_tx1(in_memory=True)
    
    ber_records = {snr: [] for snr in snr_values}

    for snr in snr_values:
        for _ in range(num_trials):
            # Capturar ambos: sinal combinado E metadados
            combined, metadata = combine_cdma_signals(
                attenuation_coeffs=[ATTENUATION],
                snr_db=snr,
                use_in_memory=True,
                transmitter_data_list=[tx_data]
            )
            
            # Passar metadados para o receptor
            recovered = recover_cdma_signals(
                use_in_memory=True,
                combined_signal=combined,
                metadata=metadata  # Agora temos metadata definido
            )
            
            ber = calculate_ber(tx_data['message'], recovered[0])
            ber_records[snr].append(ber)
    
    return {snr: np.mean(vals) for snr, vals in ber_records.items()}

# ============================
# PLOTTING FUNCTION (SIMPLIFIED)
# ============================

# Gera gráfico da BER em função do SNR.

def plot_ber_vs_snr(ber_data):
    """Plot single BER curve."""
    snr = sorted(ber_data.keys())
    ber = [ber_data[s] for s in snr]

    plt.figure(figsize=(8, 5))
    plt.semilogy(snr, ber, marker='o', label='Tx1') # Eixo Y logarítmico
    plt.title('BER vs SNR (Single Transmitter)')
    plt.xlabel('SNR (dB)')
    plt.ylabel('Bit Error Rate (BER)')
    plt.grid(True, which='both', linestyle='--')
    plt.legend()
    plt.tight_layout()
    plt.savefig(OUTPUT_PLOT)
    plt.show()

# ============================
# MAIN EXECUTION
# ============================

if __name__ == '__main__':
    snr_vals = np.arange(SNR_START_DB, SNR_END_DB + SNR_STEP_DB, SNR_STEP_DB)
    average_ber = simulate_ber_vs_snr(snr_vals, NUM_TRIALS)

    # Imprime resultados no terminal
    print("\n--- BER Results ---")
    for snr, ber in sorted(average_ber.items()):
        print(f"SNR={snr:>5.1f} dB  |  BER: {ber:.6f}")

    # Guarda CSV com os resultados
    with open(OUTPUT_CSV, 'w') as f:
        f.write("SNR,BER\n")
        for snr, ber in sorted(average_ber.items()):
            f.write(f"{snr},{ber:.6f}\n")

    # Gera gráfico
    plot_ber_vs_snr(average_ber)
    
"""
Cria vetor de SNRs (np.arange).

Chama a simulação para todos os SNRs.

Mostra e salva os resultados:

.csv: para análise futura em Excel ou MATLAB, por exemplo.

.png: visualização da curva BER vs SNR.

Resumo:

Simula transmissão, canal e receção CDMA com ruído aditivo.

Avalia o desempenho do sistema ao medir BER para diferentes níveis de ruído.

Gera resultados gráficos e numéricos para análise.

"""