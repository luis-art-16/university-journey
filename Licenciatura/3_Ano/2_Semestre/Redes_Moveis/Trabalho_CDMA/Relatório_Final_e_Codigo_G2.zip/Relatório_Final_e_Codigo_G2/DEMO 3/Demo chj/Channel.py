# Channel.py
# ============================
# Combinação de múltiplos sinais CDMA e adição de ruído AWGN
# ============================

import numpy as np
import numpy as np
import os

# --- Parâmetros & Configuração de Ficheiros ---
ATTENUATION_COEFFICIENTS = np.array([0.9])      # Coeficientes de atenuação por transmissor - simula perdas ou ganhos diferentes de cada transmissor.
TRANSMITTER_SIGNAL_FILES = ['transmitted_cdma_signal_1.txt']  # Ficheiros de cada TX 

# usados quando não se trabalha em memória.
SNR_DB_FILE_MODE = 20                        # SNR em dB para modo ficheiro
COMBINED_SIGNAL_FILE = 'combined_cdma_signal.txt'  # Ficheiro onde se grava o sinal combinado

# --- Funções Utilitárias ---

def compute_signal_power(signal):
    """
    Calcula a potência média de um sinal.
    Power = E[signal^2]
    """
    return np.mean(signal ** 2) # Retorna a média dos quadrados das amostra

def add_awgn_noise(signal, snr_db):
    """
    Adiciona ruído AWGN (Gaussian White Noise) para atingir o SNR desejado.

    Args:
        signal (np.ndarray): sinal sem ruído
        snr_db (float): relação sinal-ruído desejada em decibéis

    Retorna:
        noisy_signal (np.ndarray): sinal com ruído adicionado
        noise_std_dev (float): desvio-padrão do ruído gerado
    """
    # 1) Potência do sinal
    power = compute_signal_power(signal)
    # 2) Converte SNR dB → linear
    snr_linear = 10 ** (snr_db / 10)
    # 3) Potência do ruído requerida
    noise_power = power / snr_linear
    noise_std_dev = np.sqrt(noise_power)
    # 4) Gera ruído Gaussiano
    noise = np.random.normal(0, noise_std_dev, size=signal.shape)
    # 5) Retorna sinal ruidoso e desvio-padrão do ruído
    return signal + noise, noise_std_dev

# A relação potência_ruído = potência_sinal / SNR_linear garante que, ao somar o ruído gerado, 
# a nova SNR seja exatamente a desejada.

# --- Função Principal: combine_cdma_signals ---

def combine_cdma_signals(attenuation_coeffs, snr_db, use_in_memory=False, transmitter_data_list=None, signal_file_list = None):
    """Combina sinais CDMA e adiciona ruído AWGN."""
    if use_in_memory:
        # Verificar se temos dados de transmissor
        if not transmitter_data_list:
            raise ValueError("transmitter_data_list é necessário para modo in-memory")
        
        # Inicializar o sinal combinado
        max_length = max(len(tx['modulated_signal']) for tx in transmitter_data_list)
        combined_signal = np.zeros(max_length)
        
        # Listas para metadados
        codes = []
        spreading_factors = []
        
        # Combinar sinais com atenuações
        for i, tx_data in enumerate(transmitter_data_list):
            # Obter parâmetros de atenuação
            atten = attenuation_coeffs[i] if i < len(attenuation_coeffs) else 1.0
            
            # Obter sinal e aplicar atenuação
            signal = tx_data['modulated_signal']
            padded_signal = np.pad(signal, (0, max_length - len(signal)))
            combined_signal += atten * padded_signal
            
            # Armazenar metadados
            codes.append(tx_data['spreading_code'])
            spreading_factors.append(tx_data['spreading_factor'])
        
        # Adicionar ruído AWGN
        noise_power = 10 ** (-snr_db / 10)
        noise = np.sqrt(noise_power) * np.random.randn(len(combined_signal))
        combined_signal += noise
        
        # Preparar metadados para retorno
        metadata = {
            'codes': codes,
            'spreading_factors': spreading_factors
        }
        
        return combined_signal, metadata
    else:
        # modo ficheiro: lê cada ficheiro de transmissor
        assert signal_file_list is not None, "signal_file_list é obrigatório no modo ficheiro"
        signals, messages, codes, spreading_factors = [], [], [], []
        for path in signal_file_list:
            with open(path, 'r') as f:
                lines = f.readlines()
            # Linha 0: sinal amostrado
            sig = np.fromstring(lines[0], sep=',')
            # Linha 1: mensagem bits originais
            msg = list(map(int, lines[1].split(',')))
            # Linha 2: código de espalhamento
            code = list(map(int, lines[2].split(',')))
            # Linha 3: fator de espalhamento
            sf = int(lines[3].strip())
            signals.append(sig)
            messages.append(msg)
            codes.append(code)
            spreading_factors.append(sf)

    # 2) Descobrir comprimento máximo para alinhamento por padding
    max_len = max(sig.size for sig in signals)

    # 3) Aplicar atenuação e somar sinais
    composite = np.zeros(max_len)
    for sig, coeff in zip(signals, attenuation_coeffs):
        # Preenche com zeros até max_len
        padded = np.pad(sig, (0, max_len - sig.size), 'constant')
        composite += coeff * padded

    # 4) Adicionar ruído AWGN para atingir SNR desejado
    noisy_composite, noise_std = add_awgn_noise(composite, snr_db)

    # 5) Grava em ficheiro se for o modo ficheiro
    if not use_in_memory:
        with open(COMBINED_SIGNAL_FILE, 'w') as out:
            # Linha 1: sinal combinado + ruído
            out.write(','.join(map(str, noisy_composite)) + '\n')
            # Para cada transmissor: mensagem, código, fator
            for msg, code, sf in zip(messages, codes, spreading_factors):
                out.write(','.join(map(str, msg)) + '\n')
                out.write(','.join(map(str, code)) + '\n')
                out.write(str(sf) + '\n')
        print(
            f"Sinal combinado guardado em '{COMBINED_SIGNAL_FILE}' "
            f"com SNR={snr_db} dB (noise_std={noise_std:.4f})"
        )

    # 6) Prepara metadados de saída
    metadata = {
        'messages': messages,
        'codes': codes,
        'spreading_factors': spreading_factors
    }
    return noisy_composite, metadata

# --- Executável como script independente ---

if __name__ == '__main__':
    # Exemplo de uso em memória
    from Transmitter1 import main as generate_tx1
    from Transmitter2 import main as generate_tx2
    
    tx1_data = generate_tx1(in_memory=True)
    tx2_data = generate_tx2(in_memory=True)
    
    combined, metadata = combine_cdma_signals(
        attenuation_coeffs=[1.0, 0.5],
        snr_db=10,
        use_in_memory=True,
        transmitter_data_list=[tx1_data, tx2_data]
    )
    
    print("Sinal combinado criado com sucesso!")
    print(f"Comprimento: {len(combined)} amostras")
