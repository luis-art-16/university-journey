# BER_Meter.py
# ============================
# Cálculo da Bit Error Rate (BER) para sinais CDMA
# ============================

import numpy as np

# --- Parâmetros de Sincronização (idem transmissor) ---
SYNC_PATTERN = np.tile([1, 0, 1, 0, 1, 1, 0, 0], 8)  # 64 bits, devem coincidir exatamente com o transmissor para remover corretamente os bits de pré‑ambulo.
SYNC_PREAMBLE_LENGTH = len(SYNC_PATTERN)            # 64

# --- Ficheiros de Entrada/Saída ---
TRANSMITTER_FILES = ['transmitted_cdma_signal_1.txt']  # Ficheiros TX, contém, por cada transmissor, o ficheiro com sinal+mensagem original.
RECEIVER_FILE = 'recovered_messages.txt'               # Mensagens RX , em as mensagens recuperadas no receptor (payload sem sync).


OUTPUT_FILENAME = 'ber_results.txt'   #onde se grava a taxa de erro de bits.                # Resultados BER

# --- Função de Cálculo de BER ---

def calculate_ber(original, recovered):
    """
    Calcula o BER comparando a parte útil (payload) da mensagem original
    e a recuperada.
    
     Args:
      original (np.ndarray): vetor de bits original (inclui sync + payload)
      recovered (np.ndarray): vetor de bits recuperados (apenas payload)

    Passos:
      1) Remove os SYNC bits da mensagem original.
      2) Conta diferenças entre original_payload e recovered.
      3) Se faltarem bits em recovered, contam-se como erros.
      4) Divide total de erros pelo comprimento do payload original.
    
    """
    # Remove bits de preâmbulo (sync)
    original_payload = original[SYNC_PREAMBLE_LENGTH:]
    expected_length = len(original_payload)

    # Conta erros onde bits diferem
    min_len = min(len(original_payload), len(recovered))
    errors = np.sum(original_payload[:min_len] != recovered[:min_len])
    # Bits faltantes contam como erros
    missing_bits = expected_length - len(recovered)
    total_errors = errors + missing_bits

    # BER = erros / tamanho do payload
    return total_errors / expected_length


    # Quando o receptor recupera menos bits do que foram transmitidos, esses bits “em falta” são considerados erros, 
    # penalizando o BER.

# --- Função Principal de Medição de BER ---

def ber_meter(transmitter_files, receiver_file, output_filename):
    """
    Para cada transmissor:
      1. Lê mensagem original (inclui sync + payload).
      2. Lê mensagem recuperada (apenas payload).
      3. Calcula BER (exclui sync).
      4. Mostra e grava resultados.
    """
    # 1) Carrega mensagens originais dos ficheiros TX
    original_messages = []
    for tx_file in transmitter_files:
        with open(tx_file, 'r') as f:
            lines = f.readlines()
            # Linha 1 do ficheiro: bits da mensagem original
            bits = list(map(int, lines[1].strip().split(',')))
            original_messages.append(np.array(bits))

    # 2) Carrega as mensagens recuperadas pelo receptor (cada linha = payload de um TX)
    with open(receiver_file, 'r') as f:
        recovered_messages = [
            np.array(list(map(int, line.strip().split(','))))
            for line in f
        ]

    # 3) Calcula BER para cada fluxo TX → RX (original vs recuperado)
    ber_results = {}
    for i, (orig, recv) in enumerate(zip(original_messages, recovered_messages), start=1):
        try:
            ber = calculate_ber(orig, recv)
            ber_results[f"Tx{i}"] = ber
            print(f"Tx{i}: BER = {ber:.2%} (excluindo sync)")
        except Exception as e:
            print(f"Tx{i}: Erro no cálculo de BER – {e}")
            ber_results[f"Tx{i}"] = float('nan')

    # 4) Grava resultados finais num ficheiro de texto
    with open(output_filename, 'w') as f:
        for tx, ber in ber_results.items():
            f.write(f"{tx}: {ber:.6f}\n")

    return ber_results

# --- Execução como script independente ---

if __name__ == "__main__":
    ber_meter(TRANSMITTER_FILES, RECEIVER_FILE, OUTPUT_FILENAME)
