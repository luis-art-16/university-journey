# Simula a transmissão de um sinal CDMA (Code Division Multiple Access), 
# utilizando espalhamento de espectro com códigos ortogonais (códigos de Walsh)

# ============================
# PARAMETERS & CONFIGURATION
# ============================

import numpy as np

# Parâmetros de transmissão
MESSAGE_LENGTH = 10064         # Comprimento total da mensagem em bits (inclui preâmbulo de sincronização)
WALSH_ORDER = 16               # Ordem da matriz de Walsh (deve ser potência de 2)
CODE_INDEX = 1                 # Índice da linha da matriz de Walsh usada como código de espalhamento
SPREADING_FACTOR = 16          # Fator de espalhamento: quantos "chips" por bit  
SAMPLING_RATE = 5              # Número de amostras por chip
ZEROS_LENGTH = 50              # Zeros no início do sinal para simular início desconhecido

# Configuração de sincronização
SYNC_PATTERN = np.tile([1,0,1,0,1,1,0,0], 8)  # Padrão de sincronização (64 bits)
SYNC_PREAMBLE_LENGTH = len(SYNC_PATTERN)      # Comprimento do preâmbulo derivado automaticamente

# Configuração do output
OUTPUT_FILENAME = 'transmitted_cdma_signal_1.txt' # Nome do ficheiro de saída

# ============================
# FUNCTION DEFINITIONS
# ============================

def generate_message(length):
    
    # Gera a mensagem com preâmbulo de sincronização.
    # Estrutura: [SYNC_PATTERN | payload aleatório]
    
    payload = np.random.randint(0, 2, length - SYNC_PREAMBLE_LENGTH)
    return np.concatenate([SYNC_PATTERN, payload])

def generate_walsh_matrix(n):
   # Gera recursivamente a matriz de Walsh-Hadamard n x n
    if n == 1:
        return np.array([[1]])
    H = generate_walsh_matrix(n//2)
    return np.block([[H, H], [H, -H]])

def generate_spreading_code(order, index):
    
    #Seleciona uma linha da matriz de Walsh como código de espalhamento.
   
    walsh_matrix = generate_walsh_matrix(order)
    return walsh_matrix[index] 
   
    # Retorna uma linha específica da matriz de Walsh.
    # Cada utilizador no sistema CDMA pode usar uma linha diferente
    
def spread_signal(message, spreading_code):
    """
    Aplica o código de espalhamento à mensagem:
    - Mapeia bits 0 → -1, 1 → +1
    - Usa produto de Kronecker para espalhar
    - Adiciona zeros no início para simular incerteza temporal
    """
    mapped_message = message * 2 - 1 # 0 → -1, 1 → +1
    cdma_signal = np.kron(mapped_message, spreading_code) # Espalhamento , np.kron repete o código de espalhamento inteiro para cada bit.
    zeros = np.zeros(ZEROS_LENGTH)   # Zeros iniciais
    return np.concatenate([zeros, cdma_signal])  


def apply_sampling_rate(signal, sampling_rate):
    # Repete cada valor do sinal para simular taxa de amostragem mais alta
    # Aumenta a resolução do sinal no tempo.
    return np.repeat(signal, sampling_rate)

def save_to_file(filename, cdma_signal, message, spreading_code, spreading_factor):
    """
    Salva o sinal e metadados num ficheiro com 4 linhas:
    1. Sinal CDMA amostrado
    2. Mensagem (bits)
    3. Código de espalhamento
    4. Fator de espalhamento
    """
    with open(filename, 'w') as f:
        np.savetxt(f, [cdma_signal], delimiter=',', fmt='%d')
        np.savetxt(f, [message], delimiter=',', fmt='%d')
        np.savetxt(f, [spreading_code], delimiter=',', fmt='%d')
        f.write(f"{spreading_factor}\n")

# ============================
# MAIN EXECUTION
# ============================

def main(in_memory=False):
    #Gera o sinal CDMA completo com sincronização embutida
    
    message = generate_message(MESSAGE_LENGTH)
    # Certifique-se que está usando inteiros (não floats)
    spreading_code = np.random.choice([1, -1], size=SPREADING_FACTOR).astype(int)
    cdma_signal = spread_signal(message, spreading_code)
    sampled_signal = apply_sampling_rate(cdma_signal, SAMPLING_RATE)
    
    if in_memory:
        return {
            'signal': sampled_signal,
            'message': message,
            'code': spreading_code,
            'spreading_factor': SPREADING_FACTOR
            # Sync pattern is implied in message
        }
    else:
        save_to_file(OUTPUT_FILENAME, sampled_signal, message, 
                   spreading_code, SPREADING_FACTOR)

if __name__ == "__main__":
    main()
    
# Se for chamado com in_memory=True, retorna tudo como dicionário
# Caso contrário, escreve os dados no ficheiro de saída.

""" 
Resumo:

  - Cria uma mensagem digital com preâmbulo de sincronização.

  - Usa códigos ortogonais de Walsh para espalhamento espectral (CDMA).

  - Aplica espalhamento (spread spectrum) usando produto de Kronecker.

  - Simula amostragem temporal mais densa.

  - Adiciona zeros para simular início desconhecido.

  - Permite salvar os dados para serem usados posteriormente (por exemplo, por um recetor CDMA). 

"""