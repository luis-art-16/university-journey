# ============================
# PARAMETERS & CONFIGURATION
# ============================
import numpy as np

# Sync parameters (MUST match transmitter!)
SYNC_PATTERN = np.tile([1, 0, 1, 0, 1, 1, 0, 0], 8)  # 64-bit sync
SYNC_PREAMBLE_LENGTH = len(SYNC_PATTERN)  # 64

# File paths (unchanged)
TRANSMITTER_FILES = [
    'transmitted_cdma_signal_1.txt'
]
RECEIVER_FILE = 'recovered_messages.txt'
OUTPUT_FILENAME = 'ber_results.txt'

# ============================
# CORE BER FUNCTIONS
# ============================
def calculate_ber(original, recovered):
    original_payload = original[SYNC_PREAMBLE_LENGTH:]  # Remove sync bits
    expected_length = len(original_payload)
    
    # Count errors in recovered bits
    errors = np.sum(original_payload[:len(recovered)] != recovered)
    
    # Add missing bits as errors
    missing_bits = expected_length - len(recovered)
    total_errors = errors + missing_bits
    
    return total_errors / expected_length  # BER


def ber_meter(transmitter_files, receiver_file, output_filename):
    """
    Computes BER for each Tx-Rx pair, excluding sync bits.
    """
    # Load original messages (including sync)
    original_messages = []
    for tx_file in transmitter_files:
        with open(tx_file, 'r') as f:
            lines = f.readlines()
            original_messages.append(np.array(list(map(int, lines[1].strip().split(',')))))

    # Load recovered messages (payload only)
    with open(receiver_file, 'r') as f:
        recovered_messages = [np.array(list(map(int, line.strip().split(',')))) for line in f]

    # Calculate BER for each Tx
    ber_results = {}
    for i, (orig, recv) in enumerate(zip(original_messages, recovered_messages), 1):
        try:
            ber = calculate_ber(orig, recv)
            ber_results[f"Tx{i}"] = ber
            print(f"Tx{i}: BER = {ber:.2%} (excluding sync)")
        except Exception as e:
            print(f"Tx{i}: Error in BER calculation - {str(e)}")
            ber_results[f"Tx{i}"] = float('nan')

    # Save results
    with open(output_filename, 'w') as f:
        for tx, ber in ber_results.items():
            f.write(f"{tx}: {ber:.6f}\n")

    return ber_results

# ============================
# MAIN EXECUTION
# ============================
if __name__ == "__main__":
    ber_meter(TRANSMITTER_FILES, RECEIVER_FILE, OUTPUT_FILENAME)