# ============================
# PARAMETERS & CONFIGURATION
# ============================

import numpy as np
import matplotlib.pyplot as plt

# Import functions
from Transmitter1 import main as generate_tx1
from Channel import combine_cdma_signals
from Receiver import recover_cdma_signals
from BER_Meter import calculate_ber

# Simulation configuration
SNR_START_DB = -20      # Start SNR (inclusive)
SNR_END_DB = 20           # End SNR (exclusive)
SNR_STEP_DB = 2           # Step size
NUM_TRIALS = 1            # Trials per SNR point
ATTENUATION = 1         # Single attenuation coefficient

# Output files
OUTPUT_CSV = 'ber_results_single.csv'
OUTPUT_PLOT = 'ber_vs_snr_single.png'

# ============================
# SIMULATION FUNCTION (SIMPLIFIED)
# ============================

def simulate_ber_vs_snr(snr_values, num_trials):
    """
    Perform BER simulations for single transmitter.
    Returns dictionary mapping SNR to average BER.
    """
    # Generate transmitter data once (reused for all trials)
    tx_data = generate_tx1(in_memory=True)
    ber_records = {snr: [] for snr in snr_values}

    for snr in snr_values:
        print(f"\n=== Simulating SNR = {snr} dB ===")
        
        for _ in range(num_trials):
            # Combine signal with noise (note: using list with single element)
            combined, metadata = combine_cdma_signals(
                attenuation_coeffs=[ATTENUATION],
                snr_db=snr,
                use_in_memory=True,
                transmitter_data_list=[tx_data]
            )

            # Recover message (returns list with single element)
            recovered = recover_cdma_signals(
                use_in_memory=True,
                combined_signal=combined,
                metadata=metadata
            )

            # Calculate BER (compare original vs recovered[0])
            ber = calculate_ber(tx_data['message'], recovered[0])
            ber_records[snr].append(ber)

    # Average results
    return {snr: np.mean(vals) for snr, vals in ber_records.items()}

# ============================
# PLOTTING FUNCTION (SIMPLIFIED)
# ============================

def plot_ber_vs_snr(ber_data):
    """Plot single BER curve."""
    snr = sorted(ber_data.keys())
    ber = [ber_data[s] for s in snr]

    plt.figure(figsize=(8, 5))
    plt.semilogy(snr, ber, marker='o', label='Tx1')
    plt.title('BER vs SNR (Single Transmitter)')
    plt.xlabel('SNR (dB)')
    plt.ylabel('Bit Error Rate (BER)')
    plt.grid(True, which='both', linestyle='--')
    plt.legend()
    plt.tight_layout()
    plt.savefig(OUTPUT_PLOT)
    plt.show()

# ============================
# MAIN EXECUTION
# ============================

if __name__ == '__main__':
    snr_vals = np.arange(SNR_START_DB, SNR_END_DB + SNR_STEP_DB, SNR_STEP_DB)
    average_ber = simulate_ber_vs_snr(snr_vals, NUM_TRIALS)

    # Print results
    print("\n--- BER Results ---")
    for snr, ber in sorted(average_ber.items()):
        print(f"SNR={snr:>5.1f} dB  |  BER: {ber:.6f}")

    # Save to CSV
    with open(OUTPUT_CSV, 'w') as f:
        f.write("SNR,BER\n")
        for snr, ber in sorted(average_ber.items()):
            f.write(f"{snr},{ber:.6f}\n")

    # Plot
    plot_ber_vs_snr(average_ber)