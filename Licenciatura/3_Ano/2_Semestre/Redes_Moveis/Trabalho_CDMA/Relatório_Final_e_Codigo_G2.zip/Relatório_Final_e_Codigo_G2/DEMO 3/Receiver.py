# Receiver.py 
import numpy as np
import argparse

COMBINED_SIGNAL_FILE = 'combined_cdma_signal.txt'
SAMPLING_RATE = 5
SYNC_PATTERN = np.tile([1, 0, 1, 0, 1, 1, 0, 0], 8)
SYNC_PREAMBLE_LENGTH = len(SYNC_PATTERN)
SYNC_CORR_THRESHOLD = 0.5
RECOVERED_MESSAGES_FILE = 'recovered_messages.txt'

def detect_sync(signal, spreading_code, sampling_rate):
    """
    Detects the start of the synchronization preamble using FFT-based correlation.

    Args:
        signal (np.ndarray): Received CDMA signal (1D array of samples).
        spreading_code (np.ndarray): Spreading code for one transmitter.
        sampling_rate (int): Number of samples per chip.

    Returns:
        tuple: (position of the correlation peak, normalized peak value)
    """
    # 1. Convert the sync pattern from {0,1} to bipolar {-1,+1}
    bipolar_sync_bits = SYNC_PATTERN * 2 - 1

    # 2. Spread the bipolar sync bits by the given spreading code (Kronecker product)
    spread_sync_sequence = np.kron(bipolar_sync_bits, spreading_code)

    # 3. Upsample each chip by repeating it sampling_rate times
    sync_template = np.repeat(spread_sync_sequence, sampling_rate)

    # 4. Compute FFT length to avoid circular convolution effects
    n_fft = len(signal) + len(sync_template) - 1

    # 5. FFT of the received signal (zero-padded to n_fft)
    signal_spectrum = np.fft.rfft(signal, n=n_fft)

    # 6. FFT of the reversed template (for correlation)
    template_reversed = sync_template[::-1]
    template_spectrum = np.fft.rfft(template_reversed, n=n_fft)

    # 7. Multiply spectrums and invert FFT to get time-domain convolution result
    convolution_result = np.fft.irfft(signal_spectrum * template_spectrum, n=n_fft)

    # 8. Extract valid correlation values (no wrap-around)
    start_index = len(sync_template) - 1
    end_index = start_index + (len(signal) - len(sync_template) + 1)
    valid_corr = convolution_result[start_index:end_index]

    # 9. Find the index and value of the maximum absolute correlation
    peak_position = np.argmax(np.abs(valid_corr))
    peak_value = valid_corr[peak_position] / len(sync_template)
    
    print(f"Maximum correlation detected: {peak_value:.4f}")

    # 10. Check against correlation threshold
    if abs(peak_value) < SYNC_CORR_THRESHOLD:
        raise ValueError("Sync not detected via FFT method")

    return peak_position, peak_value

def despread_signal(combined_signal, spreading_code, spreading_factor, sampling_rate, sync_position=None):
    """
    Despreads the signal to recover the original bits.
    
    Args:
        combined_signal (np.ndarray): Combined CDMA signal
        spreading_code (np.ndarray): Spreading code for this transmitter
        spreading_factor (int): Spreading factor
        sampling_rate (int): Number of samples per chip
        sync_position (int, optional): Pre-detected sync position. If None, detects sync.
    
    Returns:
        np.ndarray: Correlation values for each bit
    """
    if sync_position is None:
        sync_pos, _ = detect_sync(combined_signal, spreading_code, sampling_rate)
    else:
        sync_pos = sync_position
    
    payload_start = sync_pos + SYNC_PREAMBLE_LENGTH * spreading_factor * sampling_rate
    payload_signal = combined_signal[payload_start:]
    
    segment_length = spreading_factor * sampling_rate
    num_bits = len(payload_signal) // segment_length
    reshaped = payload_signal[:num_bits*segment_length].reshape(num_bits, segment_length)
    sampled_code = np.repeat(spreading_code, sampling_rate)
    
    return np.sum(reshaped * sampled_code, axis=1)

def recover_bits(correlation_values):
    return (correlation_values > 0).astype(int)

def save_recovered_messages(messages, filename=RECOVERED_MESSAGES_FILE):
    with open(filename, 'w') as f:
        for msg in messages:
            f.write(','.join(map(str, msg.tolist())) + '\n')
    print(f"Mensagens salvas em {filename}")

def recover_cdma_signals(use_in_memory=False, combined_signal=None, metadata=None, detect_only=False):
    """
    Recover CDMA signals with option to only detect synchronization positions
    
    Args:
        use_in_memory (bool): Use in-memory data instead of files
        combined_signal (np.ndarray): Combined CDMA signal (in-memory mode)
        metadata (dict): Metadata dictionary (in-memory mode)
        detect_only (bool): Only detect sync positions without full recovery
    
    Returns:
        list: Recovered messages or sync positions depending on mode
    """
    if use_in_memory:
        codes = metadata['codes']
        spreading_factors = metadata['spreading_factors']
    else:
        with open(COMBINED_SIGNAL_FILE, 'r') as f:
            lines = f.readlines()
        combined_signal = np.fromstring(lines[0], sep=',')
        codes, spreading_factors = [], []
        idx = 1
        while idx < len(lines):
            code = np.fromstring(lines[idx+1], sep=',', dtype=int)
            factor = int(lines[idx+2].strip())
            codes.append(code)
            spreading_factors.append(factor)
            idx += 3

    # Fast mode: only detect sync positions
    if detect_only:
        sync_positions = []
        for code, factor in zip(codes, spreading_factors):
            try:
                pos, val = detect_sync(combined_signal, code, SAMPLING_RATE)
                sync_positions.append((pos, val))
                print(f"Sync detectado: pos={pos}, corr={val:.4f}")
            except ValueError as e:
                print(f"Erro na detecção de sync: {str(e)}")
                sync_positions.append((None, None))
        return sync_positions

    # Normal mode: full signal recovery
    recovered = []
    for code, factor in zip(codes, spreading_factors):
        try:
            # Usa detecção de sync normal
            corr = despread_signal(combined_signal, code, factor, SAMPLING_RATE)
            bits = recover_bits(corr)
            recovered.append(bits)
        except ValueError as e:
            print(f"Erro no desespalhamento: {str(e)}")
            recovered.append(np.array([]))

    if not use_in_memory:
        save_recovered_messages(recovered)
        print("\nMensagens recuperadas:")
        for i, bits in enumerate(recovered, 1):
            print(f"Transmissor {i}: {bits[:10]}...")

    return recovered

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='CDMA Receiver')
    parser.add_argument('--detect-only', action='store_true',
                        help='Executa apenas detecção de sync sem processamento completo')
    args = parser.parse_args()

    if args.detect_only:
        print("Executando modo rápido: apenas detecção de sync")
        sync_data = recover_cdma_signals(use_in_memory=False, detect_only=True)
        for i, (pos, val) in enumerate(sync_data, 1):
            if pos is not None:
                print(f"Transmissor {i}: pos={pos}, corr={val:.4f}")
            else:
                print(f"Transmissor {i}: Sync não detectado")
    else:
        recover_cdma_signals(use_in_memory=False)