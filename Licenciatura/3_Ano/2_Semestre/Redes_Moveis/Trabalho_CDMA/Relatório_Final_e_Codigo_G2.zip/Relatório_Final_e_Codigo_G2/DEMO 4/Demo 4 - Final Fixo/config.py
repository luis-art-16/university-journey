# Parâmetros de configuração do sistema CDMA

MESSAGE_LENGTH    = 10064      # Número de bits por utilizador (payload, sem o padrão de sincronização)
WALSH_ORDER       = 16         # Ordem da matriz de Walsh (define o número máximo de códigos ortogonais)
SPREADING_FACTOR  = 16         # Fator de spreading (quantos chips por bit; determina o grau de espalhamento)
SAMPLING_RATE     = 5          # Número de amostras por chip (para sobremostragem do sinal)
LEADING_ZEROS     = 50         # Número de chips a zero antes do início do sinal útil (ajuda a separar sinais no tempo)
TX_COUNT          = 7          # Número de utilizadores/transmissores simulados

# Nomes padrão dos ficheiros gerados/esperados por cada módulo
TX_PATTERN        = "transmitted_cdma_signal_{}.txt"    # Sinal transmitido por cada utilizador
COMBINED_FILE     = "combined_cdma_signal.txt"          # Sinal combinado (de todos os utilizadores) recebido pelo canal
RECOVERED_FILE    = "recovered_messages_demo4.txt"      # Mensagens recuperadas no recetor
BER_FILE          = "ber_results.txt"                   # Ficheiro de resultados de BER (Bit Error Rate)
