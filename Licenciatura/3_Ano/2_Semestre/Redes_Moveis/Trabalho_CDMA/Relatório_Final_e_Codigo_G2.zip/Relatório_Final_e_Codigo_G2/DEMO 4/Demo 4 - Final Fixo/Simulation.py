""" 
Como é que o recetor encontra o campo de sincronização?

O recetor encontra o campo de sincronização calculando a correlação cruzada entre o sinal recebido e uma réplica do campo de sincronização
espalhado com o código do utilizador e sobremostrado. O máximo da correlação indica o início do campo de sincronização no tempo.
Com offset fixo, basta procurar o pico uma vez, pois todos os utilizadores estão alinhados.
Com offset aleatório, cada utilizador tem o seu atraso, então a busca é feita individualmente para cada user, 
sempre espalhando o padrão de sincronismo pelo código desse user.

"""

import numpy as np
import matplotlib.pyplot as plt
from Transmitters import generate_transmitters_mem
from Channel import combine_cdma_signals
from Receiver_demo4 import recover_cdma_signals_mem
from BER_Meter import ber_meter_mem
from config import *

RUNS_PER_SNR = 1  # Número de repetições por SNR (aumenta para mais estatística)

SNR_RANGE = np.arange(-20, 21, 2)  # SNR de -10 dB a 10 dB, passo 2dB
BER_CURVES = {f"Tx{i+1}": [] for i in range(TX_COUNT)}

for snr in SNR_RANGE:
    ber_acc = {k: [] for k in BER_CURVES} #Guardar temporariamente os resultados de BER (Bit Error Rate) de cada utilizador, ao longo dos vários ciclos de simulação para cada valor de SNR.
    print(f"\n=== SNR {snr} dB ===")
    for _ in range(RUNS_PER_SNR):
        # Gera transmissores (bits, códigos, sinais)
        transmitters = generate_transmitters_mem()
        # Combina sinais no canal (em memória!)
        noisy_signal, metadata = combine_cdma_signals(
            attenuation_coeffs=np.ones(TX_COUNT),
            snr_db=snr,
            use_in_memory=True,  # obrigatório para modo simulador!
            transmitter_data_list=transmitters
        )
        # Recupera bits transmitidos
        recovereds = recover_cdma_signals_mem(noisy_signal, metadata['codes'])
        # Calcula BER de cada utilizador
        ber = ber_meter_mem(metadata['messages'], recovereds)
        for k in BER_CURVES:
            ber_acc[k].append(ber[k]) #No final, pode-se calcular a média dos BERs para cada utilizador para esse SNR.

    # Média dos BERs para cada user neste SNR
    for k in BER_CURVES:
        BER_CURVES[k].append(np.mean(ber_acc[k]))
    ber_medio = np.mean([np.mean(ber_acc[k]) for k in BER_CURVES])
    print(f"BER = {ber_medio*100:.4f}%")

# Gráfico final BER vs SNR
plt.figure(figsize=(8, 5))
for i, (tx, curve) in enumerate(BER_CURVES.items()):
    plt.semilogy(SNR_RANGE, curve, marker='o', label=tx)
plt.xlabel("SNR (dB)")
plt.ylabel("Bit Error Rate (BER)")
plt.title(f"BER vs SNR ({TX_COUNT} utilizadores CDMA)")
plt.grid(True, which='both', ls='--')
plt.legend()
plt.savefig("ber_vs_snr.png")
plt.show()
