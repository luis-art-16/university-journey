import numpy as np
from config import *

ATTENUATION_COEFFICIENTS = np.array([1.0, 0.7, 0.8, 0.6, 0.4, 0.5, 0.3])
TRANSMITTER_SIGNAL_FILES = [TX_PATTERN.format(i+1) for i in range(TX_COUNT)]
SNR_DB_FILE_MODE = 10
COMBINED_SIGNAL_FILE = COMBINED_FILE

def compute_signal_power(signal):
    """
    Calcula a potência média do sinal (útil para calcular ruído)
    """
    return np.mean(signal ** 2)

def add_awgn_noise(signal, snr_db):
    """
    Adiciona ruído branco gaussiano (AWGN) ao sinal de entrada, para atingir o SNR desejado.
    - SNR em dB
    """
    power = compute_signal_power(signal)
    snr_linear = 10 ** (snr_db / 10)
    noise_power = power / snr_linear
    noise_std_dev = np.sqrt(noise_power)
    noise = np.random.normal(0, noise_std_dev, size=signal.shape)
    print(f"SNR: {snr_db} dB, Noise std: {noise_std_dev:.4f}, Signal power: {power:.4f}")
    return signal + noise, noise_std_dev

def combine_cdma_signals(
        attenuation_coeffs,
        snr_db,
        use_in_memory=False,
        signal_file_list=None,
        transmitter_data_list=None
    ):
    """
    Junta sinais de todos os utilizadores, simula passagem no canal e adiciona ruído.
    Dois modos:
      - Modo ficheiro: lê sinais dos ficheiros dos transmissores.
      - Modo memória: usa lista de dicts (output do generate_transmitters_mem)
    """
    if use_in_memory:
        signals = [entry['signal'] for entry in transmitter_data_list]
        messages = [entry['message'] for entry in transmitter_data_list]
        codes =    [entry['code'] for entry in transmitter_data_list]
        spreading_factors = [entry['spreading_factor'] for entry in transmitter_data_list]
    else:
        assert signal_file_list is not None, "signal_file_list é obrigatório no modo ficheiro" #garante que nao se esquece de passar o arg 'signal_file_list'
        signals, messages, codes, spreading_factors = [], [], [], []
        for path in signal_file_list:
            with open(path, 'r') as f:
                lines = f.readlines()
            sig = np.fromstring(lines[0], sep=',')
            msg = list(map(int, lines[1].split(',')))
            code = list(map(int, lines[2].split(',')))
            sf = int(lines[3].strip())
            signals.append(sig)
            messages.append(msg)
            codes.append(code)
            spreading_factors.append(sf)
    max_len = max(sig.size for sig in signals)
    composite = np.zeros(max_len)
    
    # Junta todos os sinais (com possíveis offsets já embutidos)
    for sig, coeff in zip(signals, attenuation_coeffs):
        padded = np.pad(sig, (0, max_len - sig.size), 'constant')
        composite += coeff * padded
    # Adiciona ruído
    noisy_composite, noise_std = add_awgn_noise(composite, snr_db)
    if not use_in_memory:
        with open(COMBINED_SIGNAL_FILE, 'w') as out:
            out.write(','.join(map(str, noisy_composite)) + '\n')
            for msg, code, sf in zip(messages, codes, spreading_factors):
                out.write(','.join(map(str, msg)) + '\n')
                out.write(','.join(map(str, code)) + '\n')
                out.write(str(sf) + '\n')
        print(
            f"Sinal combinado guardado em '{COMBINED_SIGNAL_FILE}' "
            f"com SNR={snr_db} dB (noise_std={noise_std:.4f})"
        )
    metadata = {
        'messages': messages,        # Mensagens transmitidas (bits)
        'codes': codes,              # Códigos de cada utilizador
        'spreading_factors': spreading_factors
    }
    return noisy_composite, metadata

if __name__ == '__main__':
    combine_cdma_signals(
        attenuation_coeffs=ATTENUATION_COEFFICIENTS,
        snr_db=SNR_DB_FILE_MODE,
        use_in_memory=False,
        signal_file_list=TRANSMITTER_SIGNAL_FILES
    )
