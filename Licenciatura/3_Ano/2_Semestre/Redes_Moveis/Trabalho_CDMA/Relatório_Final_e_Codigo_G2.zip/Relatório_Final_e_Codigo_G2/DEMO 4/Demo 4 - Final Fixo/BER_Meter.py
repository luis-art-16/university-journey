import numpy as np

# Definição do padrão de sincronização usado nos transmissores (também serve para alinhamento)
SYNC_PATTERN = np.tile([1, 0, 1, 0, 1, 1, 0, 0], 8)  # 64 bits de sincronismo
SYNC_PREAMBLE_LENGTH = len(SYNC_PATTERN)

TRANSMITTER_FILES = [f'transmitted_cdma_signal_{i+1}.txt' for i in range(7)]
RECEIVER_FILE = 'recovered_messages_demo4.txt'
OUTPUT_FILENAME = 'ber_results.txt'

def calculate_ber(original, recovered):
    """
    Calcula o Bit Error Rate (BER) entre o original e o recuperado.
    - Só compara o payload (exclui o preâmbulo de sincronização)
    - Conta diferenças bit a bit e bits em falta como erros.
    """
    original_payload = original[SYNC_PREAMBLE_LENGTH:]
    expected_length = len(original_payload)
    if len(recovered) == 0:
        return 1.0
    compare_len = min(len(original_payload), len(recovered))
    errors = np.sum(original_payload[:compare_len] != recovered[:compare_len])
    missing_bits = max(0, expected_length - compare_len)
    total_errors = errors + missing_bits
    return total_errors / expected_length

def ber_meter(transmitter_files, receiver_file, output_filename):
    """
    Modo ficheiro: lê mensagens transmitidas e recuperadas dos ficheiros,
    calcula BER para cada utilizador e grava resultados.
    """
    original_messages = []
    for tx_file in transmitter_files:
        with open(tx_file, 'r') as f:
            lines = f.readlines()
            bits = list(map(int, lines[1].strip().split(',')))
            original_messages.append(np.array(bits))
    with open(receiver_file, 'r') as f:
        recovered_messages = [
            np.array(list(map(int, line.strip().split(','))))
            for line in f
        ]
    ber_results = {}
    for i, (orig, recv) in enumerate(zip(original_messages, recovered_messages), start=1):
        try:
            ber = calculate_ber(orig, recv)
            ber_results[f"Tx{i}"] = ber
            print(f"Tx{i}: BER = {ber:.2%} (excluindo sync)")
        except Exception as e:
            print(f"Tx{i}: Erro no cálculo de BER – {e}")
            ber_results[f"Tx{i}"] = float('nan')
    with open(output_filename, 'w') as f:
        for tx, ber in ber_results.items():
            f.write(f"{tx}: {ber:.6f}\n")
    return ber_results

# ---- VERSÃO MEMÓRIA ----
def ber_meter_mem(originals, recovereds):
    """
    Modo simulador (em memória): calcula BER diretamente sobre arrays em RAM.
    """
    ber_results = {}
    for i, (orig, recv) in enumerate(zip(originals, recovereds), start=1):
        try:
            ber = calculate_ber(orig, recv)
            ber_results[f"Tx{i}"] = ber
        except Exception:
            ber_results[f"Tx{i}"] = float('nan')
    return ber_results

if __name__ == "__main__":
    ber_meter(TRANSMITTER_FILES, RECEIVER_FILE, OUTPUT_FILENAME)
