import numpy as np
from config import *
from BER_Meter import SYNC_PATTERN, SYNC_PREAMBLE_LENGTH

def despread(signal, code, start_pos=0):
    """
    Recupera a sequência de bits original de um sinal CDMA despreadando:
      - Para cada bit, faz produto interno entre o sinal e o código,
      - Se resultado positivo => bit=1, negativo => bit=0
      - Usa norm para garantir decisão correta (pode dar problemas se o sinal estiver saturado/ruído extremo)
    """
    chunk = SPREADING_FACTOR * SAMPLING_RATE     # Quantidade de samples por bit transmitido
    scode = np.repeat(code, SAMPLING_RATE)       # Repete código para fazer match com a sobreamostragem
    norm = np.dot(scode, scode)                  # Normalização para produto escalar


    # Detecção ótima de cada bit, alinhando o código para cada secção do sinal, reconstruindo o bitstream transmitido.
    bits = []
    for b in range(MESSAGE_LENGTH):
        a = start_pos + b * chunk                # Início do bit b
        z = start_pos + (b + 1) * chunk          # Fim do bit b
        if z > len(signal):
            break
        bits.append(1 if np.dot(signal[a:z], scode) / norm > 0 else 0)
    return np.array(bits, dtype=int)

def find_sync_position(signal, code, sync_pattern, expected_start=250, tol=5000):
    """
    Procura, no sinal de entrada, o início do padrão de sincronização
    - Usa produto interno (correlação cruzada) entre o código espalhado do sync_pattern e o sinal real.
    - expected_start/tol servem para limitar a pesquisa a uma zona provável
    - Retorna o índice (offset) mais provável do início da mensagem útil.
    """
    sync_bits = np.array(sync_pattern)
    sync_chips = np.repeat(sync_bits * 2 - 1, SPREADING_FACTOR)
    sync_code = np.tile(code, len(sync_pattern))
    sync_signal = sync_chips * sync_code
    sync_oversampled = np.repeat(sync_signal, SAMPLING_RATE)
    correlation = np.correlate(signal, sync_oversampled, mode='valid') #mode garante que só calcula correlação quando o sync_oversampled cabe inteiro dentro do signal
    # procura máximo na zona esperada
    candidates = np.where(np.abs(np.arange(len(correlation)) - expected_start) < tol)[0]
    if len(candidates) > 0:
        idx = candidates[np.argmax(correlation[candidates])]
        return idx
    # fallback: pico global
    return np.argmax(correlation)

def recover_cdma_signals(n_tx=TX_COUNT, combined_file=COMBINED_FILE, out_file=RECOVERED_FILE):
    """
    Recupera as mensagens de cada utilizador do sinal combinado.
    - Lê o sinal combinado do canal e os códigos de cada utilizador dos seus ficheiros
    - Encontra a posição de sincronismo (offset) para o primeiro utilizador (sincronismo global)
    - Usa o mesmo offset para todos os users (assumindo que não há offset aleatório)
    - Despread para obter os bits transmitidos.
    """
    signal = np.fromstring(open(combined_file).read().splitlines()[0], sep=",") # transforma a linha de texto do ficheiro num vetor de dados “pronto a usar” para processamento matemático (string de num para array)
    codes = []
    for i in range(1, n_tx+1):
        code = np.fromstring(
            open(TX_PATTERN.format(i)).read().splitlines()[2],
            sep=',', dtype=int
        )
        codes.append(code)
    # Sincronismo só no primeiro user
    main_start = find_sync_position(signal, codes[0], SYNC_PATTERN, expected_start=250, tol=200)
    print(f"SINCRONISMO GLOBAL: {main_start}")
    recovered = []
    for code in codes:
        start_payload = main_start + SPREADING_FACTOR * SAMPLING_RATE * SYNC_PREAMBLE_LENGTH
        bits = despread(signal, code, start_payload)
        recovered.append(bits)
    with open(out_file, "w") as f:
        for bits in recovered:
            f.write(",".join(map(str, bits)) + "\n")
    return recovered

# ---- VERSÃO MEMÓRIA (simulador) ----
def recover_cdma_signals_mem(signal, codes):
    """
    Igual ao de ficheiros, mas recebe o sinal e códigos diretamente em RAM.
    """
    main_start = find_sync_position(signal, codes[0], SYNC_PATTERN, expected_start=250, tol=200)
    print(f"SINCRONISMO GLOBAL: {main_start}")
    recovered = []
    for code in codes:
        start_payload = main_start + SPREADING_FACTOR * SAMPLING_RATE * SYNC_PREAMBLE_LENGTH
        bits = despread(signal, code, start_payload)
        recovered.append(bits)
    return recovered

if __name__ == "__main__":
    recover_cdma_signals()
    print("→", RECOVERED_FILE)
