import numpy as np
from config import *

def add_awgn_noise(signal, snr_db):
    """
    Adiciona ruído branco gaussiano (AWGN) ao sinal, ajustando a potência de ruído
    para atingir o SNR desejado (em dB).
    """
    signal_power = np.mean(signal ** 2)                 # Potência média do sinal
    snr_linear = 10 ** (snr_db / 10)                    # Converte SNR de dB para linear
    noise_power = signal_power / snr_linear
    noise_std = np.sqrt(noise_power)
    noise = np.random.normal(0, noise_std, signal.shape)  # Vetor de ruído
    return signal + noise, noise_std

# --- MODO FICHEIRO ---
def combine_cdma_signals_file(attenuation_coeffs, snr_db, in_files, out_file='combined_cdma_signal.txt', max_offset=3000):
    """
    Lê os sinais transmitidos de cada ficheiro, aplica offset aleatório a cada user,
    soma, e adiciona ruído (canal CDMA).
    Grava o resultado em disco.
    """
    signals, messages, codes, spreading_factors = [], [], [], []
    for path in in_files:
        with open(path, 'r') as f:
            lines = f.readlines()
        sig = np.fromstring(lines[0], sep=',')
        msg = list(map(int, lines[1].split(',')))
        code = list(map(int, lines[2].split(',')))
        sf = int(lines[3].strip())
        signals.append(sig)
        messages.append(msg)
        codes.append(code)
        spreading_factors.append(sf)
    # Gera offsets aleatórios para cada utilizador
    offsets = np.random.randint(0, max_offset, size=len(signals))
    print("Offsets aplicados (samples):", offsets)
    # Calcula comprimento total do sinal resultante
    lengths = [sig.size + off for sig, off in zip(signals, offsets)]
    max_len = max(lengths)
    composite = np.zeros(max_len)
    # Adiciona cada sinal, com offset e atenuação
    for sig, coeff, offset in zip(signals, attenuation_coeffs, offsets):
        padded = np.pad(sig, (offset, max_len - sig.size - offset), 'constant')
        composite += coeff * padded
    noisy_composite, noise_std = add_awgn_noise(composite, snr_db)
    # Guarda o sinal combinado (linha única de samples)
    with open(out_file, 'w') as f:
        f.write(",".join(map(str, noisy_composite)) + "\n")
    # Opcional: guardar offsets/códigos em ficheiro à parte
    return noisy_composite, {'messages': messages, 'codes': codes, 'spreading_factors': spreading_factors, 'offsets': offsets.tolist()}

# --- MODO MEMÓRIA (simulador) ---
def combine_cdma_signals_mem(attenuation_coeffs, snr_db, transmitter_data_list, max_offset=3000):
    """
    Igual ao de ficheiro, mas usa lista de sinais em RAM.
    """
    signals = [entry['signal'] for entry in transmitter_data_list]
    messages = [entry['message'] for entry in transmitter_data_list]
    codes = [entry['code'] for entry in transmitter_data_list]
    spreading_factors = [entry['spreading_factor'] for entry in transmitter_data_list]
    offsets = np.random.randint(0, max_offset, size=len(signals))
    print("Offsets aplicados (samples):", offsets)
    lengths = [sig.size + off for sig, off in zip(signals, offsets)]
    max_len = max(lengths)
    composite = np.zeros(max_len)
    for sig, coeff, offset in zip(signals, attenuation_coeffs, offsets):
        padded = np.pad(sig, (offset, max_len - sig.size - offset), 'constant')
        composite += coeff * padded
    noisy_composite, noise_std = add_awgn_noise(composite, snr_db)
    metadata = {
        'messages': messages,
        'codes': codes,
        'spreading_factors': spreading_factors,
        'offsets': offsets.tolist()
    }
    return noisy_composite, metadata

if __name__ == "__main__":
    # Exemplo de uso em modo ficheiro
    combine_cdma_signals_file(
        attenuation_coeffs=np.ones(TX_COUNT),
        snr_db=10,
        in_files=[TX_PATTERN.format(i+1) for i in range(TX_COUNT)]
    )
