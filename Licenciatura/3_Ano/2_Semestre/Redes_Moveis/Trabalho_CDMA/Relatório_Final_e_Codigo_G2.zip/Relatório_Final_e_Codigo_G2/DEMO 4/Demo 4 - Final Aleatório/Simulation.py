
""" 
Como é que o recetor encontra o campo de sincronização

O recetor encontra o campo de sincronização calculando a correlação cruzada entre o sinal recebido e uma réplica do campo de sincronização
espalhado com o código do user e sobremostrado. O máximo da correlação indica o início do campo de sincronização no tempo.
Com offset fixo, basta procurar o pico uma vez, pois todos os utilizadores estão alinhados.
Com offset aleatório, cada utilizador tem o seu atraso, então a busca é feita individualmente para cada user, 
sempre espalhando o padrão de sincronismo pelo código desse user.

"""
import numpy as np
import matplotlib.pyplot as plt
from Transmitters import generate_transmitters_mem
from Channel import combine_cdma_signals_mem
from Receiver_demo4 import recover_cdma_signals_mem
from BER_Meter import ber_meter_mem
from config import *

RUNS_PER_SNR = 1 # Quantas vezes repete cada simulação para o mesmo SNR (aumenta para média estatística melhor)

SNR_RANGE = np.arange(-10, 11, 2)  # SNR de -10 a 10 dB, de 2 em 2
BER_CURVES = {f"Tx{i+1}": [] for i in range(TX_COUNT)}  # Dicionário: uma curva para cada user

for snr in SNR_RANGE:
    ber_acc = {k: [] for k in BER_CURVES}  # Para cada user, uma lista dos BERs nesta rodada
    print(f"\n=== SNR {snr} dB ===")
    for _ in range(RUNS_PER_SNR):
        transmitters = generate_transmitters_mem()
        noisy_signal, metadata = combine_cdma_signals_mem(
            attenuation_coeffs=np.ones(TX_COUNT),
            snr_db=snr,
            transmitter_data_list=transmitters,
            max_offset = 3000
        )
        recovereds = recover_cdma_signals_mem(noisy_signal, metadata['codes'])
        ber = ber_meter_mem(metadata['messages'], recovereds)
        for k in BER_CURVES:
            ber_acc[k].append(ber[k])  # Adiciona BER desta simulação à lista do user k
    # Calcula a média dos BERs para cada user neste SNR
    for k in BER_CURVES:
        BER_CURVES[k].append(np.mean(ber_acc[k]))
    ber_medio = np.mean([np.mean(ber_acc[k]) for k in BER_CURVES])
    print(f"BER = {ber_medio*100:.4f}%")

# Gráfico final BER vs SNR
plt.figure(figsize=(8,5))
for i, (tx, curve) in enumerate(BER_CURVES.items()):
    plt.semilogy(SNR_RANGE, curve, marker='o', label=tx)
plt.xlabel("SNR (dB)")
plt.ylabel("Bit Error Rate (BER)")
plt.title(f"BER vs SNR ({TX_COUNT} utilizadores CDMA)")
plt.grid(True, which='both', ls='--')
plt.legend()
plt.savefig("ber_vs_snr.png")
plt.show()
