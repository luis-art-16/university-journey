# config.py
MESSAGE_LENGTH    = 10064         # Número de bits de payload transmitidos por cada user (não inclui preâmbulo de sync)
WALSH_ORDER       = 16            # Ordem da matriz de Walsh-Hadamard (máx. de códigos ortogonais disponíveis)
SPREADING_FACTOR  = 16            # Quantos chips (pulsos) representam cada bit (define o "grau de espalhamento")
SAMPLING_RATE     = 5             # Amostras por chip (permite sobremostragem realista do sinal físico)
LEADING_ZEROS     = 50            # Chips a zero antes do início do sinal (ajuda no alinhamento)
TX_COUNT          = 3           # Número de utilizadores (transmissores/CDMA users)
max_offset        = 3000          # Offset máximo, em samples, aplicado aleatoriamente a cada utilizador (simula delays distintos)

# Nomes padrão para os ficheiros usados na pipeline (ficheiro)
TX_PATTERN        = "transmitted_cdma_signal_{}.txt"   # Ficheiro de output do transmissor (um por user)
COMBINED_FILE     = "combined_cdma_signal.txt"         # Ficheiro do sinal somado (output do canal)
RECOVERED_FILE    = "recovered_messages_demo4.txt"     # Ficheiro das mensagens recuperadas pelo recetor
BER_FILE          = "ber_results.txt"                  # Ficheiro de resultados de BER (calculado pelo BER_Meter)

