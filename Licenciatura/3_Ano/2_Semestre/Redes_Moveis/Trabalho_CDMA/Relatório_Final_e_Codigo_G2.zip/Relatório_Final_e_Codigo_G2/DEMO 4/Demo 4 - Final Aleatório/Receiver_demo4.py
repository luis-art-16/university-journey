import numpy as np
from config import *
from BER_Meter import SYNC_PATTERN, SYNC_PREAMBLE_LENGTH

def despread(signal, code, start_pos=0):
    """
    Recupera bits do sinal CDMA:
    Para cada bit:
      - Calcula o produto interno do sinal e do código (com oversampling).
      - Se resultado positivo -> bit=1, senão bit=0.
      - Normaliza pelo 'norm' para compensar possíveis escalas.
    """
    chunk = SPREADING_FACTOR * SAMPLING_RATE    # Samples por bit transmitido
    scode = np.repeat(code, SAMPLING_RATE)      # Código expandido para o oversampling
    norm = np.dot(scode, scode)                 # Energia do código (para normalizar)
    bits = []
    for b in range(MESSAGE_LENGTH):
        a = start_pos + b * chunk                # Início da secção correspondente ao bit b
        z = start_pos + (b + 1) * chunk          # Fim dessa secção
        if z > len(signal):                      # Se já não há samples suficientes, para o loop
            break
        # Detecção: se projecção com código for >0, é 1; senão 0
        bits.append(1 if np.dot(signal[a:z], scode) / norm > 0 else 0)
    return np.array(bits, dtype=int)

def find_sync_position(signal, code, sync_pattern, expected_start=0, tol=None):
    """
    Localiza o início do preâmbulo de sincronização (padrão SYNC_PATTERN) no sinal recebido.
    - 'sync_pattern' é espalhado e sobremostrado para igualar o sinal real.
    - A correlação máxima indica o ponto mais provável onde começa o sync (e logo a mensagem útil).
    - Se 'tol' for dado, só procura em torno de 'expected_start' (pode acelerar para sinais grandes).
    """
    sync_bits = np.array(sync_pattern)
    sync_chips = np.repeat(sync_bits * 2 - 1, SPREADING_FACTOR)
    sync_code = np.tile(code, len(sync_pattern))
    sync_signal = sync_chips * sync_code
    sync_oversampled = np.repeat(sync_signal, SAMPLING_RATE)
    # Correlação cruzada entre sinal recebido e sync_oversampled:
    correlation = np.correlate(signal, sync_oversampled, mode='valid')
    # Se tol estiver definido, limita pesquisa à janela à volta de expected_start
    if tol is not None:
        candidates = np.where(np.abs(np.arange(len(correlation)) - expected_start) < tol)[0]
        if len(candidates) > 0:
            idx = candidates[np.argmax(correlation[candidates])]
            return idx
    # Caso contrário, devolve pico global
    return np.argmax(correlation)

# --- MODO FICHEIRO ---
def recover_cdma_signals(n_tx=TX_COUNT, combined_file='combined_cdma_signal.txt', out_file='recovered_messages_demo4.txt'):
    """
    Lê sinal combinado do ficheiro, faz sincronização e despreading individual para cada user,
    guarda mensagens recuperadas em ficheiro.
    """
    with open(combined_file) as f:
        # Lê só a primeira linha (os samples do sinal)
        signal = np.fromstring(f.readline(), sep=",")
    recovered = []
    for i in range(1, n_tx+1):
        with open(TX_PATTERN.format(i)) as f_tx:
            lines = f_tx.readlines()
            code = np.fromstring(lines[2], sep=",", dtype=int)
        # Para cada user, sincroniza individualmente!
        start = find_sync_position(signal, code, SYNC_PATTERN, expected_start=0, tol=len(signal))
        print(f"User {i}: start={start}")
        start_payload = start + SPREADING_FACTOR * SAMPLING_RATE * SYNC_PREAMBLE_LENGTH
        bits = despread(signal, code, start_payload)
        print(f"User {i}: len(bits)={len(bits)}")
        recovered.append(bits)
    with open(out_file, "w") as f:
        for bits in recovered:
            f.write(",".join(map(str, bits)) + "\n")
    return recovered

# --- MODO MEMÓRIA (simulador) ---
def recover_cdma_signals_mem(signal, codes):
    """
    Igual ao de ficheiro, mas recebe os dados diretamente.
    """
    recovered = []
    for i, code in enumerate(codes):
        start = find_sync_position(signal, code, SYNC_PATTERN, expected_start=0, tol=len(signal))
        print(f"User {i+1}: start={start}")
        start_payload = start + SPREADING_FACTOR * SAMPLING_RATE * SYNC_PREAMBLE_LENGTH
        bits = despread(signal, code, start_payload)
        print(f"User {i+1}: len(bits)={len(bits)}")
        recovered.append(bits)
    return recovered

if __name__ == "__main__":
    recover_cdma_signals()
    print("→ recovered_messages_demo4.txt")
