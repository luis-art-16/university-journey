import numpy as np
from scipy.linalg import hadamard
from config import *
from BER_Meter import SYNC_PATTERN

rng = np.random.default_rng()  # Gerador de números aleatórios moderno para bits, offsets, etc.

def walsh_code(index, order=WALSH_ORDER):
    """
    Devolve o código Walsh (Hadamard) de ordem 'order' e linha 'index'.
    Estes códigos são ortogonais entre si (essencial em CDMA para separar users).
    No CDMA, cada user recebe um código único.
    """
    H = hadamard(order)                # Matriz de Hadamard, linhas são códigos
    code = H[index % order]            # Seleciona a linha (o código)
    code[code == 0] = -1               # Hadamard é {-1,+1} (não pode ser zero)
    return code[:SPREADING_FACTOR].astype(int)  # Só usamos SPREADING_FACTOR elementos

def spread(bits, code):
    """
    Faz o spreading do bitstream, espalhando cada bit pelos chips do código.
    bits: array de 0/1.
    code: código de spreading (-1/+1) com SPREADING_FACTOR elementos.
    """
    assert len(code) == SPREADING_FACTOR
    # Para cada bit: converte 0/1 em -1/+1, repete SPREADING_FACTOR vezes,
    # multiplica pela "tile" do código (para que o código se repita no tamanho certo).
    chips = np.repeat(bits * 2 - 1, SPREADING_FACTOR) * np.tile(code, len(bits))
    return chips

def oversample(chips):
    """
    Repete cada chip SAMPLING_RATE vezes para simular o efeito de amostragem digital/filtragem analógica.
    """
    return np.repeat(chips, SAMPLING_RATE)

def generate_code_idx(n_users, walsh_order, step=3):
    """
    Gera índices de códigos para n_users distintos, evitando usar o código 0 (linha de todos os +1).
    'step=3' previne escolher códigos vizinhos (maior ortogonalidade).
    """
    idx = []
    candidate = 1
    while len(idx) < n_users:
        code = candidate % walsh_order
        if code != 0 and code not in idx:  # Evita código 0 e repetidos
            idx.append(code)
        candidate += step
    return idx

# --- MODO FICHEIRO ---
def generate_transmitters(n_tx=TX_COUNT):
    """
    Gera, para cada utilizador:
      - Bits aleatórios (payload)
      - Junta preâmbulo de sincronização (SYNC_PATTERN)
      - Faz spreading e oversampling
      - Adiciona zeros à frente (LEADING_ZEROS)
      - Guarda 4 linhas por ficheiro:
        Linha 1: samples do sinal transmitido
        Linha 2: bits transmitidos (com sync)
        Linha 3: código de spreading usado
        Linha 4: spreading factor
    """
    CODE_IDX = generate_code_idx(n_tx, WALSH_ORDER, step=3)
    print("CODE_IDX usados:", CODE_IDX)
    for i in range(n_tx):
        bits_payload = rng.integers(0, 2, MESSAGE_LENGTH, dtype=int)  # Gera bits 0/1
        bits = np.concatenate([SYNC_PATTERN, bits_payload])           # Adiciona preâmbulo
        code = walsh_code(CODE_IDX[i], order=WALSH_ORDER)
        chips = spread(bits, code)
        chips = np.concatenate((np.zeros(LEADING_ZEROS, dtype=int), chips))  # Padding inicial
        samples = oversample(chips).astype(float)
        with open(TX_PATTERN.format(i+1), "w") as f:
            f.write(",".join(map("{:.6f}".format, samples)) + "\n")
            f.write(",".join(map(str, bits)) + "\n")
            f.write(",".join(map(str, code)) + "\n")
            f.write(str(SPREADING_FACTOR) + "\n")
    print(f"Gerados {n_tx} ficheiros de transmissores.")

# --- MODO MEMÓRIA (simulador) ---
def generate_transmitters_mem(n_tx=TX_COUNT):
    """
    Idêntico ao de ficheiro, mas tudo em RAM.
    Devolve lista de dicionários para uso direto no simulador.
    """
    CODE_IDX = generate_code_idx(n_tx, WALSH_ORDER, step=3)
    print("CODE_IDX usados:", CODE_IDX)
    transmitters = []
    for i in range(n_tx):
        bits_payload = rng.integers(0, 2, MESSAGE_LENGTH, dtype=int)
        bits = np.concatenate([SYNC_PATTERN, bits_payload])
        code = walsh_code(CODE_IDX[i], order=WALSH_ORDER)
        chips = spread(bits, code)
        chips = np.concatenate((np.zeros(LEADING_ZEROS, dtype=int), chips))
        samples = oversample(chips).astype(float)
        transmitters.append({
            "signal": samples,             # Sinal transmitido (samples)
            "message": bits,               # Bits transmitidos (com sync)
            "code": code,                  # Código usado
            "spreading_factor": SPREADING_FACTOR
        })
    return transmitters

if __name__ == "__main__":
    generate_transmitters()
