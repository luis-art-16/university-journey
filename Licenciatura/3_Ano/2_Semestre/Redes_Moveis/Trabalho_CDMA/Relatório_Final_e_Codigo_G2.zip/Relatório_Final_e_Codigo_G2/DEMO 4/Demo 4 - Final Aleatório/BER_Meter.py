import numpy as np

# Preâmbulo de sincronização: padrão de bits (igual nos Transmitters)
SYNC_PATTERN = np.tile([1, 0, 1, 0, 1, 1, 0, 0], 8)  # 64 bits
SYNC_PREAMBLE_LENGTH = len(SYNC_PATTERN)  # 64

def calculate_ber(original, recovered):
    """
    Calcula BER (Bit Error Rate) entre o original e o recuperado (apenas payload!).
    - Conta número de bits diferentes + bits em falta, normalizado pelo número de bits esperado.
    """
    original_payload = original[SYNC_PREAMBLE_LENGTH:]       # Remove o preâmbulo
    expected_length = len(original_payload)
    if len(recovered) == 0:
        return 1.0
    compare_len = min(len(original_payload), len(recovered))
    errors = (original_payload[:compare_len] != recovered[:compare_len]).sum()
    missing_bits = max(0, expected_length - compare_len)
    total_errors = errors + missing_bits
    return total_errors / expected_length

# --- MODO MEMÓRIA (simulador) ---
def ber_meter_mem(originals, recovereds):
    """
    Calcula o BER para cada utilizador em modo simulador.
    originals: lista de payloads transmitidos
    recovereds: lista de payloads recuperados
    """
    ber_results = {}
    for i, (orig, recv) in enumerate(zip(originals, recovereds), start=1):
        try:
            ber = calculate_ber(orig, recv)
            ber_results[f"Tx{i}"] = ber
        except Exception:
            ber_results[f"Tx{i}"] = float('nan')
    return ber_results

# --- MODO FICHEIRO ---
def ber_meter(transmitter_files, receiver_file, output_filename):
    """
    Lê mensagens transmitidas e recuperadas, calcula BER, guarda em ficheiro e imprime no terminal.
    """
    original_messages = []
    for tx_file in transmitter_files:
        with open(tx_file, 'r') as f:
            lines = f.readlines()
            bits = list(map(int, lines[1].strip().split(',')))
            original_messages.append(np.array(bits))
    with open(receiver_file, 'r') as f:
        recovered_messages = [
            np.array(list(map(int, line.strip().split(','))))
            for line in f
        ]
    ber_results = {}
    for i, (orig, recv) in enumerate(zip(original_messages, recovered_messages), start=1):
        try:
            ber = calculate_ber(orig, recv)
            ber_results[f"Tx{i}"] = ber
            print(f"Tx{i}: BER = {ber:.2%} (excluindo sync)")
        except Exception as e:
            print(f"Tx{i}: Erro no cálculo de BER – {e}")
            ber_results[f"Tx{i}"] = float('nan')
    with open(output_filename, 'w') as f:
        for tx, ber in ber_results.items():
            f.write(f"{tx}: {ber:.6f}\n")
    return ber_results

if __name__ == "__main__":
    # Exemplo para ficheiros
    from config import TX_PATTERN, TX_COUNT
    transmitter_files = [TX_PATTERN.format(i) for i in range(1, TX_COUNT+1)]
    ber_meter(transmitter_files, 'recovered_messages_demo4.txt', 'ber_results.txt')
