import numpy as np, os
from scipy.linalg import hadamard
from config import *
from BER_Meter import SYNC_PATTERN

rng = np.random.default_rng()  # Gerador de números aleatórios (para bits e offsets)

def walsh_code(index, order=WALSH_ORDER):
    """
    Gera um código Walsh/Hadamard de ordem 'order' e devolve a linha 'index'.
    Os códigos de Walsh são ortogonais e usados em CDMA para separar utilizadores.
    """
    H = hadamard(order)            # Cria matriz de Walsh-Hadamard (linhas = códigos)
    code = H[index % order]        # Seleciona o código para o utilizador (modulo para garantir dentro dos limites)
    code[code == 0] = -1           # Em Walsh, valores são -1/+1, nunca zero
    return code[:SPREADING_FACTOR].astype(int)   # Apenas os primeiros SPREADING_FACTOR chips

def spread(bits, code):
    """
    Faz o spreading de cada bit usando o código Walsh (chip por bit).
    bits: array de 0s e 1s
    code: array de -1/+1 com comprimento SPREADING_FACTOR
    """
    assert len(code) == SPREADING_FACTOR
    chips = np.repeat(bits * 2 - 1, SPREADING_FACTOR) * np.tile(code, len(bits))
    return chips

def oversample(chips):
    """
    Sobreamostra cada chip, repetindo cada um SAMPLING_RATE vezes.
    (permite simular filtragem e processamento real)
    """
    return np.repeat(chips, SAMPLING_RATE)

def generate_code_idx(n_users, walsh_order, step=3):
    """
    Gera índices únicos para os códigos Walsh a serem usados pelos utilizadores.
    'step=3' garante que os códigos não se repetem de forma cíclica.
    """
    idx = []
    candidate = 1
    while len(idx) < n_users:
        code = candidate % walsh_order
        if code != 0 and code not in idx:
            idx.append(code)
        candidate += step
    return idx

def generate_transmitters(n_tx=TX_COUNT):
    """
    Gera sinais para todos os transmissores, grava ficheiros.
    Para cada user:
      - Gera bits aleatórios (payload)
      - Adiciona padrão de sincronização (SYNC_PATTERN)
      - Faz spreading e oversampling
      - Guarda ficheiro com:
        [linha 0] amostras do sinal transmitido,
        [linha 1] bits transmitidos (com preâmbulo),
        [linha 2] código Walsh usado,
        [linha 3] spreading factor.
    """
    CODE_IDX = generate_code_idx(n_tx, WALSH_ORDER, step=3)
    print("CODE_IDX usados:", CODE_IDX)
    for i in range(n_tx):
        bits_payload  = rng.integers(0, 2, MESSAGE_LENGTH, dtype=int)
        bits = np.concatenate([SYNC_PATTERN, bits_payload])  # junta sync + mensagem
        code  = walsh_code(CODE_IDX[i])
        chips = spread(bits, code)
        chips = np.concatenate((np.zeros(LEADING_ZEROS, dtype=int), chips))  # padding inicial
        samples = oversample(chips).astype(float)
        with open(TX_PATTERN.format(i+1), "w") as f:
            f.write(",".join(map("{:.6f}".format, samples)) + "\n")
            f.write(",".join(map(str, bits)) + "\n")
            f.write(",".join(map(str, code)) + "\n")
            f.write(str(SPREADING_FACTOR) + "\n")
    print(f"Gerados {n_tx} ficheiros de transmissores.")

# ---- VERSÃO MEMÓRIA (simulador) ----
def generate_transmitters_mem(n_tx=TX_COUNT):
    """
    Versão para simulação em memória.
    Em vez de gravar ficheiros, devolve uma lista de dicionários com os dados dos utilizadores.
    """
    CODE_IDX = generate_code_idx(n_tx, WALSH_ORDER, step=3)
    print("CODE_IDX usados:", CODE_IDX)
    transmitters = []
    for i in range(n_tx):
        bits_payload  = rng.integers(0, 2, MESSAGE_LENGTH, dtype=int)
        bits = np.concatenate([SYNC_PATTERN, bits_payload])
        code  = walsh_code(CODE_IDX[i])
        chips = spread(bits, code)
        chips = np.concatenate((np.zeros(LEADING_ZEROS, dtype=int), chips))
        samples = oversample(chips).astype(float)
        transmitters.append({
            "signal": samples,             # Sinal transmitido
            "message": bits,               # Mensagem (bits com sync)
            "code": code,                  # Código Walsh usado
            "spreading_factor": SPREADING_FACTOR
        })
    return transmitters

if __name__ == "__main__":
    generate_transmitters()
