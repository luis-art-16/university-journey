import numpy as np

# Parâmetros do canal
SNR_dB = 0

# Ler ficheiro do transmissor
with open("transmitted_cdma_signal.txt", "r") as f:
    lines = f.readlines()
    spread_oversampled = np.array(list(map(float, lines[0].strip().split(","))))
    # As restantes linhas ficam guardadas para referência
    # bits = np.array(list(map(int, lines[1].strip().split(","))))
    # code = np.array(list(map(int, lines[2].strip().split(","))))
    # spreading_factor = int(lines[3].strip())
    # sampling_rate = int(lines[4].strip())

# Ruído AWGN
snr_linear = 10 ** (SNR_dB / 10)
power_signal = np.mean(spread_oversampled ** 2)
noise_power = power_signal / snr_linear
noise = np.random.normal(0, np.sqrt(noise_power), spread_oversampled.shape)
received_signal = spread_oversampled + noise

# Guardar ficheiro com sinal ruidoso
with open("received_cdma_signal.txt", "w") as f:
    # Linha 1: sinal recebido (Rx)
    f.write(",".join(map(str, received_signal)) + "\n")
    # Linha 2: sinal transmitido (Tx) para comparação
    f.write(",".join(map(str, spread_oversampled)) + "\n")
