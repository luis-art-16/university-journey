import numpy as np
import matplotlib.pyplot as plt

# Lê sinais do canal
with open("received_cdma_signal.txt", "r") as f:
    lines = f.readlines()
    received_signal = np.array(list(map(float, lines[0].strip().split(","))))
    tx_signal = np.array(list(map(float, lines[1].strip().split(","))))

plt.figure(figsize=(12,3))
plt.plot(tx_signal[:200], label="Transmissor (Tx)")
plt.plot(received_signal[:200], label="Recebido (Rx, com ruído)")
plt.title("Comparação: Sinal Transmitido vs. Sinal Recebido (Demo 1)\n(SNR = 0 dB, primeiros 200 samples)")
plt.xlabel("Amostra")
plt.ylabel("Amplitude")
plt.legend()
plt.tight_layout()
plt.show()
