import numpy as np

# Parâmetros
message_length = 200
spreading_factor = 16
sampling_rate = 5

# Mensagem binária aleatória
bits = np.random.randint(0, 2, message_length)

# Walsh-Hadamard (1º código)
def hadamard_matrix(n):
    assert n > 0 and ((n & (n - 1)) == 0)
    H = np.array([[1]])
    while H.shape[0] < n:
        H = np.vstack((np.hstack((H, H)), np.hstack((H, -H))))
    return H

walsh = hadamard_matrix(spreading_factor)
code = walsh[0]

# Mapear bits para -1/+1
chips = 2 * bits - 1

# Espalhamento
spread = np.repeat(chips, spreading_factor) * np.tile(code, message_length)

# Sobreamostragem
spread_oversampled = np.repeat(spread, sampling_rate)

# Normalização [-1, 1]
spread_oversampled = spread_oversampled / np.max(np.abs(spread_oversampled))

# Guardar ficheiro (transmitted_cdma_signal.txt)
with open("transmitted_cdma_signal.txt", "w") as f:
    # Linha 1: sinal transmitido (amostras)
    f.write(",".join(map(str, spread_oversampled)) + "\n")
    # Linha 2: bits transmitidos
    f.write(",".join(map(str, bits)) + "\n")
    # Linha 3: código de espalhamento
    f.write(",".join(map(str, code)) + "\n")
    # Linha 4: spreading factor
    f.write(str(spreading_factor) + "\n")
    # Linha 5: sampling rate
    f.write(str(sampling_rate) + "\n")
