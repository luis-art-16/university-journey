import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.locks.*;

public class Cliente {
    private final String serverAddress;
    private final int serverPort;
    private Socket socket;
    private DataInputStream input;
    private DataOutputStream output;
    private final ReentrantLock lock = new ReentrantLock();

    public Cliente(String address, int port) throws IOException {
        this.serverAddress = address;
        this.serverPort = port;
        connect();
    }

    private void connect() throws IOException {
        socket = new Socket(serverAddress, serverPort);
        input = new DataInputStream(socket.getInputStream());
        output = new DataOutputStream(socket.getOutputStream());
    }

    public boolean register(String username, String password) throws IOException {
        lock.lock();
        try {
            output.writeInt(6); // Código da operação de registro
            writeString(output, username);
            writeString(output, password);
            String response = readString(input);
            return response.contains("Registro bem-sucedido");
        } finally {
            lock.unlock();
        }
    }

    public boolean authenticate(String username, String password) throws IOException {
        lock.lock();
        try {
            output.writeInt(7); // Código da operação de autenticação
            writeString(output, username);
            writeString(output, password);
            String response = readString(input);
            return response.contains("Autenticação bem-sucedida");
        } finally {
            lock.unlock();
        }
    }

    public void put(String key, byte[] value) throws IOException {
        lock.lock();
        try {
            output.writeInt(1); // Código da operação put
            writeString(output, key);
            writeBytes(output, value);
            System.out.println(readString(input));
        } finally {
            lock.unlock();
        }
    }

    public byte[] get(String key) throws IOException {
        lock.lock();
        try {
            output.writeInt(2); // Código da operação get
            writeString(output, key);
            int length = input.readInt();
            if (length == -1) return null; // Key não encontrada
            return readBytes(input, length);
        } finally {
            lock.unlock();
        }
    }

    public void multiPut(Map<String, byte[]> pairs) throws IOException {
        lock.lock();
        try {
            output.writeInt(3); // Código da operação multiPut
            output.writeInt(pairs.size());
            for (Map.Entry<String, byte[]> entry : pairs.entrySet()) {
                writeString(output, entry.getKey());
                writeBytes(output, entry.getValue());
            }
            System.out.println(readString(input));
        } finally {
            lock.unlock();
        }
    }

    public Map<String, byte[]> multiGet(Set<String> keys) throws IOException {
        lock.lock();
        try {
            output.writeInt(4); // Código da operação multiGet
            output.writeInt(keys.size());
            for (String key : keys) {
                writeString(output, key);
            }
            int numResults = input.readInt();
            Map<String, byte[]> results = new HashMap<>();
            for (int i = 0; i < numResults; i++) {
                String key = readString(input);
                int length = input.readInt();
                results.put(key, readBytes(input, length));
            }
            return results;
        } finally {
            lock.unlock();
        }
    }

    public byte[] getWhen(String key, String keyCond, byte[] valueCond) throws IOException {
        lock.lock();
        try {
            output.writeInt(5); // Código da operação getWhen
            writeString(output, key);
            writeString(output, keyCond);
            writeBytes(output, valueCond);
            int length = input.readInt();
            if (length == -1) return null; // Key não encontrada
            return readBytes(input, length);
        } finally {
            lock.unlock();
        }
    }

    public void close() throws IOException {
        lock.lock();
        try {
            output.writeInt(0); // Código para encerrar sessão
            socket.close();
        } finally {
            lock.unlock();
        }
    }

    // Métodos auxiliares para manipulação de strings e bytes
    private String readString(DataInputStream input) throws IOException {
        int length = input.readInt();
        byte[] data = new byte[length];
        input.readFully(data);
        return new String(data, "UTF-8");
    }

    private void writeString(DataOutputStream output, String value) throws IOException {
        byte[] data = value.getBytes("UTF-8");
        output.writeInt(data.length);
        output.write(data);
    }

    private byte[] readBytes(DataInputStream input, int length) throws IOException {
        byte[] data = new byte[length];
        input.readFully(data);
        return data;
    }

    private void writeBytes(DataOutputStream output, byte[] data) throws IOException {
        output.writeInt(data.length);
        output.write(data);
    }
}


