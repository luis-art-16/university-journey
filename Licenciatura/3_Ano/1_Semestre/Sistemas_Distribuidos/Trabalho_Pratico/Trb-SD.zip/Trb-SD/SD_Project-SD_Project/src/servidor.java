import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.locks.*;



public class servidor {
    private final Map<String, String> users = new HashMap<>(); // Stores users and passwords
    private final Map<String, byte[]> store = new HashMap<>();
    private final ReentrantLock userLock = new ReentrantLock();
    private final ReentrantLock sessionLock = new ReentrantLock();
    private final Condition sessionCondition = sessionLock.newCondition();
    private final ReentrantReadWriteLock storeLock = new ReentrantReadWriteLock();
    private final Lock readLock = storeLock.readLock();
    private final Lock writeLock = storeLock.writeLock();
    private final Condition storeCondition = writeLock.newCondition(); // Condition for store changes

    private static final int PORT = 1234;
    private static final int MAX_SESSIONS = 10;
    private int activeSessions = 0;

    public static void main(String[] args) {
        new servidor().startServer();
    }

    public void startServer() {
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Servidor iniciado na porta " + PORT);

            while (true) {
                sessionLock.lock();
                try {
                    while (activeSessions >= MAX_SESSIONS) {
                        sessionCondition.await(); // Wait until there is space for new sessions
                    }
                    Socket clientSocket = serverSocket.accept(); // Passar isto para cima, criar um socket antes da espera
                    activeSessions++;
                    new ClientHandler(clientSocket).start();
                } finally {
                    sessionLock.unlock();
                }
            }
        } catch (IOException | InterruptedException e) {
            System.out.println("Erro ao iniciar o servidor: " + e.getMessage());
        }
    }

    private class ClientHandler extends Thread {
        private final Socket socket;

        public ClientHandler(Socket socket) {
            this.socket = socket;
        }

        @Override
        public void run() {
            try (DataInputStream input = new DataInputStream(socket.getInputStream());
                 DataOutputStream output = new DataOutputStream(socket.getOutputStream())) {

                boolean authenticated = false;
                String username = null;

                while (true) {
                    int command = input.readInt();

                    switch (command) {
                        case 6: // Register
                            username = readString(input);
                            String password = readString(input);

                            userLock.lock();
                            try {
                                if (users.containsKey(username)) {
                                    writeString(output, "Falha: usuário já registrado.");
                                } else {
                                    users.put(username, password);
                                    writeString(output, "Registro bem-sucedido");
                                }
                            } finally {
                                userLock.unlock();
                            }
                            break;

                        case 7: // Authenticate
                            username = readString(input);
                            password = readString(input);

                            userLock.lock();
                            try {
                                if (password.equals(users.get(username))) {
                                    authenticated = true;
                                    writeString(output, "Autenticação bem-sucedida");
                                } else {
                                    writeString(output, "Falha na autenticação");
                                }
                            } finally {
                                userLock.unlock();
                            }
                            break;

                        case 1: // put
                            if (!authenticated) {
                                writeString(output, "Erro: não autenticado.");
                                break;
                            }
                            String key = readString(input);
                            byte[] value = readBytes(input);

                            writeLock.lock();
                            try {
                                store.put(key, value);
                                storeCondition.signalAll(); // Notify threads waiting on the store
                                writeString(output, "Valor inserido com sucesso.");
                            } finally {
                                writeLock.unlock();
                            }
                            break;

                        case 2: // get
                            if (!authenticated) {
                                writeString(output, "Erro: não autenticado.");
                                break;
                            }
                            key = readString(input);

                            readLock.lock();
                            try {
                                byte[] result = store.get(key);
                                if (result != null) {
                                    writeBytes(output, result);
                                } else {
                                    output.writeInt(-1); // Key not found
                                }
                            } finally {
                                readLock.unlock();
                            }
                            break;

                        case 3: // multiPut
                            if (!authenticated) {
                                writeString(output, "Erro: não autenticado.");
                                break;
                            }
                            int numPairs = input.readInt();
                            Map<String, byte[]> pairs = new HashMap<>();
                            for (int i = 0; i < numPairs; i++) {
                                String multiKey = readString(input);
                                byte[] multiValue = readBytes(input);
                                pairs.put(multiKey, multiValue);
                            }

                            writeLock.lock();
                            try {
                                store.putAll(pairs);
                                storeCondition.signalAll(); // Notify threads waiting on the store
                                writeString(output, "Múltiplos valores inseridos com sucesso.");
                            } finally {
                                writeLock.unlock();
                            }
                            break;

                        case 4: // multiGet
                            if (!authenticated) {
                                writeString(output, "Erro: não autenticado.");
                                break;
                            }
                            int numKeys = input.readInt();
                            Set<String> keys = new HashSet<>();
                            for (int i = 0; i < numKeys; i++) {
                                keys.add(readString(input));
                            }

                            Map<String, byte[]> results = new HashMap<>();
                            readLock.lock();
                            try {
                                for (String multiKey : keys) {
                                    byte[] keyValue = store.get(multiKey);
                                    if (keyValue != null) {  //
                                        results.put(multiKey, keyValue);
                                    }
                                }
                                output.writeInt(results.size());
                                for (Map.Entry<String, byte[]> entry : results.entrySet()) {
                                    writeString(output, entry.getKey());
                                    writeBytes(output, entry.getValue());
                                }
                            } finally {
                                readLock.unlock();
                            }
                            break;

                        case 5: // getWhen
                            if (!authenticated) {
                                writeString(output, "Erro: não autenticado.");
                                break;
                            }
                            String keyMain = readString(input);
                            String keyCond = readString(input);
                            byte[] condValue = readBytes(input);

                            readLock.lock();
                            try {
                                while (!store.containsKey(keyCond) || !Arrays.equals(store.get(keyCond), condValue)) {
                                    try {
                                        storeCondition.await(); // Wait until the condition is met
                                    } catch (InterruptedException e) {
                                        Thread.currentThread().interrupt();
                                        writeString(output, "Erro ao aguardar condição.");
                                        return;
                                    }
                                }

                                byte[] mainValue = store.get(keyMain);
                                if (mainValue != null) {
                                    writeBytes(output, mainValue);
                                } else {
                                    output.writeInt(-1); // Main key not found
                                }
                                //
                            } finally {
                                readLock.unlock();
                            }
                            break;

                        case 0: // Logout
                            authenticated = false;
                            writeString(output, "Sessão encerrada.");
                            return;

                        default:
                            writeString(output, "Comando desconhecido.");
                    }
                }
            } catch (IOException e) {
                System.out.println("Erro de comunicação com o cliente: " + e.getMessage());
            } finally {
                sessionLock.lock();
                try {
                    activeSessions--;
                    sessionCondition.signalAll(); // Notify threads waiting for session space
                } finally {
                    sessionLock.unlock();
                }
            }
        }
    }

    // Helper methods for strings and bytes
    private String readString(DataInputStream input) throws IOException {
        int length = input.readInt();
        byte[] data = new byte[length];
        input.readFully(data);
        return new String(data, "UTF-8");
    }

    private void writeString(DataOutputStream output, String value) throws IOException {
        byte[] data = value.getBytes("UTF-8");
        output.writeInt(data.length);
        output.write(data);
    }

    private byte[] readBytes(DataInputStream input) throws IOException {
        int length = input.readInt();
        byte[] data = new byte[length];
        input.readFully(data);
        return data;
    }

    private void writeBytes(DataOutputStream output, byte[] data) throws IOException {
        output.writeInt(data.length);
        output.write(data);
    }
}

//out.flush
