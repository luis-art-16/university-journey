import java.io.IOException;
import java.util.*;

public class utilizador {
    private static Cliente client;

    public static void main(String[] args) {
        try {
            client = new Cliente( "localhost", 1234);
            Scanner scanner = new Scanner(System.in);

            System.out.print("Registar (R) ou Login (L): ");
            String action = scanner.nextLine().toUpperCase();
            boolean isAuthenticated = false;

            if ("R".equals(action)) {
                System.out.print("Novo nome de utilizador: ");
                String newUsername = scanner.nextLine();
                System.out.print("Nova senha: ");
                String newPassword = scanner.nextLine();
                isAuthenticated = client.register(newUsername, newPassword);
                if (isAuthenticated) {
                    System.out.println("Registro bem-sucedido. Faça login.");
                }
            }

            if (!isAuthenticated) {
                System.out.print("Nome de utilizador: ");
                String username = scanner.nextLine();
                System.out.print("Senha: ");
                String password = scanner.nextLine();
                isAuthenticated = client.authenticate(username, password);
            }

            if (isAuthenticated) {
                System.out.println("Autenticação bem-sucedida.");

                boolean running = true;
                while (running) {
                    showMenu();
                    int choice = scanner.nextInt();
                    scanner.nextLine(); // Consome o \n

                    switch (choice) {
                        case 1 -> handlePut(scanner);
                        case 2 -> handleGet(scanner);
                        case 3 -> handleMultiPut(scanner);
                        case 4 -> handleMultiGet(scanner);
                        case 5 -> handleGetWhen(scanner);
                        case 0 -> running = false;
                        default -> System.out.println("Opção inválida.");
                    }
                }
            } else {
                System.out.println("Falha no login ou registo.");
            }

            client.close();
        } catch (IOException e) {
            System.out.println("Erro na comunicação com o servidor: " + e.getMessage());
        }
    }

    private static void showMenu() {
        System.out.println("\n--- Menu ---");
        System.out.println("1. Inserir valor (put)");
        System.out.println("2. Consultar valor (get)");
        System.out.println("3. Inserir múltiplos valores (multiPut)");
        System.out.println("4. Consultar múltiplos valores (multiGet)");
        System.out.println("5. Leitura condicional (getWhen)");
        System.out.println("0. Sair");
        System.out.print("Escolha uma opção: ");
    }

    private static void handlePut(Scanner scanner) throws IOException {
        System.out.print("Chave: ");
        String key = scanner.nextLine();
        System.out.print("Valor: ");
        byte[] value = scanner.nextLine().getBytes();
        client.put(key, value);
    }

    private static void handleGet(Scanner scanner) throws IOException {
        System.out.print("Chave: ");
        String key = scanner.nextLine();
        byte[] value = client.get(key);
        if (value != null) {
            System.out.println("Valor: " + new String(value));
        } else {
            System.out.println("Chave não encontrada.");
        }
    }

    private static void handleMultiPut(Scanner scanner) throws IOException {
        System.out.println("Digite pares de chave-valor separados por vírgula (ex: chave1:valor1,chave2:valor2):");
        String[] pairs = scanner.nextLine().split(",");
        Map<String, byte[]> map = new HashMap<>();
        for (String pair : pairs) {
            String[] kv = pair.split(":");
            if (kv.length == 2) {
                map.put(kv[0], kv[1].getBytes());
            }
        }
        client.multiPut(map);
    }

    private static void handleMultiGet(Scanner scanner) throws IOException {
        System.out.println("Digite as chaves separadas por vírgula:");
        String[] keys = scanner.nextLine().split(",");
        Set<String> keySet = new HashSet<>(Arrays.asList(keys));
        Map<String, byte[]> results = client.multiGet(keySet);
        results.forEach((k, v) -> System.out.println("Chave: " + k + ", Valor: " + new String(v)));
    }

    private static void handleGetWhen(Scanner scanner) throws IOException {
        System.out.print("Chave principal: ");
        String key = scanner.nextLine();
        System.out.print("Chave condicional: ");
        String keyCond = scanner.nextLine();
        System.out.print("Valor condicional: ");
        byte[] valueCond = scanner.nextLine().getBytes();

        byte[] value = client.getWhen(key, keyCond, valueCond);
        if (value != null) {
            System.out.println("Valor: " + new String(value));
        } else {
            System.out.println("Condição não satisfeita ou chave não encontrada.");
        }
    }

}
