// SLIDE 33
//
// Programa que escreve num ficheiro os argumentos do programa, 
// um argumento  por linha, o nome do ficheiro é igual ao 1º 
// argumento com o qual o programa foi chamado


#include <stdio.h>

int main(int argc, char *argv[])
{
   char* nomeF = (argc > 1) ? argv[1] : "resultado.txt";
   FILE* f;
   if ((f = fopen(nomeF, "w")) == NULL) {
      fprintf(stderr, "Erro ao abrir o ficheiro %s\n", nomeF);
      return -1;
   }
   fprintf(f, "Programa chamado com %d argumentos:\n", argc);
   for (int i = 0; i < argc; ++i) {
      fprintf(f, "argv[%d]='%s'\n", i, argv[i]);
   }
   if (fclose(f) == EOF) {
      fprintf(stderr, "Erro ao fechar o ficheiro %s\n", nomeF);
      return -1;
   }
   return 0;
}
