// SLIDES 36 e 37
//
// Copiar um ficheiro para outro, um bloco de 4096 carateres 
// de cada vez e no modo binário

#include <stdio.h>
#include <stdlib.h>

#define TAM_BUFFER 4096

void terminarEmErro	(char* msg) {
	fprintf(stderr,	"%s\n", msg);
	exit(-2);
}

int main(int argc, char* argv[])
{
	if (argc != 3) {
		printf("Ajuda: copiar <fileIn> <fileOut>\n");
		return -1;
	}

	FILE* fpIn = fopen(argv[1],"rb");
	if (!fpIn) {
		terminarEmErro(argv[1]);
	}

	FILE* fpOut = fopen(argv[2],"wb");
	if (!fp_out) {
		terminarEmErro(argv[2]);
	}

	char buffer[TAM_BUFFER];

	while (1) {

		int nbytes = fread(buffer,sizeof(char),TAM_BUFFER, fpIn);
		if (ferror(fpIn)) {
			terminarEmErro(argv[1]);
		}

		fwrite(buffer, sizeof(char), nbytes, fpOut); // nbytes e não TAM_BUFFER
		if (feof(fpOut) || ferror(fpOut)) {
			terminarEmErro(argv[2]);
		}
		if (feof(fpIn)) {
			break;
		}
	}

	fclose(fpIn);
	fclose(fpOut);

	return 0;
}
