// SLIDE 27
//
// Programa que lê byte a byte de stdin e
//          escreve byte a byte em stdout

#include <stdio.h>

int main(void)
{
   int c;
   int bytes = 0;

   while ((c = getc(stdin)) != EOF) {
      if (putc(c, stdout) == EOF) {
         fprintf(stderr, "Erro em putc");
         break;
      }
      bytes += 1;
   }

   double mb = bytes / (1024 * 1024);
   fprintf(stderr, "%.2lf MB\n", mb);

   return 0;
}
