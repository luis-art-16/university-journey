// SLIDE 32
//
// Leitura formatada a partir de um ficheiro texto.
// Para testar o programa utiliza-se o ficheiro '10-scanf.txt'.

#include <stdio.h>

int main(int argc, char *argv[]) 
{
   char *nomef = "10-scanf.txt";
   FILE *f;
   if ((f = fopen(nomef, "r")) == NULL) {
      fprintf(stderr, "Erro ao abrir o ficheiro '%s'\n", nomef);
      return -1;
   }

   char   str[10];
   int    i        = -1;
   double d        = -1.0;
   int    line     = 1;

   while (feof(f) == 0) {

      int r = fscanf(f, "%9s %d %lf\n", str, &i, &d);

      if (r == 3) {
         fprintf(stdout, "Linha %d com %d items lidos -> s: %9s  i: %11i  d: %lf\n", line, r, str, i, d);
      }
      else {
         fprintf(stdout, "\n");
         fprintf(stdout, "Aviso: Linha %d com %d items lidos -> s: %9s  i: %11i  d: %lf\n", line, r, str, i, d);
         break;
      }
      line++;
   }

   if (fclose(f) == EOF) {
      fprintf(stderr, "Erro ao fechar o ficheiro '%s'\n", nomef);
      return -1;
   }

   return 0;
}
