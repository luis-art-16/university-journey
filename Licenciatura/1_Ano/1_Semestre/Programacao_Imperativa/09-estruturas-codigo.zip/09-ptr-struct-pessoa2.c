
// SLIDE 32
// Apontadores para estruturas

#include <stdio.h>

#define TAM 100

int main(void) 
{

	struct pessoa {
		char  nome[TAM];
		int   altura;
		int   peso;
		char  genero;
		int   numCC;
		short idade;
	} pessoa1, *p;

	p = &pessoa1;

	// Vamos substituir '(*p).membro' por 'p->membro'

	// (*p).altura = 168;
	// (*p).idade  = 25;

	p->altura = 168;
	p->idade  = 25;

	// Acesso aos membros da estrutura 'pessoa1' usando o apontador 'p'

	printf("(via apontador e operador ->) Altura: %d\n",  p->altura);
	printf("(via apontador e operador ->) Idade:  %hd\n", p->idade);

	// Acesso direto aos membros da estrutura 'pessoa1'

	printf("Altura: %d\n",  pessoa1.altura); 
	printf("Idade:  %hd\n", pessoa1.idade);

	return 0;
}
