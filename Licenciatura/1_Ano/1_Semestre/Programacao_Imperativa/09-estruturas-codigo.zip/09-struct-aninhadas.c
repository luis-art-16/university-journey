
// SLIDES 17-18
// Estrutura em que um ou mais membros são estruturas

#include <stdio.h>

#define TAM 100

int main(void) 
{

	struct data {
		unsigned short mes;
		unsigned short dia;
		unsigned int   ano;
	};

	// Uma estrutura pode conter membros que são estruturas

	struct pessoa_com_inicio {
		struct data inicio; // este membro é uma estrutura
		char   nome[TAM];
		int    altura;
		int    peso;
		char   genero;
		int    numCC;
		short  idade;
	};

	// Aceder aos membros de uma estrutura incluída dentro de outra estrutura

	struct pessoa_com_inicio p1;

	p1.inicio.mes = 10;
	p1.inicio.dia = 19;
	p1.inicio.ano = 2022;

	printf("CONTEUDO DO MEMBRO inicio DA ESTRUTURA p1 (dia/mes/ano): %hu %hu %u\n",
		p1.inicio.dia, p1.inicio.mes, p1.inicio.ano);

	return 0;
}
