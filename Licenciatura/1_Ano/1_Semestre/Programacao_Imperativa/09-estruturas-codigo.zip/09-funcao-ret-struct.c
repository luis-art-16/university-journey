
// SLIDE 28
// Função que devolve uma estrutura

#include <stdio.h>
#include <string.h>

#define TAM 100

struct pessoa {
	char  nome[TAM];
	int   altura;
	int   peso;
	char  genero;
	int   numCC;
	short idade;
};

struct pessoa LerPessoa();
void escrevePessoa(struct pessoa);

int main(void) 
{
	struct pessoa pessoa1 = LerPessoa();

	escrevePessoa(pessoa1);

	return 0;
}

// Função que devolve uma estrutura

struct pessoa LerPessoa()
{
	struct pessoa nova;

	printf("Nome:   ");
	fgets(nova.nome,TAM,stdin);
	size_t len = strlen(nova.nome); 
	nova.nome[len-1] = '\0'; // remover o '\n' no fim do nome, que o fgets lê

	printf("Genero: ");	nova.genero=getchar();

	printf("Altura: "); scanf("%d",&(nova.altura));

	printf("Peso:   "); scanf("%d",&(nova.peso));
	
	printf("CC:     "); scanf("%d",&(nova.numCC));

	printf("Idade   "); scanf("%hd",&(nova.idade));

	return nova;
}

void escrevePessoa( struct pessoa p )
{
	printf("\nPESSOA\n");
	printf("  NOME:   %s\n",  p.nome);
	printf("  ALTURA: %d\n",  p.altura);
	printf("  PESO:   %d\n",  p.peso);
	printf("  GENERO: %c\n",  p.genero);
	printf("  CC:     %d\n",  p.numCC);
	printf("  IDADE:  %hd\n", p.idade);
}
