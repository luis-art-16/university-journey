
// SLIDE 37
// Tipo de dados enumerado

#include <stdio.h>

int main(void) 
{
	enum naipe { ESPADAS, PAUS, COPAS, OUROS } n1, n2;
	n1 = COPAS;
	printf("Naipe: %d\n",n1); // Qual o valor escrito no terminal? Porquê?
}
