
// SLIDE 20
// Array de estruturas

#include <stdio.h>

#define TAM 100

int main(void) 
{

	struct pessoa {
		char  nome[TAM];
		int   altura;
		int   peso;
		char  genero;
		int   numCC;
		short idade;
	};

	// Um array de estruturas de tamanho 100

	struct pessoa pessoas[100];

	// Aceder aos membros de um elemento dum array de estruturas
	
	strcpy(pessoas[0].nome, "Anita");
	
	strcpy(pessoas[1].nome, "Joana");

	strcpy(pessoas[2].nome, "Pedro");
	pessoas[2].altura = 178;
	pessoas[2].peso   = 85;
	pessoas[2].idade  = 21;

	printf("PESSOAS[2]:\n");
	printf("  Nome:    %s\n",  pessoas[2].nome);
	printf("  Altura:  %d\n",  pessoas[2].altura); 
	printf("  Peso:    %d\n",  pessoas[2].peso);
	printf("  Idade:   %hd\n", pessoas[2].idade);

	return 0;
}
