
// SLIDE 26
// Passar uma estrutura como argumento a uma função

#include <stdio.h>

#define TAM 100

struct pessoa {
	char  nome[TAM];
	int   altura;
	int   peso;
	char  genero;
	int   numCC;
	short idade;
};

void escrevePessoa (struct pessoa );

int main(void) 
{
	struct pessoa pessoa1 =
	{
		.nome    = "Dos Santos",
		.altura  = 175,
		.peso 	 = 82,
		.genero	 = 'M'
	} ;

	escrevePessoa(pessoa1);

	return 0;
}

// Função que recebe uma estrutura como argumento

void escrevePessoa( struct pessoa p )
{
	printf("\nPESSOA\n");
	printf("  NOME:   %s\n",  p.nome);
	printf("  ALTURA: %d\n",  p.altura);
	printf("  PESO:   %d\n",  p.peso);
	printf("  GENERO: %c\n",  p.genero);
	printf("  CC:     %d\n",  p.numCC);  // membro não inicializado
	printf("  IDADE:  %hd\n", p.idade);  // membro não inicializado
}
