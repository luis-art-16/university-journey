
// SLIDES 13-15

#include <stdio.h>

#define TAM 100

int main(void) 
{

	struct pessoa {
		char  nome[TAM];
		int   altura;
		int   peso;
		char  genero;
		int   numCC;
		short idade;
	};

	// Estruturas não inicializadas
	struct pessoa pessoa1, pessoa2;

	// Estrutura completamente inicializada
	struct pessoa pessoa3 =	{"Joana", 168, 65, 'F', 7654321, 20};

	// Estrutura parcialmente inicializada (versão 1)
	struct pessoa pessoa4 = {"Joana", 168, 65, 'F'};

	// Estrutura parcialmente inicializada (versão 2)
	struct pessoa pessoa5 = 
	{
		.nome   = "Joana",
		.altura = 168,
		.genero = 'F',
		.numCC  = 7654321
	};

	// Atribuir um valor a um membro da estrutura 'pessoa3'
	pessoa3.peso = 70;

	// Atribuir (copiar) a estrutura 'pessoa3' à (para a) estrutura 'pessoa1'
	pessoa1 = pessoa3;

	// Atribuir em simultâneo valores a todos os membros duma estrutura
	pessoa2 = (struct pessoa) {"Maria", 172, 74, 'F', 9876532, 19 };

	// MOSTRAR CONTEÚDO DAS ESTRUTURAS

	printf("\nPESSOA1\n  NOME:   %s\n  ALTURA: %d\n  PESO:   %d\n  GENERO: %c\n  CC:     %d\n  IDADE:  %hd\n", 
		pessoa1.nome, pessoa1.altura, pessoa1.peso, pessoa1.genero, pessoa1.numCC, pessoa1.idade);

	printf("\nPESSOA2\n  NOME:   %s\n  ALTURA: %d\n  PESO:   %d\n  GENERO: %c\n  CC:     %d\n  IDADE:  %hd\n", 
		pessoa2.nome, pessoa2.altura, pessoa2.peso, pessoa2.genero, pessoa2.numCC, pessoa2.idade);

	printf("\nPESSOA3\n  NOME:   %s\n  ALTURA: %d\n  PESO:   %d\n  GENERO: %c\n  CC:     %d\n  IDADE:  %hd\n", 
		pessoa3.nome, pessoa3.altura, pessoa3.peso, pessoa3.genero, pessoa3.numCC, pessoa3.idade);

	printf("\nPESSOA4\n  NOME:   %s\n  ALTURA: %d\n  PESO:   %d\n  GENERO: %c\n  CC:     %d\n  IDADE:  %hd\n", 
		pessoa4.nome, pessoa4.altura, pessoa4.peso, pessoa4.genero, pessoa4.numCC, pessoa4.idade);

	printf("\nPESSOA5\n  NOME:   %s\n  ALTURA: %d\n  PESO:   %d\n  GENERO: %c\n  CC:     %d\n  IDADE:  %hd\n", 
		pessoa5.nome, pessoa5.altura, pessoa5.peso, pessoa5.genero, pessoa5.numCC, pessoa5.idade);

	return 0;
}
