
// SLIDE 33
// Apontadores para estruturas

#include <stdio.h>
#include <string.h>

#define TAM 100

int main(void) 
{

	struct pessoa {
		char  nome[TAM];
		int   altura;
		int   peso;
		char  genero;
		int   numCC;
		short idade;
		struct pessoa *pai;
		struct pessoa *mae;
	} pessoas[100], *p1;

	strcpy(pessoas[22].nome, "Manuel");
	pessoas[22].idade = 68;
	strcpy(pessoas[45].nome, "Helena");
	pessoas[45].idade = 62;

	p1 = & pessoas[1];
	p1->pai = & pessoas[22];
	p1->mae = & pessoas[45];

	if ( p1->pai->idade > 66)
		printf("O pai %s esta' reformado\n",p1->pai->nome);
	else
		printf("O pai %s trabalha\n",p1->pai->nome);

	if ( p1->mae->idade > 66)
		printf("A mae %s esta' reformada\n",p1->mae->nome);
	else
		printf("A mae %s trabalha\n",p1->mae->nome);

	return 0;
}
