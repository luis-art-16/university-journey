
// SLIDE 7
// Declaração duma estrutura e acesso aos seus membros

#include <stdio.h>

#define TAM 100

int main(void) 
{

	struct pessoa {
		char  nome[TAM];
		int   altura;
		int   peso;
		char  genero;
		int   numCC;
		short idade;
	};

	struct pessoa pessoa1;

	pessoa1.altura 	= 175;
	pessoa1.peso 	= 82;
	pessoa1.genero	= 'M';

	printf("Altura:  %d\n", pessoa1.altura); 
	printf("Peso:    %d\n", pessoa1.peso);
	printf("Genero:  %c\n", pessoa1.genero);

	return 0;
}
