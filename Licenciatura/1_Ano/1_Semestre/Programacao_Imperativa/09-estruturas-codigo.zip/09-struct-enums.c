
// SLIDE 38
// Tipo de dados enumerado

#include <stdio.h>

typedef enum {DOMINGO, SEGUNDA, TERCA, QUARTA, QUINTA, SEXTA, SABADO} DiaSemana;

int main(void)
{
	DiaSemana ds;

	char *diasemana[] = {"Domingo", "Segunda-feira", "Terca-feira",
		 "Quarta-feira", "Quinta-feira", "Sexta-feira", "Sabado" };

	// Será que podemos usar o tipo enumerado como índice do array diasemana?

	// Consultemos a codificação das etiquetas:

	printf("Etiqueta 'DOMINGO': %d\n", DOMINGO);
	printf("Etiqueta 'SEGUNDA': %d\n", SEGUNDA);
	printf("Etiqueta 'TERCA':   %d\n", TERCA);
	printf("Etiqueta 'QUARTA':  %d\n", QUARTA);
	printf("Etiqueta 'QUINTA':  %d\n", QUINTA);
	printf("Etiqueta 'SEXTA':   %d\n", SEXTA);
	printf("Etiqueta 'SABADO':  %d\n", SABADO);

	// Atribuir valores à variável 'ds' do tipo enumerado

	ds = DOMINGO;
	ds = SEGUNDA;
	ds = TERCA;
	ds = QUARTA;
	ds = QUINTA;
	ds = SEXTA;
	ds = SABADO;

	// Vamos então usar o tipo enumerado para indexar o array diasemana

	printf("Para aceder ao nome de Dom: %s\n", diasemana[DOMINGO]);
	printf("Para aceder ao nome de Seg: %s\n", diasemana[SEGUNDA]);
	printf("Para aceder ao nome de Ter: %s\n", diasemana[TERCA]);
	printf("Para aceder ao nome de Qua: %s\n", diasemana[QUARTA]);
	printf("Para aceder ao nome de Qui: %s\n", diasemana[QUINTA]);
	printf("Para aceder ao nome de Sex: %s\n", diasemana[SEXTA]);
	printf("Para aceder ao nome de Sab: %s\n", diasemana[SABADO]);

	return 0;
}
