
// SLIDE 6
//
// Tentar utilizar um apontador para alterar um literal do tipo string.

#include <stdio.h>

int main(void)
{
    char *p = "123";
    *p = '0'; // Esta instrução não é recomendável!!!! Porquê?

    printf("Literal p alterado: '%s'\n", p);

    return 0;
}