
// SLIDE 13
//
// Limitar o número máximo de carateres a ler com scanf, para
// evitar que se ultrapasse o tamanho do array onde são guardados
// os carateres lidos.

#include <stdio.h>

int main(void) 
{
   char str0[9] = "PI2023"; // 1 caratere para o '\0'
   char str1[5];            // 4 carateres mais um '\0'

   printf("String str0: '%s'\n", str0);
   printf("Introduza mais de 4 carateres para tentar provocar um erro: ");
   scanf("%4s", str1);
   printf("Introduziu a string '%s'\n",      str1);
   printf("Novamente a string str0: '%s'\n", str0);

   return 0;
}
