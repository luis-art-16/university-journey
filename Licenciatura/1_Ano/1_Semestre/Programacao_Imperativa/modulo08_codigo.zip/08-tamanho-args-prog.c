
// SLIDE 23
//
// Determinar o tamanho de strings.

#include <stdio.h>
#include <string.h>

int obterTamanho(char *);

int main(int argc, char *argv[])
{
    printf("Argumentos do programa e seu tamanho:\n");
    for (int i=0; i<argc; ++i) {
        printf("  argv[%i]: %s  tamanho=%i  strlen=%lu\n", i, 
            argv[i], obterTamanho(argv[i]), strlen(argv[i]));
    }
}

int obterTamanho(char *str)
{
    int t = 0;
    while (str!=NULL && str[t]!='\0') {
        t++;
    }
    return t;
}

