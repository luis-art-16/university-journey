
// SLIDE 9
//
// Inicialização de variáveis do tipo string.

#include <stdio.h>

int main(void)
{
   char str1[] = "123";
   char str2[] = {'5', '6', '7' };

   printf("\nstr1: '%s'\n", str1);
   printf("Tamanho do array str1: %lu\n\n", sizeof(str1));
 
   printf("str2: '%s'\n", str2);
   printf("Tamanho do array str2: %lu\n", sizeof(str2));
   printf("Ha' um problema no conteudo do array str2 ou ha' um problema ao escrever o array?\n\n");

   printf("Utilizando um apontador para um literal do tipo string:\n");
   char* ptr_str3 = "89a";
   printf("   str3: '%s'\n", ptr_str3);
   printf("   Tamanho de ptr_str3: %lu\n", sizeof(ptr_str3));
   printf("   O tamanho de ptr_str3 e' o valor que esperava?\n\n");

   return 0;
}
