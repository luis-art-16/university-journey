
// SLIDE 10
//
// Array de carateres vs. apontador para uma string.

#include <stdio.h>

int main(void)
{
   char str1[] = "PImp-2023"; // Array de carateres (ou string)
   char *str2  = "PImp-2023"; // Apontador para uma string

   printf("str1 \"%s\"\n", str1);
   printf("str2 \"%s\"\n", str2);

   printf("Tamanho de str1 %lu\n", sizeof(str1)); // devolve o tamanho do array str1
   printf("Tamanho de str2 %lu\n", sizeof(str2)); // devolve o tamanho dum apontador

   return 0;

}
