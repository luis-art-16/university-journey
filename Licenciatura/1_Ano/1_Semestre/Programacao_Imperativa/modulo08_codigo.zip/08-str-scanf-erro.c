
// SLIDE 12
//
// A leitura de carateres com scanf e formato "%s" pode fazer
// um programa falhar, porque se podem ler mais carateres
// do que o tamanho disponível no array onde são guardados.

#include <stdio.h>

int main(void) 
{
   char str0[7] = "PI2023"; // mais o '\0'
   char str1[5];            // para 4 carateres mais o '\0'

   printf("String str0: '%s'\n", str0);
   printf("Digite mais de 4 carateres para provocar um erro: ");
   scanf("%s", str1);
   printf("Inseriu a string '%s'\n", str1);
   printf("Novamente a string str0: '%s'\n", str0);

   return 0;
}
