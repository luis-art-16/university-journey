
// SLIDE 5
//
// Aceder aos carateres dum literal do tipo string.

#include <stdio.h>

int main(void)
{
    char *str = "ABC";
    printf("Tamanho de str: %lu\n", sizeof(str));
    printf("str: '%s'\n", str);

    // str: 'A' 'B' 'C' '\0'
    // Tamanho de str: 8
    // PORQUÊ 8 E NÃO 4?

    return 0;
}