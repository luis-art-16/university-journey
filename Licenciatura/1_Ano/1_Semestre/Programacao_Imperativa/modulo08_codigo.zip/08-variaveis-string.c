
// SLIDE 8
//
// Declaração e inicialização de variáveis do tipo string.

#include <stdio.h>
#include <stdbool.h>
#include <string.h>

int main(void)
{
    // Declaração de uma variável do tipo array de carateres, 
    // especificando o tamanho do array  
    // e inicializada com um literal do tipo string

    char str1[10] = "PImp-2023"; 

    // Declaração de uma variável do tipo array de carateres, 
    // especificando o tamanho do array 
    // e inicializada com uma sequência de literais do tipo caratere

    char str2[10] = {'P', 'I', 'm', 'p', '-', '2', '0', '2', '3', '\0'};

    bool iguais=true;
    for (int c=0; c<10; ++c)
        if(str1[c] != str2[c])
            iguais = false;
    printf("As strings str1 e str2 sao %s\n",iguais?"iguais":"diferentes");

    // Se o tamanho do array for maior do que a string de inicialização, 
    // as posições não utilizadas são definidas com o valor '\0'

    char str3[15] = "PImp-2023"; 

    // Escrever os elementos da string guardada em str3 como chars

    for (int j=0; j<strlen(str3); ++j)
        printf("(char) str3[%02i] = '%c'\n", j, str3[j]);
    
    // Escrever os elementos restantes do array str3 como inteiros
    
    for (int j=strlen(str3); j<15; ++j)
        printf("(int)  str3[%02i] = %i\n", j, (int)str3[j]);

    // Declaração de uma variável do tipo array de carateres, 
    // omitindo o tamanho do array
    // e inicializada com um literal do tipo string

    char str4[] = "PImp-2023";

    printf("Qual o numero de carateres reservados em str4?\n");

    //printf("Numero de carateres de str4: %lu\n",sizeof(str4));

    return 0;
}