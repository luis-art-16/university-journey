
// SLIDE 6
//
// Converter um número entre 0 e 15 para o caratere 
// hexadecimal correspondente.

#include <stdio.h>

char numero_2_hexchar(int);

int main(void)
{
    int  num;
    char charHex;

    do {
        printf("numero de 0-15: ");
        scanf("%i",&num);
    } while (num<0 || num>15);

    charHex = numero_2_hexchar(num);
    printf("Digito hexadecimal: '%c'\n",charHex);

    return 0;
}

// Converter um número entre 0 e 15 para o caratere hexadecimal correspondente

char numero_2_hexchar(int numero)
{
    return "0123456789ABCDEF"[numero];
}
