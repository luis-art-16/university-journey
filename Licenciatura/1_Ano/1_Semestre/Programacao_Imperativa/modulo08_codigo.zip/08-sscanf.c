
// SLIDE 27
//
// Utilizar a função sscanf para extrair números a partir duma string.

#include <stdio.h>

int main(void)
{
    char   str[100] = "1576 -12.375";
    int    numI;
    double realF;
    
    sscanf(str,"%d %lf", &numI, &realF);
    printf("INT: %d\nDOUBLE: %lf\n", numI, realF);

    return 0;
}