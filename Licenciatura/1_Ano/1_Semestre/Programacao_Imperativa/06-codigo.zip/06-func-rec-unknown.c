#include <stdio.h>

int f (int);

int main(void)
{
    int n, res;

    printf("N: ");
    scanf("%d",&n);

    res = f(n);

    printf("Resultado: %d\n",res);
}

// Versão recursiva da função f(), em que se guarda o valor calculado
// numa variável int.
//
// O que faz esta função?

int f (int n)
{
    if ((n == 1) || (n == 0))
        return 1;
    else
        return (f(n-1) + f(n-2));
}
