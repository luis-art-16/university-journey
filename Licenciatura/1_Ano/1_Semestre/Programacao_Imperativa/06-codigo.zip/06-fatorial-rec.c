#include <stdio.h>

int fatorial (int);

int main (void)
{
    int n = 5, w;
    w = fatorial ( n );
    printf("Fatorial de %d = %d\n",n,w);
}

int fatorial (int n)
{
    if (n == 1)
        return 1;
    else
        return n * fatorial(n-1);
}
