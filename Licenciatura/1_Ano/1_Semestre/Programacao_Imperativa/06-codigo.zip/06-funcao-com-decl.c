#include <stdio.h>

// Declaração da função f

float f (float, float);

////////////////////////////////////////
int main (void)
{
    float w, x=3.5, y=4.7;
    w = f(x, y);
    printf("w: %f\n",w);
}

////////////////////////////////////////
float f (float x, float y)
{
    float max;
    max = (x>y) ? x : y;
    return max;
}