#include <stdio.h>

/*
NOTA: Este código não compila, é apenas ilustrativo da motivação
      para utilizar funções.

VERSÃO COM FUNÇÕES
*/

void main() {
	
	float in1[H1][W1], in2[H2][W2], out1[HO][WO], out2[HO][WO];
	float f1[HF1][WF1], f2[HF2][WF2], f3[HF3][WF3], res, max, min, media;
	int   h, w, hf, wf;
    int   opcao;

	in1  = ...; // ler imagem 1 do ficheiro 1

	in2  = ...; // ler imagem 2 do ficheiro 2

	out1 = ...; // colocar array a zero

	out2 = ...; // colocar array a zero

	f1   = {...}; // inicializar filtro 1 com valores fixos

	f2   = {...}; // inicializar filtro 2 com valores fixos

	f3   = {...}; // inicializar filtro 3 com valores fixos

    printf("Que operacao pretende aplicar: ");
    scanf("%d",&opcao);
    
	switch(opcao) {
		case OP1:
			filtroSobelNormalizado(in1, f1, out1, H1, W1, HF1, WF1);
			break;

		case OP2:
			filtroRemoverRuido(in2, f2, out1, H2, W2, HF2, WF2);
			break;

		case OP3:
			filtroSobelNormalizado(in1, f1, out1, H1, W1, HF1, WF1);
			filtroRemoverRuido(out1, f3, out2, H1, W1, HF3, WF3);
			break;

		case OP4:
			diferencaImagens(in1, in2, out2, H1, W1);
			break;

		case OP5:
			mediaImagens(in1, in2, out1, H1, W1);
			break;

		case OP6:
			detecaoContornos(in2, out2, H2, W2, param1, param2);
			break;
		default:
			printf("Algoritmo não disponivel!");
	}
}


// -------------------------------------------------------
void filtroSobelNormalizado(float *i, float *f, float *o, int HI, int WI, int HF, int WF) {
	int h, w, hf, wf;
	float max=-1000.0, min=1000.0, res;
	for(h=0;h<HI;++h) {
		for(w=0;w<WI;++w) {
			for(hf=0;hf<HF;++hf) {
				res=0.0;
				for(wf=0;wf<WF;++wf) {
					res +=i[h+hf][w+wf]*f[hf][wf];
				}
			}
		o[h][w] = res;
		max = maximum(res, max);
		min = minimum(res, min);
		}
	}
	normalizacao(o, HI, WI, max, min);
}

// -------------------------------------------------------
float maximum(float v, float max){
	if(v>max)
		return v;
	else
		return max;
}

// -------------------------------------------------------
float minimum(float v, float min){
	if(v<min)
		return v;
	else
		return min;
}

// -------------------------------------------------------
void normalizacao(float *img, int H, int W, float max, float min) {
	int h,w;
	for(h=0;h<H;++h) {
		for(w=0;w<W;++w) {
			img[h][w] /= (max-min);
		}
	}
}

// -------------------------------------------------------

void filtroRemoverRuido(float *i, float *f, float *o, int HI, int WI, int HF, int WF) {
	int h, w, hf, wf;
	float media=0.0, res;

	for(h=0;h<HI;++h) {
		for(w=0;w<WI;++w) {
			for(hf=0;hf<HF;++hf) {
				res=0.0;
				for(wf=0;wf<WF;++wf) {
					res +=i[h+hf][w+wf]*f[hf][wf];
				}
			}
		o[h][w] = res;
		media += res;
		}
	}
	media /= (HI*WI);
	subtrairMedia(o, HI, WI, media);
}
	
// -------------------------------------------------------
void subtrairMedia(float *img, int H, int W, float media) {
	int h, w;

	for(h=0;h<H;++h) {
		for(w=0;w<W;++w) {
			img[h][w] -= media;
		}
	}
}

/* ETC ETC */
