#include <stdio.h>

void swap_errado(int, int); // declaração da função

int main(){
    int a, b;

    printf("Introduza dois numeros: ");
    scanf("%d%d", &a, &b);

    printf("Antes:  a=%d b=%d\n", a, b);

    swap_errado(a, b); // função chamada por valor

    printf("Depois: a=%d b=%d\n", a, b);

    return 0;
}

void swap_errado(int x, int y){ // definição da função
    int temp;
    temp = x;
    x    = y;
    y    = temp; // Qual o problema deste swap? Como o resolver?
}