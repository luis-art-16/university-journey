#include <stdio.h>

int soma(int,int); // declaração da função soma

//////////////////////////////////////////////////

int main()
{
    int a, b, s;

    printf("Introduza dois inteiros: ");
    scanf("%d%d", &a, &b);

    s=soma(a, b);  // chamada da função soma
    printf("Soma = %d\n", s);

    return 0;
}

//////////////////////////////////////////////////

int soma(int x, int y) // definição da função soma
{
    int res;
    res = x + y;
    return res; // instrução de regresso à função chamadora (main)
}