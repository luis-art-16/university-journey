#include <stdio.h>

long long f (int);

int main (void)
{
    int       n;
    long long res;

    printf("N (>=2): ");
    scanf("%d",&n);

    if (n<2) {
        printf("Escolha um N maior ou igual a 2\n");
        return -1;
    }

    res = f(n);

    printf("Resultado: %lld\n", res);
    
    return 0;
}

// Versão iterativa (i.e. com ciclo) da função f().

long long f (int n) 
{
    long long vf[n+1]; // vf = array de valores intermédios

    vf[0] = 1LL;
    vf[1] = 1LL;

    for (int i = 2; i <= n; i++)
        vf[i] = vf[i-1] + vf[i-2];
    
    return vf[n];
}
