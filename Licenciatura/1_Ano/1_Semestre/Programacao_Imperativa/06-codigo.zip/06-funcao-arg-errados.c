#include <stdio.h>

// CORRIGIR OS ARGUMENTOS UTILIZADOS NA CHAMADA DE cilindro()

#define PI 3.14159

void cilindro (float , float);

// variáveis globais

float a, v;

////////////////////////////////////////

int main(void) {
    int r=2;
    cilindro (r);
    printf("a: %d  v: %d\n", a, v);
}

////////////////////////////////////////
void cilindro (float r, float h)
{
    a = 2.0 * PI * r * (r + h);
    v = PI * r * r * h;
}