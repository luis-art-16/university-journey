#include <stdio.h>

// NOTA: ESTE CÓDIGO NÃO COMPILA

char lerString() [100];

int main(void) {
    char s[100];
    strcpy(s, lerString());
    printf("S: %s\n",s);

    return 0;
}

char lerString() [100] {
    char localS[100];
    fgets(localS,100,stdin);
    return localS; // esta instrução não devolve o array, 
                   // devolve o endereço de memória do elemento 0 do array
}
