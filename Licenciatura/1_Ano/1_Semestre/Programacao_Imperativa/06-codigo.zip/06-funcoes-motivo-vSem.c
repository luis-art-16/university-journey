#include <stdio.h>

/*
NOTA: Este código não compila, é apenas ilustrativo da motivação
      para utilizar funções.

VERSÃO SEM FUNÇÕES
*/

void main() {
	
	float in1[H1][W1], in2[H2][W2], out1[HO][WO], out2[HO][WO];
	float f1[HF1][WF1], f2[HF2][WF2], f3[HF3][WF3], res, max, min, media;
	int   h, w, hf, wf;
    int   opcao;

	in1 = ...; // ler imagem 1 do ficheiro 1

	in2 = ...; // ler imagem 2 do ficheiro 2

	out1 = ...; // colocar array a zero

	out2 = ...; // colocar array a zero

	f1 = {...}; // inicializar filtro 1 com valores fixos

	f2 = {...}; // inicializar filtro 2 com valores fixos

	f3 = {...}; // inicializar filtro 3 com valores fixos

    printf("Que operacao pretende aplicar: ");
    scanf("%d",&opcao);
    
	switch(opcao) {
		case OP1:
			max = -1000.0;
			min = 1000.0;
			for(h=0;h<H1;++h) {
				for(w=0;w<W1;++w) {
					for(hf=0;hf<HF1;++hf) {
						res=0.0;
						for(wf=0;wf<WF1;++wf) {
							res +=in1[h+hf][w+wf]*f1[hf][wf];
						}
					}
				out1[h][w] = res;
				if(res>max)
					max = res;
				if(res<min)
					min = res;
				}
			}
			for(h=0;h<H1;++h) {
				for(w=0;w<W1;++w) {
					out1[h][w] /= (max-min);
				}
			}
			break;

		case OP2:
			media = 0.0;
			for(h=0;h<H2;++h) {
				for(w=0;w<W2;++w) {
					for(hf=0;hf<HF2;++hf) {
						res=0.0;
						for(wf=0;wf<WF2;++wf) {
							res +=in2[h+hf][w+wf]*f2[hf][wf];
						}
					}
				out1[h][w] = res;
				media += res;
				}
			}
			media /= (H2*W2);
			for(h=0;h<H1;++h) {
				for(w=0;w<W1;++w) {
					out1[h][w] -= media;
				}
			}
			break;

		case OP3:
			max = -1000.0;
			min = 1000.0;
			for(h=0;h<H1;++h) {
				for(w=0;w<W1;++w) {
					for(hf=0;hf<HF1;++hf) {
						res=0.0;
						for(wf=0;wf<WF1;++wf) {
							res +=in1[h+hf][w+wf]*f1[hf][wf];
						}
					}
				out1[h][w] = res;
				if(res>max)
					max = res;
				if(res<min)
					min = res;
				}
			}
			for(h=0;h<H1;++h) {
				for(w=0;w<W1;++w) {
					out1[h][w] /= (max-min);
				}
			}
			media = 0.0;
			for(h=0;h<H1;++h) {
				for(w=0;w<W1;++w) {
					for(hf=0;hf<HF3;++hf) {
						res=0.0;
						for(wf=0;wf<WF3;++wf) {
							res +=ou1[h+hf][w+wf]*f3[hf][wf];
						}
					}
				out2[h][w] = res;
				media += res;
				}
			}
			media /= (H1*W1);
			for(h=0;h<H1;++h) {
				for(w=0;w<W1;++w) {
					out2[h][w] -= media;
				}
			}
			break;

		case OP4:
			for(h=0;h<H1;++h) {
				for(w=0;w<W1;++w) {
					out2[h][w] = in2[h][w]-in1[h][w];
				}
			}
			break;

		case OP5: /* CÓDIGO REPETIDO APENAS PARA EFEITOS ILUSTRATIVOS */
			max = -1000.0;
			min = 1000.0;
			for(h=0;h<H1;++h) {
				for(w=0;w<W1;++w) {
					for(hf=0;hf<HF1;++hf) {
						res=0.0;
						for(wf=0;wf<WF1;++wf) {
							res +=in1[h+hf][w+wf]*f1[hf][wf]+in2[h+hf][w+wf]*f2[hf][wf];
						}
					}
				out1[h][w] = res;
				if(res>max)
					max = res;
				if(res<min)
					min = res;
				}
			}
			for(h=0;h<H1;++h) {
				for(w=0;w<W1;++w) {
					out1[h][w] /= (max-min);
				}
			}
			break;

		case OP6:  /* CÓDIGO REPETIDO APENAS PARA EFEITOS ILUSTRATIVOS */
			media = 0.0;
			for(h=0;h<H2;++h) {
				for(w=0;w<W2;++w) {
					for(hf=0;hf<HF2;++hf) {
						res=0.0;
						for(wf=0;wf<WF2;++wf) {
							res +=in2[h+hf][w+wf]*f2[hf][wf];
						}
					}
				out2[h][w] = res;
				media += res;
				}
			}
			media /= (H2*W2);
			for(h=0;h<H1;++h) {
				for(w=0;w<W1;++w) {
					out2[h][w] -= media;
				}
			}
			break;

		default:
			printf("Algoritmo não disponivel!");
	}
}