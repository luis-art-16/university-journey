
// Operador '*' sobre apontadores - SLIDE 9
//
// O operador '*' devolve o conteúdo do endereço contido no apontador.

#include <stdio.h>

int main(void)
{
    int     a=3, a2;
    int*    ap;
    char    c='s', c2;
    char*   cp;
    float   f=2.9, f2;
    float*  fp;

    ap = & a;
    cp = & c;
    fp = & f;

    printf("INICIO:\n\ta=%d  c=%c  f=%f\n",a,c,f);

    *ap = 33;   // Atribui-se o valor 33 à variável apontada por ap
    a2  = *ap;  // Atribui-se o conteúdo (da variável) apontada por ap à variável a2

    *cp = 'Q';  // Atribui-se o valor ’Q’ à variável apontada por cp
    c2  = *cp;  // Atribui-se o conteúdo (da variável) apontada por cp à variável c2

    *fp = 3.14; // Atribui-se o valor 3.14 à variável apontada por fp
    f2   = *fp;  // Atribui-se o conteúdo (da variável) apontada por fp à variável f2

    printf("APOS AS ALTERACOES:\n\ta =%d  c =%c  f =%f\n",a,c,f);
    printf("\ta2=%d  c2=%c  f2=%f\n",a2,c2,f2);

    return 0;
}