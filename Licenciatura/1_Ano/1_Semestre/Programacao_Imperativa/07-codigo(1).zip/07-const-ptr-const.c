
// Apontador constante para uma variável constante - SLIDE 42

#include <stdio.h>

int main(void)
{
    int v  = 10;
    int v2 = 20;

    const int *const ptr = &v;

    printf("v: %d *ptr: %d\n", v, *ptr);

    ptr  = &v2; // NÃO É PERMITIDO ALTERAR O APONTADOR DADO QUE ELE É CONSTANTE!
    *ptr = 11;  // NÃO É PERMITIDO ALTERAR A VARIÁVEL APONTADA DADO QUE ELA É CONSTANTE!

    return -1;
}