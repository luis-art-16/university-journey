/* 
Aritmética dos apontadores - SLIDE 25

Consideremos a declaração:
   char∗ pc = (char∗)pa; 
 
Que valor de n satisfaz:
   (int∗)(pc+n) == pa+3
*/

#include <stdio.h>
#include <stdlib.h>

int main() {

    int arr[8];
    int n, j, *pa3;

    int  *pa;
    pa = arr;

    char *pc;
    pc= (char *)pa;

    // Que valor de n satisfaz: (int ∗)(pc+n) == (pa+3) ?

    printf("pa = pc = Endereco de memoria de arr[0]: %p\n\n",arr);
    printf("pa e' um apontador para int's -> quando incrementado avança de 4 em 4 bytes:\n");

    for (j=0;j<8;++j) {
        printf("Endereco pa+%d: %p\n",j,pa+j);
        if(j==3) {
            pa3 = pa+j;
        }
    }

    printf("\n");

    printf("pc e' um apontador para char's -> quando incrementado avança de 1 em 1 byte:\n");
    for (n=0;n<32;++n) {
        printf("Endereco pc+%2d: %p\n",n,pc+n);
        if ((int *)(pc+n)==pa3) {
            printf("\n==> O valor de n que satisfaz: (pc+n==pa+3) e' %d\n",n);
            break;
        }
    }

    return 0;
}