
// Apontador para uma variável constante - SLIDE 40

#include <stdio.h>

int main(void)
{
    int v  = 10;
    int v2 = 20;

    const int *ptr = &v;
    printf("[A] *ptr: %d\n", *ptr);

    *ptr = 11; // NÃO É PERMITIDO ALTERAR A VARIÁVEL APONTADA v

    v = 11; // Mas podemos modificar a variável v diretamente
    printf("[B] *ptr: %d\n", *ptr);

    ptr = &v2; // E também podemos atribuir outro endereço a ptr
    printf("[C] *ptr: %d\n", *ptr);
}