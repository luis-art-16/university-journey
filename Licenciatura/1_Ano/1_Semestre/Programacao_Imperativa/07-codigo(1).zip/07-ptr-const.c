
// Apontador constante - SLIDE 41

#include <stdio.h>

int main(void)
{
int v  = 10;
int v2 = 20;

int * const ptr = &v;

printf("v: %d *ptr: %d\n", v, *ptr);

ptr = &v2; // NÃO É PERMITIDO ALTERAR O APONTADOR CONSTANTE ptr!

*ptr = 11; // Mas podemos modificar o conteúdo da variável v apontada por ptr
printf("v: %d\n", v);

}