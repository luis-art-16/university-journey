
// Uma função que devolve um apontador - SLIDE 16

#include <stdio.h>

int* maior (int*, int*);

int main(void)
{
    int i=3, j=7, *rp;
    printf("Endereco de i(=3): %p\n",&i);
    printf("Endereco de j(=7): %p\n",&j);

    rp = maior ( &i, &j );

    printf("MAIOR: %d <-- Esta' guardado no endereco %p\n",*rp,rp);
}

// A função 'maior' devolve um apontador

int* maior (int* p1, int* p2 )
{
    if (*p1 > *p2)
        return p1;
    else
        return p2;
}