
// Função que devolve um apontador - SLIDE 17

#include <stdio.h>

int* soma (int);

int main (void)
{
    int* ret;

    ret = soma(3);
    printf("%d\n", *ret );

    ret = soma(4);
    printf("%d\n", *ret );

    ret = soma(5);
    printf("%d\n", *ret );

    return (0);
}

// Função que devolve um apontador para uma variável local --> NUNCA FAZER ISTO!!!!

// Verifique o que acontece ao executar o programa

int* soma (int i)
{
    int sum = 0;
    sum += i;

    return &sum;
}

// Segmentation fault (core dumped)