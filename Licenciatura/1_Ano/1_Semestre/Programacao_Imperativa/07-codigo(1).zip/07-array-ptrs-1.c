
// Arrays de apontadores - SLIDES 32:35

#include <stdio.h>

int main() {
   int *arrApontadores[5];
   int  arrInts[5];
   int  v=100, x=200, y=300, z=400, w=500;

   // array com uma cópia dos valores das variáveis v,x,y,z,w

   arrInts[0] = v;
   arrInts[1] = x;
   arrInts[2] = y;
   arrInts[3] = z;
   arrInts[4] = w;

   // array com os endereços das variáveis v,x,y,z,w

   arrApontadores[0] = &v;
   arrApontadores[1] = &x;
   arrApontadores[2] = &y;
   arrApontadores[3] = &z;
   arrApontadores[4] = &w;

   // vamos alterar as variáveis v,x,y,z,w

   v += 5; x += 7; y += 9; z += 12; w += 16;

   // vamos inspecionar os valores acessíveis através dos dois arrays

   for (int i = 0; i<5; i++) {

      switch (i) {
         case 0:
            printf("v=%d   ",v);
            break;
         case 1:
            printf("x=%d   ",x);
            break;
         case 2:
            printf("y=%d   ",y);
            break;
         case 3:
            printf("z=%d   ",z);
            break;
         case 4:
            printf("w=%d   ",w);
            break;
         default:
            break;
      }
      printf("arrInts[%d]=%d   Valor apontado por arrApontadores[%d]=%d\n", 
         i, arrInts[i], i, *(arrApontadores[i]));
   }

   return 0;
}