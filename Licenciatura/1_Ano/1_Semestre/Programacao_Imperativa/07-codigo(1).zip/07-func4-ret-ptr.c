
// A alternativa a devolver um apontador a partir de uma função
// é passar um argumento por referência.
//
// SLIDE 19

#include <stdio.h>

void soma (int, int*);

int main (void)
{
    int s = 0;

    soma(3, &s);
    printf("%d\n", s);
    soma(4, &s);
    printf("%d\n", s);
    soma(5, &s);
    printf("%d\n", s);

    return 0;
}

// A função 'soma' recebe o argumento 'sp' passado por referência

void soma(int i, int* sp )
{
    *sp += i;
    return;
}