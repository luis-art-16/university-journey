
// Arrays vs. apontadores - SLIDE 22

// Comente com /* ... */ a versão que não quer compilar.
// Remova /* ... */ da versão que quer compilar.

#include <stdio.h>

/*
// COM ARRAYS //////////////////////////////////////////////

int  slen (char s[]);

int main (void)
{
    int  len;
    char str[20] = "uma string";

    len = slen(str);
    printf("Tamanho da string: %d\n",len);

    return 0;
}

int slen(char str[])
{
    int len = 0;
    while (str[len] != '\0')
        len++;
    return len;
}
////////////////////////////////////////////////////////////
*/


// COM APONTADORES /////////////////////////////////////////

int slen (char *s);

int main (void)
{
    int  len;
    char str[20] = "uma string";

    len = slen(str);
    printf("Tamanho da string: %d\n",len);

    return 0;
}

int slen(char *str)
{
    int len = 0;
    while (*(str+len) != '\0')
        len++;
    return len;
}
////////////////////////////////////////////////////////////

