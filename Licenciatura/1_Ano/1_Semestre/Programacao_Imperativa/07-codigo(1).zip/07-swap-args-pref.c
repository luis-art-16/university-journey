
// Passar argumentos a uma função por referência - SLIDE 28

#include <stdio.h>

void swap (int*, int*);

int main()
{
    int a, b, *pa, *pb;

    a  = 10;  b  = 20;
    pa = &a;  pb = &b;

    printf("[antes SWAP] A=%d B=%d\n", a, b);
    
    swap (pa, pb);

    printf("[apos  SWAP] A=%d B=%d\n\n", a, b);

    return 0;
}

// os argumentos 'a' e 'b' da função são passados por referência

void swap (int* va, int* vb)
{
    int temp = *va;
    *va = *vb;
    *vb = temp;
}
