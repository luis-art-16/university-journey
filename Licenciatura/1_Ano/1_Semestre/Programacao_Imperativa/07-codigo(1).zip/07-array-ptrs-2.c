
// Arrays de apontadores - Exercício que não é referido nos slides

#include <stdio.h>
#include <string.h>

int main()
{
    char *fruto[] = {
        "melancia",
        "banana",
        "pera",
        "ananas",
        "marmelo",
        "uva",
        "ameixa preta"
    };

    for(int f=0; f<7; f++) {
        printf("Numero de carateres do fruto[%d]=%s e' %lu\n",f,fruto[f],strlen(fruto[f]));
    }

    return(0);
}