
// Função que devolve um apontador - SLIDE 18

#include <stdio.h>

int* soma (int);

int main (void)
{
    int* ret;

    ret = soma(3);
    printf("%d\n", *ret);
    ret = soma(4);
    printf("%d\n", *ret);
    ret = soma(5);
    printf("%d\n", *ret);

    return (0);
}

// A função 'soma' devolve um apontador para uma variável local.
// Como a variável local é qualificada de "static", 
// passa a ser válido devolver o seu endereço

int* soma (int i)
{
    static int sum=0; // A variável 'sum' é partilhada por todas as execuções
                      // da função, ou seja, só é inicializada a zero a
                      // primeira vez que a função é executada
    sum += i;
    return &sum;
}