
// Operador '&' - SLIDE 7
//
// O operador '&' devolve o endereço de memória onde a variável está armazenada.

#include <stdio.h>

int main(void)
{
    //  Endereçamento e indireção

    double  pi  = 3.14159;

    double* ppi = &pi;
    // ppi fica com o endereço de memória onde a variável pi está armazenada

    printf("PI pode ser obtido indiretamente como o conteudo do seu endereco %p: %lf\n", ppi, *ppi);

    // Escreve no terminal o valor guardado em pi pois *ppi = pi
}