
// Apontadores para apontadores - SLIDE 29

#include <stdio.h>

void swap1 (int**, int**);

int main()
{
    int a, b, *pa, *pb;

    a  = 10;  b  = 20;
    pa = &a;  pb = &b;

    printf("[antes SWAP1] A=%d B=%d apontador(A)=%p apontador(B)=%p\n", a, b, pa, pb);
    
    swap1 (&pa, &pb);

    printf("[apos  SWAP1] A=%d B=%d apontador(A)=%p apontador(B)=%p\n", a, b, pa, pb);

    return 0;
}

// os argumentos 'a' e 'b' da função são um "apontador para um apontador"

void swap1 (int** a, int** b)
{
    int* temp = *a;
    *a = *b;
    *b = temp;
}
