#include "dados.h"
#include <stdio.h>

int igual(data_t d1,data_t d2)
{
	if(d1.cod==d2.cod)
		return 1;
	else
		return 0;
}

void inserir_dados(data_t *d1)
{

	printf("Indique o codigo do produto:");
	scanf("%d",&(d1->cod));
	fflush(stdin);
	printf("Indique o nome do produto:");
	gets(d1->nome);
	printf("Indique a quantidade inicial do stock:");
	scanf("%f",&(d1->stock));
}

void mostrar_dados(data_t d1)
{

	printf("Codigo de produto: %d\n",d1.cod);
	printf("Nome do produto: %s \n",d1.nome);
	printf("Quantidade em stock: %f \n",d1.stock);
}
