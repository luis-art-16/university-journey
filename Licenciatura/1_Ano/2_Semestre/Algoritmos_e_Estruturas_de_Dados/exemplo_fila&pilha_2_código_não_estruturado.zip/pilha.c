#include<stdio.h>
#include<stdlib.h>

typedef struct dados{
	int valor;
}Dados;

typedef struct no{
	Dados dados;
	struct no* proximo;
}No;

typedef struct stack{
	No *topo;
}Pilha;

Pilha* create()
{
	Pilha *p = malloc(sizeof(Pilha));
	p->topo = NULL;
	return p;
}

void push(Pilha *stack, Dados d)
{
	//Prepara novo n�
	No *elemento = malloc(sizeof(No));
	elemento->dados = d;
	elemento->proximo = NULL;
	//Caso a pilha esteja vazia
	if (stack->topo == NULL)
	{
		stack->topo = elemento;
	}
	//Caso contr�rio...
	else
	{
		elemento->proximo = stack->topo;
		stack->topo = elemento;
	}
}

Dados* pop(Pilha *stack)
{
	if(stack->topo!=NULL)
	{
		No *aux = stack->topo;
		Dados *p = malloc(sizeof(Dados));
		*p = aux->dados;
		stack->topo = aux->proximo;
		free(aux);
		aux = NULL;
		return p;
	}
	return NULL;
}

Dados* peek(Pilha *stack)
{
	if(stack->topo!=NULL)
	{
		Dados *p = malloc(sizeof(Dados));
		*p = stack->topo->dados;
		return p;
	}
	return NULL;
}

int empty(Pilha *stack)
{
	if(stack->topo==NULL)
		return 1;
	else 
		return 0;
}

void destroy(Pilha**stack)
{
	while(!empty(*stack))
		pop(*stack);
	free(*stack);
	*stack = NULL;
}

Dados novoElemento(int v)
{
	Dados d = {.valor=v};
	return d;
}

main()
{
	Pilha *pilha = create();
	push(pilha, novoElemento(10));
	printf("\nTopo da pilha: %d", peek(pilha)->valor);
	push(pilha, novoElemento(20));
	printf("\nTopo da pilha: %d", peek(pilha)->valor);
	push(pilha, novoElemento(50));
	printf("\nTopo da pilha: %d", peek(pilha)->valor);
	printf("\nTopo da pilha: %d", pop(pilha)->valor);
	printf("\nTopo da pilha: %d", pop(pilha)->valor);
	printf("\nTopo da pilha: %d", pop(pilha)->valor);
	printf("\nVazia? --> %d", empty(pilha));
}
