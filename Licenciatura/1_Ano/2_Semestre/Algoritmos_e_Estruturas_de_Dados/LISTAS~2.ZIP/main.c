#include <stdio.h>
#include <stdlib.h>
#include"Listas.h"

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	
	Lista *lista = NULL;
	
	adicionaNaLista_FIM(&lista, criarNo("VW", "Golf", "XX-XY-XZ", 1998, 1000));
	adicionaNaLista_FIM(&lista, criarNo("VW", "Polo", "00-11-22", 2011, 5000));
	adicionaNaLista_FIM(&lista, criarNo("Seat", "Ibiza", "00-11-33", 2008, 4000));
	
	remover(&lista, "00-11-33");
	remover(&lista, "00-11-22");
	remover(&lista, "XX-XY-XZ");
	
	adicionaNaLista_FIM(&lista, criarNo("Seat", "Ibiza", "00-11-33", 2008, 4000));

	imprimirLista(&lista);
	
	return 0;
}
