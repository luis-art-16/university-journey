#include"Listas.h"
#include<stdio.h>
#include<stdlib.h>
#include<string.h>

No* criarNo(char *mar, char *mod, char* mat, int ano, float pr)
{

	Viatura v = {.anoConstr=ano, .preco=pr};
	strcpy(v.marca, mar);
	strcpy(v.modelo, mod);
	strcpy(v.matricula, mat);
	No* novo = (No*) malloc(sizeof(No));
	novo->viatura = v;
	novo->proximo = NULL; 
	novo->anterior = NULL; 
	return novo;
}

void imprimirNo(No *no){
	printf("\n-------------------------%s-------------------------\n", no->viatura.matricula);
	printf("%s | %s | %d | %.2f\n", no->viatura.marca, no->viatura.modelo, no->viatura.anoConstr, no->viatura.preco);
	printf("----------------------------------------------------------\n");
}

void imprimirLista(Lista **lista)
{
	printf("############################## A MINHA LISTA ##############################");
	if (*lista==NULL)
		printf("\n--- Empty list ---\n");
	else
	{
		No *aux = *lista;
		while(aux!=NULL)
		{
			imprimirNo(aux);
			aux = aux->proximo;
		}
	}
	printf("##########################################################################\n");
}

void adicionaNaLista_FIM(Lista **lista, No *novo)
{
	if (*lista == NULL)
	{
		*lista = novo;
	}
	else /*a outra parte mais dificil...*/
	{
		No* aux = *lista;
		while(aux->proximo!=NULL)
		{
			aux=aux->proximo;
		}
		aux->proximo = novo;
		novo->anterior = aux;
	}	
}

void adicionaNaLista_INICIO(Lista **lista, No *novo)
{
	if (*lista == NULL)
	{
		*lista = novo;
	}
	else /*a outra parte mais dificil...*/
	{
		novo->proximo = *lista;
		(*lista)->anterior = novo;
		*lista = novo;
	}	
}

int remover(Lista **lista, char *mat)
{
	if (*lista==NULL)
	{
		return 0;
	}
	else
	{
		int encontrou = 0;
		No *aux = *lista;
		while (encontrou == 0 && aux!=NULL)
		{
			if (strcmp(aux->viatura.matricula, mat)==0)
				encontrou = 1;
			else 
				aux = aux->proximo;
		}
		if(encontrou == 0)
			return 0;
		
		if(aux == *lista)
		{
			*lista = NULL;
		}
		else
		{
			aux->anterior->proximo = aux->proximo;	
			if (aux->proximo!=NULL)		
				aux->proximo->anterior = aux->anterior;
		}
		aux=NULL;
		free(aux);
	}
	return 1;
}



