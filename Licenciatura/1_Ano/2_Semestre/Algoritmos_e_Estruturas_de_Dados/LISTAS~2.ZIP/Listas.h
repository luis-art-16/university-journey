typedef struct carros{
	char marca [50];
	char modelo [50];
	char matricula [50];
	int anoConstr;
	float preco;
} Viatura;

typedef struct no{
	Viatura viatura;
	struct no* proximo;
	struct no* anterior;
}No, Lista;

No* criarNo(char *mar, char *mod, char* mat, int ano, float pr);

void imprimirNo(No *no);

void imprimirLista(Lista **lista);

void adicionaNaLista_INICIO(Lista **lista, No *no);

void adicionaNaLista_FIM(Lista **lista, No *no);

int remover(Lista **lista, char *mat);

void editar(Lista **lista, char *matAAlterar, char *marNova, char *modNovo, int anoNovo, float prNovo);

