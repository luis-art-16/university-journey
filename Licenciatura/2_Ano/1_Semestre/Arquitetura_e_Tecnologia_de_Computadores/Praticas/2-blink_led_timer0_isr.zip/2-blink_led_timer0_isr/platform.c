#include "SI_EFM8BB3_Defs.h"

#define __USE_SIMULATOR__

#define PFE0CN_FLRT_BIT 	  (1 << 4)   /// sysclk < 50MHz
#define CLKSEL_CLKSL_HFOSC1   0x03		 /// Clock derived from the Internal High Frequency
#define XBR2_XBARE_ENABLED	  0x40		 /// Crossbar Enabled
#define XBR0_URT0E_ENABLED    0x01 		 /// UART0 TX0, RX0 routed to Port pins P0.4 and P0.5

extern void init_xbar(void){
	XBR2 = XBR2_XBARE_ENABLED;
	XBR0 = XBR0_URT0E_ENABLED;
}

extern void init_cpu_clock_49 (void){
	//disable watch-dog
	WDTCN = 0xAD;
	
	//Ensure SYSCLK is > 24MHz using HFOSC0
	CLKSEL = 0;
	
	SFRPAGE = 0x10;
	PFE0CN |= PFE0CN_FLRT_BIT;
	SFRPAGE = 0;
	
	//switch clock source to HFOSC1
	CLKSEL |= CLKSEL_CLKSL_HFOSC1;
}


extern void init_platform(void){

//#ifndef __USE_SIMULATOR__
//	init_cpu_clock_49();
//#else
	PCA0MD = 0;
//#endif
	
	init_xbar();
}