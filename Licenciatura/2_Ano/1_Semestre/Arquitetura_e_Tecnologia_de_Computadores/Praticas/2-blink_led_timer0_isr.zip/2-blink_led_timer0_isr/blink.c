#include "SI_EFM8BB3_Defs.h"


/*********************************************************
 * typedefs						 																	 *
 *********************************************************/	
//typedef unsigned char uint8_t;
//typedef unsigned int uint16_t;

/*********************************************************
 * global vars				 																	 *
 *********************************************************/	
 uint16_t timeout = 0;
 
/*********************************************************
 * function prototypes 																	 *
 *********************************************************/	
void init_timer0_int(void);

/*********************************************************
 * timer0_isr					 																	 *
 *********************************************************/	
void isr_timer0(void) interrupt 1 using 2
{
	static uint16_t counter = 0;

	TH0 = (-24500>>8);
	TL0 = (-24500);
	
	counter++;
	
	timeout = ((counter&0x200)>>9);

	counter &= 0x1ff;
} 

/*********************************************************
 * xbar								 																	 *
 *********************************************************/	
void init_xbar(void){
// Enable Crossbar
	XBR2 = 0x40;
}

/*********************************************************
 * platform init			 																	 *
 *********************************************************/	
void init_platform(void){
	PCA0MD = 0;
	// 0x00 Select 24.5 MHz internal oscillator 0 (HFOSC0)
	// 0x03 Select 49.0 MHz internal oscillator 1 (HFOSC1)
	CLKSEL    = 0x00;
	
	// Disable WDT
	WDTCN = 0xDE;
	WDTCN = 0xAD;
	
	init_xbar();
	init_timer0_int();
}
 
/*********************************************************
 * my main loop			  																	 *
 *********************************************************/
void main()
{
	init_platform();
	
	IE_EA = 1;
	
	while(1){
		
		P3 ^= 1 << 3; // Toggle RGB led in blue
		while(!timeout);
		timeout = 0;
	}
}

/*********************************************************
 * timer0 init			  																	 *
 *********************************************************/
void init_timer0_int(void){
	
	CKCON0 = 0x4;
	TMOD = 0x01;
	
	TH0 = (-24500>>8);
	TL0 = (-24500);
	
	TCON_TR0 = 1;
	
	IE_ET0 = 1;
}
