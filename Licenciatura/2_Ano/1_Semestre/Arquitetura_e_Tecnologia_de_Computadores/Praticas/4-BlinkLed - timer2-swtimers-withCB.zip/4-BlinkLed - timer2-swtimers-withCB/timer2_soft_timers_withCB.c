#include <REG51F380.H>
#include "types.h"

sbit seg_A = P2^0;
sbit seg_B = P2^1;
sbit seg_C = P2^2;
sbit seg_D = P2^3;


// Set 4 software timers
#define NUM_SOFT_TIMERS 4

// Set timer tick to 1 ms
#define TIMER_TICK_MS 1  		

// defines a new type, timer_callback_t, for function pointer
typedef void (*timer_callback_t)(void);

// Initiate software timers array
unsigned int soft_timers[NUM_SOFT_TIMERS] = {0};

// Array of callback functions
timer_callback_t callbacks[NUM_SOFT_TIMERS]; 

/*********************************************************
* system_init function																	 *
**********************************************************/	
void system_init(void) {
		// Disable watchdog
    PCA0MD    &= ~0x40;
    PCA0MD    = 0x00;
		// Flash scale
    FLSCL     = 0x90;
		// Clock select = 48MHz
    CLKSEL    = 0x03;
		// Crossbar enable for IOs - 7-seg display	
    XBR1      = 0x40;    
}

/*********************************************************
* timer2_init_auto function															 *
**********************************************************/	
void timer2_init_auto(int reload) {
	
		// Timer 2 control register
    TMR2CN = 0;        
		// Use system clock
    CKCON &= ~(1 << 5);

		// set load values
    TMR2H = (reload) >> 8;
    TMR2L = (reload);

		// set auto reload values for autoreload mode
    TMR2RLH = (reload) >> 8;
    TMR2RLL = (reload);
}

/*********************************************************
* Timer 2 ISR													 									 *
**********************************************************/	
void timer2_isr(void) interrupt 5 using 2 {
	
	unsigned char i;

  // Decrement each software timer if it's not zero
  for (i = 0; i < NUM_SOFT_TIMERS; i++) {
		if (soft_timers[i] > 0) {
			soft_timers[i]--;
      
      // Check if the timer has reached zero and a callback is set
			if (soft_timers[i] == 0 && callbacks[i] != 0) {
				// Call the associated callback function
				callbacks[i](); 
			}
		}
	}
	
	TF2H = 0;  // Clear Timer 2 overflow flag
}

/*********************************************************
* Set a software timer with a callback									 *
**********************************************************/	
void set_software_timer(unsigned char timer_id, unsigned int ms_duration, timer_callback_t callback) {
	
	if (timer_id < NUM_SOFT_TIMERS) {
		soft_timers[timer_id] = ms_duration / TIMER_TICK_MS; // Convert ms to tick count
		callbacks[timer_id] = callback; // Assign the callback function
		}
}

/*********************************************************
 * Example callback functions														 *
 *********************************************************/
void timer0_callback(void) {
  seg_A ^= 1; // Toggle segA
	set_software_timer(0, 250, timer0_callback);
}

void timer1_callback(void) {
  seg_B ^= 1; // Toggle segA
	set_software_timer(1, 300, timer1_callback);
}

void timer2_callback(void) {
  seg_C ^= 1; // Toggle segA
	set_software_timer(2, 621, timer2_callback);
}

void timer3_callback(void) {
  seg_D ^= 1; // Toggle segA
	set_software_timer(3, 78, timer3_callback);
}

/*********************************************************
 * Main Loop																						 *
 *********************************************************/
void main (void) {
	
	system_init();

	// Set Timer 2 to overflow every 1ms
	// (with a 4 MHz clock, 1ms = 4000 ticks)
	timer2_init_auto(-4000); 

	TF2H = 0;  // Clear overflow flag
	ET2 = 1;   // Enable Timer 2 interrupt
	TR2 = 1;   // Start Timer 2

	EA = 1;    // Enable global interrupts

	// Set multiple software timers with different intervals and callbacks
	set_software_timer(0, 250, timer0_callback); // 250 ms, callback on expiration
	set_software_timer(1, 300, timer1_callback); // 300 ms
	set_software_timer(2, 621, timer2_callback);  // 621 ms
	set_software_timer(3, 78, timer3_callback); // 78 seconds

	while (1) {
		
			// Do what ever you want HERE!!
	}
}