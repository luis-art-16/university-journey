#include <REG51F380.H>
#include "types.h"

sbit seg_A = P2^0;
sbit seg_B = P2^1;
sbit seg_C = P2^2;
sbit seg_D = P2^3;

// Set 4 software timers
#define NUM_SOFT_TIMERS 4

// Set timer tick to 1 ms
#define TIMER_TICK_MS 1 

// Initiate software timers array
unsigned int soft_timers[NUM_SOFT_TIMERS] = {0};

/*********************************************************
* system_init function																	 *
**********************************************************/	
void system_init(void) {
		// Disable watchdog
    PCA0MD    &= ~0x40;
    PCA0MD    = 0x00;
		// Flash scale
    FLSCL     = 0x90;
		// Clock select = 48MHz
    CLKSEL    = 0x03;
		// Crossbar enable for IOs - 7-seg display	
    XBR1      = 0x40;    
}

/*********************************************************
* timer2_init_auto function															 *
**********************************************************/	
void timer2_init_auto(int reload) {
	
		// Timer 2 control register
    TMR2CN = 0;        
		// Use system clock
    CKCON &= ~(1 << 5);

		// set load values
    TMR2H = (reload) >> 8;
    TMR2L = (reload);

		// set auto reload values for autoreload mode
    TMR2RLH = (reload) >> 8;
    TMR2RLL = (reload);
}

/*********************************************************
* Timer 2 ISR													 									 *
**********************************************************/	
void timer2_isr(void) interrupt 5 using 2 {
    unsigned char i;

    // Decrement each software timer if it's not zero
    for (i = 0; i < NUM_SOFT_TIMERS; i++) {
        if (soft_timers[i] > 0) {
            soft_timers[i]--;
        }
    }

    TF2H = 0;  // Clear Timer 2 overflow flag
}

/*********************************************************
* Set a software timer with a callback									 *
**********************************************************/	
void set_software_timer(unsigned char timer_id, unsigned int ms_duration) {
	if (timer_id < NUM_SOFT_TIMERS) {
	soft_timers[timer_id] = ms_duration / TIMER_TICK_MS; // Convert ms to tick count
	}
}

/*********************************************************
 * Main Loop
 *********************************************************/
void main (void) {

	system_init();

	// Set Timer 2 to overflow every 1ms
	// (with a 4 MHz clock, 1ms = 4000 ticks)
	timer2_init_auto(-4000); 
	

	TF2H = 0;  // Clear overflow flag
	ET2 = 1;   // Enable Timer 2 interrupt
	TR2 = 1;   // Start Timer 2
	EA = 1;    // Enable global interrupts

	// Set multiple software timers with different intervals
	set_software_timer(0, 1000); // 1 second timer
	set_software_timer(1, 2000); // 2 second timer
	set_software_timer(2, 500);  // 500ms timer
	set_software_timer(3, 3000); // 3 second timer

	while (1) {
			// Check if any software timer has expired
			if (soft_timers[0] == 0) {
							seg_A ^= 1; // Toggle segA
					set_software_timer(0, 1000); // Reset to 1 second
			}

			if (soft_timers[1] == 0) {
							seg_B ^= 1; // Toggle segA
					set_software_timer(1, 2000); // Reset to 2 seconds
			}

			if (soft_timers[2] == 0) {
							seg_C ^= 1; // Toggle segA
					set_software_timer(2, 500); // Reset to 500ms
			}

			if (soft_timers[3] == 0) {
							seg_D ^= 1; // Toggle segA
					set_software_timer(3, 3000); // Reset to 3 seconds
			}
	}
}