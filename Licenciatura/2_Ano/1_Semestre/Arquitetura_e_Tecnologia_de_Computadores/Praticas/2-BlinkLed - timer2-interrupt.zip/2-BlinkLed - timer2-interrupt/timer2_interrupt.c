#include <REG51F380.H>
#include "types.h"


/* P2 = 0xA0 */
sbit seg_dp = P2^7;

static int blink = 100;

/*********************************************************
* system_init function																	 *
**********************************************************/	
void system_init(void) {
		// Disable watchdog
    PCA0MD    &= ~0x40;
    PCA0MD    = 0x00;
		// Flash scale
    FLSCL     = 0x90;
		// Clock select = 48MHz
    CLKSEL    = 0x03;
		// Crossbar enable for IOs - 7-seg display	
    XBR1      = 0x40;    
}

/*********************************************************
* timer2_init_auto function															 *
**********************************************************/	
void timer2_init_auto(int reload) {
	
		// Timer 2 control register
    TMR2CN = 0;        
		// Use system clock
    CKCON &= ~(1 << 5);

		// set load values
    TMR2H = (reload) >> 8;
    TMR2L = (reload);

		// set auto reload values for autoreload mode
    TMR2RLH = (reload) >> 8;
    TMR2RLL = (reload);
}

/*********************************************************
* Timer 2 ISR													 									 *
**********************************************************/	
void timer2_isr(void) interrupt 5 using 2 {
	// sysclock /12 = 4MHz
	// 1s 4,000,000 ticks!
	// 10ms => 40000 ticks!
	
	if(--blink == 0){
		seg_dp ^= 1;
		blink = 100;
	}
		
	TF2H = 0;	
}

/*********************************************************
 * Main Loop																						 *
 *********************************************************/
void main (void){
	
	system_init();

	// Set Timer 2 to overflow every 10 ms
	// (with a 4 MHz clock, 10 ms = 40000 ticks)
	timer2_init_auto(-40000); 

	//Set by hardware when the Timer 2 high byte overflows from 0xFF to 0x00. In 16 bit 
	//mode, this will occur when Timer 2 overflows from 0xFFFF to 0x0000. 	
	TF2H = 0;	
	// Enable Flag Timer 2 Overflow
	ET2 = 1;
	// Timer 2 Run Control. 
	// Timer 2 is enabled by setting this bit to 1. 
	TR2 = 1;
	// Enable All Interrupts.
	EA = 1;	
	
	while(1);
	
	
	// do whatever you want!!!!!!!!!!!!
	
}

