#include <REG51F380.H>
#include <stdio.h>
#include "types.h"


/*********************************************************
 * function prototypes 																	 *
 *********************************************************/
void init_device(void);
 
void function_state_start(void);
void function_state_1(void);
void function_state_2(void);
void function_state_3(void);
void function_state_4(void);

/*********************************************************
 * variables and types 																	 *
 *********************************************************/
 
typedef enum ENUM_STATES {state_start = 0, state_1, state_2, state_3, state_4} e_states; 

e_states state, nextstate;

/*********************************************************/	
void init_device(void){
	
  /* Disable WDT */
	PCA0MD    = 0x00;
	/* select clock source */
	FLSCL     = 0x90;
	CLKSEL    = 0x03;
	/* enable cross-bar for I/Os */
  XBR1      = 0x40;
	/* enable uart0 with TX pin on P0.4 and RX pin on P0.5 */
	XBR0      = 0x01;
}

/*********************************************************
 * encode_FSM_switch  																	 *
 *********************************************************/
void encode_FSM_switch(){
		switch (state) {
			case state_start:
							function_state_start();
							break;
			case state_1:
							function_state_1();
							break;
			case state_2:
							function_state_2();
							break;
			case state_3:
							function_state_3();
							break;
			case state_4:
							function_state_4();
							break;
			default: break;
		}
}

/*********************************************************
 * state functions	  																	 *
 *********************************************************/

void function_state_start(void){
	
		P2 = 0x3F;
		nextstate = state_1;
}

void function_state_1(void){
		P2 = 0x79;
		nextstate = state_2;
}

void function_state_2(void){
		P2 = 0x24;
		nextstate = state_3;
}

void function_state_3(void){
		P2 = 0x30;
		nextstate = state_4;
}

void function_state_4(void){
		P2 = 0x19;
		nextstate = state_1;
}

/*********************************************************
 * my main loop			  																	 *
 *********************************************************/
void main (void){
		
	init_device();	

	state = nextstate = state_start;

	while (1) {	
		
		encode_FSM_switch();
		state = nextstate;
	}
}
