#include <REG51F380.H>
#include "lcd.h"

// LCD adresses
#define LCD_ADDR_W 0x4E
#define LCD_ADDR_R 0x4F

// 0xFFFF - Frequency
#define RELOAD 34286     

char horas[6] = "23:59";
static volatile int segundos = 0;


void updateHora(void);
void relogio(void);
void init_device(void);
void timer_init(void);
void lcd_config(void);
void config_hora(void);

void relogio(void) {
		
	updateHora();

}	

void config_hora(void) {
	
	TR0 = 0;  // stop Timer 0
	
	lcd1602Clear(LCD_ADDR_W);
	
	lcd1602Control(LCD_ADDR_W, 1,0,0);
	lcd1602SetCursor(LCD_ADDR_W, 5, 0);
	lcd1602WriteString(LCD_ADDR_W, horas);
	
	lcd1602Control(LCD_ADDR_W, 1,0,0);
	lcd1602SetCursor(LCD_ADDR_W, 3, 1);
	lcd1602WriteString(LCD_ADDR_W, "HOUR CONFIG");
	
	
	
	while(1) {
	
		if(pb1 == 0) {
			
				horas[1] += 1;
				updateHora();
				lcd_config();	
		}
			
		if(pb2 == 0) {
		
			delay();	
			break;
		}
	
	}
	
	while(1) {
	
		if(pb1 == 0) {
			
			horas[4] += 1;
			updateHora();
			lcd_config();
		
		}
	
		if(pb2 == 0) {
		
			delay();
			
			lcd1602SetCursor(LCD_ADDR_W, 3, 1);
			lcd1602WriteString(LCD_ADDR_W, "CONFIG OVER");
			
			delay();
			
			break;
		}
	
		
	}
	
	segundos = 0;
	
	lcd_config();
	lcd1602SetCursor(LCD_ADDR_W, 1, 1);
	lcd1602WriteString(LCD_ADDR_W, "DIG CLOCK 8051");
	
	
	TR0 = 1;  // restart Timer 0
	
}

void lcd_config(void) {

		
	lcd1602SetCursor(LCD_ADDR_W, 5, 0);
	
	lcd1602WriteString(LCD_ADDR_W, horas);

}

void updateHora(void) {
	
				if (segundos > 59) {
						segundos = 0;
            horas[4]++;
						lcd_config();
        }

        if (horas[4] > '9') {
            horas[4] = '0';
            horas[3]++;
						lcd_config();
				}

        if (horas[3] > '5') {
            horas[3] = '0';
            horas[1]++;
						lcd_config();
        }

        // Como o rel�gio � 24h, checar se as dezenas da hora s�o 20 (nesse caso so podemos ter at� 23:59:59 -> 00:00:00)
        if (horas[0] > '1' && horas[1] > '3') {
            horas[0] = horas[1] = horas[3] = horas[4] = '0';
						lcd_config();
				}

        if (horas[1] > '9' && horas[0] < '2' && horas[0] >= '0') {
            horas[1] = '0';
            horas[0]++;
						lcd_config();
        }
}

void timer_init(void) {
		
	CKCON |= 0x02;  // SYSCLK / 48 F = 31.250 KHz 
	TMOD |= 0x01;   // 16 bit mode
	
	ET0 = 1;
	EA = 1;
	
	TF0 = 0;
	
	TH0 = (RELOAD) >> 8;
	TL0 = (RELOAD);  
	
	TR0 = 1;
}

void timer0_isr() interrupt 1 {

	TH0 = (RELOAD) >> 8;
	TL0 = (RELOAD); 
	
	segundos++;
	TF0 = 0;
	
}

void init_device(void) {

	PCA0MD = 0x00;
	FLSCL     = 0x90;
	XBR1      = 0x40;
	
	timer_init();
}

void main() {
	
	int rc;
	init_device();
	
	rc = lcd1602Init(LCD_ADDR_W);
	lcd1602Clear(LCD_ADDR_W);
	lcd1602Control(LCD_ADDR_W, 1,0,0); // backlight on, underline off, blink block on 
	
	if(rc)
		while(1);
	
	else {
		
		lcd1602SetCursor(LCD_ADDR_W, 5, 0);
	
		lcd1602WriteString(LCD_ADDR_W, horas);
		
		lcd1602SetCursor(LCD_ADDR_W, 1, 1);
	
		lcd1602WriteString(LCD_ADDR_W, "DIG CLOCK 8051");
		
		while(1) {
			relogio();
		}
	}
}