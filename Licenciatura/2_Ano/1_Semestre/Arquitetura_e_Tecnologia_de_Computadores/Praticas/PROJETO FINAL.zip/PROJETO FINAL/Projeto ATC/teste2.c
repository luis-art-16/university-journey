#include <REG51F380.H>
#include <stdio.h>
#include "types.h"
#include "lcd1602.h"
#include <stdlib.h>

#define LCD_ADDR_W 0x4E
#define LCD_ADDR_R 0x4F

// Defini��o de pinos UART
// init uart 0
void uart0_init(void);
sbit pb1 = P0^6;
sbit pb2 = P0^7;
void Init_Device(void);
/*******************/
char p1;
char p2;
code char message_u0[] = "FCF";
code char message_a0[] = "COR";
// Vari�veis globais do cron�metro
volatile uint8_t segundos = 0;
volatile uint8_t minutos = 0;
int cronometro_ativo = 0;  // Flag para indicar se o cron�metro est� ativo
int contagem = 0;
bit pb1_habilitado = 1;
bit pb2_habilitado = 1;
int pb1_pressed = 0;
int pb2_pressed = 0;
/*******************/	
void increaseStr1(char* str1) {
    int value = atoi(str1);
    value++;
    sprintf(str1, "%d", value);
}

// Function to increase the value of str2
void increaseStr2(char* str2) {
    int value = atoi(str2);
    value++;
    sprintf(str2, "%d", value);
}

void updateCount(char* str3) {
    int value = atoi(str3);
    value += 1;
    if (value > 90) {
        value = 90;
        pb1 = 0;
        pb2 = 0;
    }
    sprintf(str3, "%d", value);
}

void timer0_isr() interrupt 1 {
    TH0 = 0xFC;  // Recarrega o temporizador para um atraso de 1 ms
    TL0 = 0x67;

    segundos++;

    if (segundos == 1) {
        segundos = 0;
        minutos++;

        if (minutos >= 90) {  // Interrompe o cron�metro ap�s 90 minutos
            TR0 = 0;  // Desativa o Timer 0
        }
    }
}

void Init_Device(void){
    /* Disable WDT */
    PCA0MD    = 0x00;
    /* select clock source */
    FLSCL     = 0x90;
    CLKSEL    = 0x03;
    // To Work with the i2c/LCD
    P0MDOUT   = 0x04;
    /* enable cross-bar for I/Os */
    XBR1      = 0x40;
    /* enable uart0 with TX pin on P0.4 and RX pin on P0.5 */
    XBR0      = 0x01;
}

void uart0_init(void){    
    /* UART0 Control                            */
    /* set REN0, enable reception                */
    SCON0     = 0x10;
    /* Timer/Counter Mode                       */    
    TMOD      = 0x20;
    /* Clock Control                            */
    CKCON     = 0x08;
    /* Timer/Counter 1 High                     
     * 0x30 generates a baudrate of 115200 bps  */
    TH1       = 0x30;
    /* Timer 1 On/Off Control                    
     */
    TR1       = 1;
    /* UART0 TX Interrupt Flag                  */
    TI0       = 1;
    RI0 = 1;
}

void debounce() {
    // Simple delay for button debounce
    unsigned int i, j;
    for (i = 0; i < 500; i++)
        for (j = 0; j < 500; j++);
}

void main (void){
    // to store the received or transmitted byte
    char c = 0;    
    int rc;
    int pb1_pressed = 0;
    int pb2_pressed = 0;
    Init_Device();  
    uart0_init();
     
    EA=1;
    TMOD |= 0x01;  // Configura temporizador 0 em modo 1 (16 bits)
    TH0 = 0xFE;    // Configura byte mais significativo da recarga
    TL0 = 0x18;    // Configura byte menos significativo da recarga
    ET0 = 1;       // Habilita interrup��o do temporizador 0
    TR0 = 1;       // Inicia o temporizador 0

    while(pb1);
    while(!pb1);

    rc = lcd1602Init(LCD_ADDR_W); 
    if (rc)
    {
        while(1);
    }

    while(1) {
        char str1[5] = {0};
        char str2[5] = {0};
        char str3[5] = {0};
        char str4[5] = {0};
        p1 = 0;
        p2 = 0;
        sprintf(str1, "%d", p1);
        sprintf(str2, "%d", p2);
        sprintf(str3, "%d", contagem);
        sprintf(str4, "%d", segundos);
            
        lcd1602Clear(LCD_ADDR_W);    // clear the memory

        lcd1602Control(LCD_ADDR_W, 1, 0, 1); // backlight on, underline on, blink block on 
        
        lcd1602SetCursor(LCD_ADDR_W, 1, 0);
        
        while (pb1);  // Aguarda ambos os bot�es serem soltos
        while (!pb1);  // Aguarda ambos os bot�es serem pressionados simultaneamente
        
        lcd1602WriteString(LCD_ADDR_W, message_u0);
            
        lcd1602Control(LCD_ADDR_W, 1, 1, 1); // backlight on, underline off, blink block on 
        
        lcd1602SetCursor(LCD_ADDR_W, 12, 0);
        
        while(pb1);
        while(!pb1);
        
        lcd1602WriteString(LCD_ADDR_W, message_a0);
            
        lcd1602Control(LCD_ADDR_W, 1, 1, 1); // backlight on, underline off, blink block on 
        
        lcd1602SetCursor(LCD_ADDR_W, 2, 1);
        
        while(pb1) 
            while(!pb1);
    
        lcd1602WriteString(LCD_ADDR_W, str1);
            
        lcd1602Control(LCD_ADDR_W, 1, 1, 1); // backlight on, underline off, blink block on 
        
        lcd1602SetCursor(LCD_ADDR_W, 13, 1);
                    
        lcd1602WriteString(LCD_ADDR_W, str2);
            
        lcd1602SetCursor(LCD_ADDR_W, 7, 1);
    
        while(pb1) 
            while(!pb1);
    
        lcd1602WriteString(LCD_ADDR_W, str3);

        lcd1602Control(LCD_ADDR_W, 1, 1, 1); // backlight on, underline off, blink block on
        lcd1602SetCursor(LCD_ADDR_W, 8, 1);

        lcd1602WriteString(LCD_ADDR_W, str4);

        lcd1602SetCursor(LCD_ADDR_W, 2, 1); 
        
        while (1) {
            // Simple delay for button debounce
            debounce();

            if (pb1 == 1 && pb2 == 0) {
                if (!pb1_pressed) {
                    increaseStr1(str1);
                    lcd1602SetCursor(LCD_ADDR_W, 2, 1);
                    lcd1602WriteString(LCD_ADDR_W, str1);
                    pb1_pressed = 1;
                }
            } else {
                pb1_pressed = 0;
            }

            if (pb1 == 0 && pb2 == 1) {
                if (!pb2_pressed) {
                    increaseStr2(str2);
                    lcd1602SetCursor(LCD_ADDR_W, 13, 1);
                    lcd1602WriteString(LCD_ADDR_W, str2);
                    pb2_pressed = 1;
                }
            } else {
                pb2_pressed = 0;
            }

            // Update the count every second
            if (segundos == 0) {
                updateCount(str3);
                lcd1602SetCursor(LCD_ADDR_W, 7, 1);
                lcd1602WriteString(LCD_ADDR_W, str3);
            }
				  
        }
    }
}