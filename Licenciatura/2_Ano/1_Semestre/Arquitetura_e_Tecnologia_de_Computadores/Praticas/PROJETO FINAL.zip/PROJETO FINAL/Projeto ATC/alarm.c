#include <REG51F380.H>
#include "init_device.h"
#include <string.h>

#define B_TF3H 7
#define B_TR3 2
#define B_ET3 7

unsigned char alarmConfigurado = 0;
unsigned char alarmHoras = 0;
unsigned char alarmMinutos = 0;
unsigned char inputAlarmBuffer[5]; 
unsigned char bufferAlarmIndex = 0;

char horas[6] = "23:59";
static volatile int minutos = 0;
static volatile int segundos = 0;

void timer3_init_auto(int reload){

	TMR3CN = 0;

	#define B_T3MH 7	

	CKCON &= ~((1 << B_T3MH));
	
	TMR3H = (reload) >> 8;
	TMR3L = (reload);

	TMR3RLH = (reload) >> 8;
	TMR3RLL = (reload);
	
}

void timer2_init_auto(int reload){

	TMR2CN = 0;

	#define B_T2MH 5	

	CKCON &= ~((1 << B_T2MH));
	
	TMR2H = (reload) >> 8;
	TMR2L = (reload);

	TMR2RLH = (reload) >> 8;
	TMR2RLL = (reload);
	
}

void delay_250us(){
	while(!(TMR3CN & (1 << B_TF3H)));
	TMR3CN &= ~(1 << B_TF3H);  
}

void delay_s(unsigned char s) {
    unsigned char i = 0;

    while(i != (s*100)) {
        i++;
        while(!TF2H);
        TF2H = 0;
    }
}



char uartAlarm() {
    if (RI0 == 1) {
        RI0 = 0;

        if (bufferAlarmIndex < 5) {
         
            inputAlarmBuffer[bufferAlarmIndex] = SBUF0;
            bufferAlarmIndex++;
        }

        if (bufferAlarmIndex == 5) {
            if (inputAlarmBuffer[0] == 's' && inputAlarmBuffer[1] == 'e' && inputAlarmBuffer[2] == 't') {
                
		alarmHoras = (inputAlarmBuffer[3] - '0') % 24; // intervalo de 0-23
                alarmMinutos = (inputAlarmBuffer[4] - '0') % 60; // intervalo de 0-59
                
		 alarmConfigurado = 1;
               
		 bufferAlarmIndex = 0;
               
		 return 0;
            		
	} else {
                bufferAlarmIndex = 0;
            }
        }
    }
    return 1;
}

void square_wave(){
	char loop = 1;
	while (loop){
		loop = uartAlarm();
		//HIGH
		P1 |= 0x80;
		delay_250us();
		//LOW
		P1 &= ~(0x80);
		delay_250us();
	}
}

void verificarAlarm() {
    if (alarmConfigurado) {
        if (horas == alarmHoras && minutos == alarmMinutos) {
           
           square_wave();
        }
    }
}

void main(void) {
    Init_Device();
        
        timer3_init_auto(-1000);
        timer2_init_auto(-40000);	
	
	TF2H = 0;
	TMR3CN &= ~(1 << B_TF3H);
		
	ET2 = 1;
	EIE1 |= (1 << B_ET3);
	
	TR2 = 1;
	TMR3CN |= (1 << B_TR3);

    while (1) {
        
        uartAlarm(); 
        verificarAlarm(); 
    }
}
