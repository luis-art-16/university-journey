#include <REG51F380.H>
#include "init_device.h"

void Init_Device(void)
{
	PCA0MD    = 0x00;
  /* clock source */
	FLSCL     = 0x90;		
  CLKSEL    = 0x03;  	
	
	/* enable cross-bar for I/Os */
	XBR1      = 0x41;
	XBR0		 	= 0x01;
	
	//P1.2 output ALARM
	P1MDOUT |= (1 << 2 );
	
}