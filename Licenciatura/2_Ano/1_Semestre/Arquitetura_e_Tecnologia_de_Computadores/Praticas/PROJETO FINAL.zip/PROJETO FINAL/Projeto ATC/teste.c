#include <REG51F380.H>
#include "lcd.h"
#include <string.h>

// LCD addresses
#define LCD_ADDR_W 0x4E
#define LCD_ADDR_R 0x4F

// Timer0 Reload Value - 0xFFFF - Frequency
#define RELOAD 34286

char horas[6] = "23:59";
static volatile int segundos = 0;
static volatile int minutos = 0;

unsigned char alarmConfigurado = 0;
unsigned char alarmHoras = 0;
unsigned char alarmMinutos = 0;

void updateHora(void);
void relogio(void);
void init_device(void);
void timer_init(void);
void lcd_config(void);
void verificarAlarm(void);
void square_wave(void);

void timer_init(void) {
    CKCON |= 0x02;  // SYSCLK / 48 F = 31.250 KHz
    TMOD |= 0x01;   // 16 bit mode

    ET0 = 1;
    EA = 1;

    TF0 = 0;

    TH0 = (RELOAD) >> 8;
    TL0 = (RELOAD);

    TR0 = 1;
}

void timer0_isr(void) interrupt 1 {
    TH0 = (RELOAD) >> 8;
    TL0 = (RELOAD);

    segundos++;

    if (segundos > 59) {
        segundos = 0;
        minutos++;
        lcd_config();
    }

    if (minutos > 59) {
        minutos = 0;
    }

    verificarAlarm();

    TF0 = 0;
}

void lcd_config(void) {
    lcd1602SetCursor(LCD_ADDR_W, 5, 0);
    lcd1602WriteString(LCD_ADDR_W, horas);
}

void updateHora(void) {
    if (segundos > 59) {
        segundos = 0;
        minutos++;
        lcd_config();
    }

    if (minutos > 59) {
        minutos = 0;
    }
}

void verificarAlarm(void) {
    if (alarmConfigurado && horas[0] == alarmHoras && minutos == alarmMinutos) {
        square_wave();
    }
}

void square_wave(void) {
    char loop = 1;
    while (loop) {
        loop = uartAlarm();
        // HIGH
        P1 |= 0x80;
        delay_250us();
        // LOW
        P1 &= ~(0x80);
        delay_250us();
    }
}

void init_device(void) {
    PCA0MD = 0x00;
    FLSCL = 0x90;
    XBR1 = 0x40;
    P1MDOUT |= (1 << 2); // Configura P1.2 como sa�da
    timer_init();
}

void main(void) {
    int rc;
    init_device();

    rc = lcd1602Init(LCD_ADDR_W);
    lcd1602Clear(LCD_ADDR_W);
    lcd1602Control(LCD_ADDR_W, 1, 0, 0);  // backlight on, underline off, blink block on

    if (rc) {
        while (1);
    } else {
        lcd1602SetCursor(LCD_ADDR_W, 5, 0);
        lcd1602WriteString(LCD_ADDR_W, horas);

        lcd1602SetCursor(LCD_ADDR_W, 1, 1);
        lcd1602WriteString(LCD_ADDR_W, "DIG CLOCK 8051");

        while (1) {
            relogio();
        }
    }
}
