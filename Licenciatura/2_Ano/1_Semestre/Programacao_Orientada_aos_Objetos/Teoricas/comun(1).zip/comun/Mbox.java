
/**
 * Write a description of class Mbox here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.ArrayList;
public class Mbox
{
    // instance variables - replace the example below with your own
    private int num;
    private ArrayList<Comunicacao> lista;
    
    /**
     * Constructor for objects of class Mbox
     */
    public Mbox(int n)
    {
        // initialise instance variables
        this.num = n;
        this.lista = new ArrayList<Comunicacao>();
    }

    // inserir
    public void add(Comunicacao c)
    {
        if(c != null)
            this.lista.add(c.clone());
    }
    
    public int numCom()
    {
        return this.lista.size();
    }
    
    public double valorNum(int n)
    {
        double tot = 0.0;
        for(Comunicacao c : this.lista)
            if(c.getNum() == n)
                tot += c.valor();
                
        return tot;
    }
    
    // como ainda não falamos de tabelas de hash vamos simular algo similar!
    public int maisSMSs()
    {
        ArrayList<Integer> ns = new ArrayList<Integer>();
        ArrayList<Integer> qty = new ArrayList<Integer>();
        
        for(Comunicacao c : this.lista)
        {
            if(c instanceof SMS)
            {
                int x = ns.indexOf(new Integer(c.getNum()));
                if( x != -1)
                    qty.set(x,qty.get(x) + 1);
                else
                {
                    ns.add(c.getNum());
                    qty.add(1);
                }
            }
        }
        
        int max = 0;
        for(int i=0; i < ns.size(); i++)
        {
            if(qty.get(i) > qty.get(max))
                max = i;
        }
        
        return ns.get(max);
    }
    
    public int num_audiveis()
    {
        int conta = 0;
        for(Comunicacao c : this.lista)
            if(c instanceof Audivel)
                conta++;
        return conta;
    }
    
    public int soma_freq()
    {
        int conta = 0;
        for(Comunicacao c : this.lista)
            if(c instanceof Audivel)
            {
                Audivel a = (Audivel)c;
                conta += a.frequencia();
            }
        return conta;
    }
}
