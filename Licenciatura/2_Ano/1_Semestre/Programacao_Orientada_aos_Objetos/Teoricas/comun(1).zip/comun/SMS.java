
/**
 * Write a description of class SMS here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class SMS extends Comunicacao
{
    // instance variables - replace the example below with your own
    private String texto;

    /**
     * Constructor for objects of class SMS
     */
    public SMS(int n, int d, double p, String s)
    {
        // initialise instance variables
        super(n,d,p);
        this.texto = s;
    }

    public int getDura()
    { return this.texto.length();}
    
    public double valor()
    {
        return this.getDura() * 0.001;
    }
    
    public SMS clone()
    {
        return new SMS(super.getNum(),super.getDura(),super.getPreco(),this.texto);
    }
}
