
/**
 * Write a description of class Ring here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Ring extends SMS implements Audivel
{
    // instance variables - replace the example below with your own
    private int toque;

    /**
     * Constructor for objects of class Ring
     */
    public Ring(int n, int d, double p, int t)
    {
        // initialise instance variables
        super(n,d,p,"");
        this.toque = t;
        
    }

    public int getToque()
    { return this.toque;}
    
    public int getDura()
    { return this.toque;}
    public  double valor()
    {
        return 0.10 * this.getDura();
    }
    
    public int frequencia()
    {
        return 99 * this.getDura();
    }
}
