
/**
 * Abstract class Comunicacao - write a description of the class here
 *
 * @author (your name here)
 * @version (version number or date here)
 */
public abstract class Comunicacao
{
    // instance variables - replace the example below with your own
    private int num;
    private int dura;
    private double preco;
    
    public Comunicacao(int n, int d, double p)
    {
        this.num = n; this.dura = d; this.preco = p;
    }
    
    public int getNum()
    { return this.num;}
    public int getDura()
    { return this.dura;}
    public double getPreco()
    { return this.preco;}
    
    public boolean equals(Object o)
    {
	if ( this == o ) return true; // é o próprio !!
	if ( o == null ) return false;
	if ( this.getClass() != o.getClass() ) return false;
	// Aqui temos a certeza que é um Ponto3D
	Comunicacao pp = (Comunicacao) o; // casting obrigatório
	return this.getNum() == pp.getNum();
    }
    
    public abstract double valor();
    public abstract Comunicacao clone();
    
    
    
}
