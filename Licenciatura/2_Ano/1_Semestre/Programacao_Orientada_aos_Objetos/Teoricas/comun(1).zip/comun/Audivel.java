
/**
 * Write a description of interface Audivel here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public interface Audivel
{
    /**
     * An example of a method header - replace this comment with your own
     *
     * @param  y a sample parameter for a method
     * @return   the result produced by sampleMethod
     */
    int frequencia();
}
