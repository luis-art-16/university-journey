
/**
 * Write a description of class Desportivo here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Desportivo extends Carro
{
    private int hp;
    
    Desportivo(int k, int a, double v, String m, int hp)
    {
        super(k,a,v,m);
        this.hp = hp;
    }
    
    Desportivo(Desportivo d)
    {
        super(d.getKms(),d.getIdade(), d.getValor(), d.getMat());
        this.hp = d.getHP();
    }
    
    public int getHP()
    {
        return this.hp;
    }
    
    public double valor_actual()
    { 
        double d = this.getValor();
        
        if(this.getIdade() <= 5)
            for(int x=1; x <=this.getIdade(); x++)
                d = d - d * 0.1;
        if(this.getIdade() > 5)
        {
            for(int x=1; x <=5; x++)
                d = d - d * 0.1;
            int fim = (this.getIdade() <= 25 ? this.getIdade() : 25);
            for(int x=6; x <= fim; x++)
                d = d - d * 0.05;
        }
        
        return d;
    }

    public Desportivo clone()
    {
        return new Desportivo(this);
    }
}
