
public class Carro
{ 
    private int kms;
    private int idade;
    private double valor;
    private String matricula;
     
    Carro(int k, int a, double v, String m)
    { this.kms = k; this.idade = a; this.valor = v; this.matricula = m; }

  public int getKms()
  { return this.kms;}
  public int getIdade()
  { return this.idade;}
  public double getValor()
  { return this.valor;}
  public String getMat()
  { return this.matricula;}
  public void setIdade()
  { this.idade++;}
  public void setKms(int inc)
  { this.kms += inc;}
  
  public double valor_actual()
  { return( (this.valor) -  (this.valor *(this.idade / 10)) - (this.valor  * (this.kms/1000000)));  }

  public Carro clone()
  { return new Carro(this.kms, this.idade, this.valor, this.matricula);}
  
  public boolean equals(Object o)
  {
      if(o == null)
          return false;
      if(o.getClass() != this.getClass())
          return false;
          
      Carro c = (Carro)o;
      
      return this.matricula.equals(c.getMat());
  }
}
