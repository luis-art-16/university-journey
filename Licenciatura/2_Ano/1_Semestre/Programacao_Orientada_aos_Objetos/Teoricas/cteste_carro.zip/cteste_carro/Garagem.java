
/**
 * Write a description of class Garagem here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.ArrayList;

public class Garagem
{
    private ArrayList<Carro> lista;
    
    Garagem()
    {
        this.lista = new ArrayList<Carro>();
    }
    
    public void insere(Carro c)
    {
        if(c != null)
            this.lista.add(c.clone());
    }
    
    public String maisAntigo()
    {
        Carro min = this.lista.get(0);
        
        for(Carro c : this.lista)
            if(c.getIdade() < min.getIdade())
                min = c;
                
        return min.getMat();
    }
    
    public double valor()
    {
        double tot = 0.0;
        for(Carro c : this.lista)
            tot += c.valor_actual();
            
        return tot;
    }
}
