
import java.util.*;
/**
 * Detec��o de pares de par�ntesis em express�es matem�ticas.
 */
public class para
{
    // m�todo para calcular express�es escritas em nota��o posfixa!
    public static double posfixo(String exp)
    {
        final String op = "+-*/"; // operadores possiveis
        // cria stack para guardar operandos
        Stack<Double> pilha = new Stack<Double>();
        
        // Tokenizer para obter as "palavras" da express�o
        StringTokenizer x = new StringTokenizer(exp," ");
        while(x.hasMoreTokens())
        {
            String tk = x.nextToken();
            
            int res = op.indexOf(tk); // � um operador??
            if(res != -1) // sim
            {
                // tira 2 operandos
                double a = pilha.pop();
                double b = pilha.pop();
                char sw = tk.charAt(0); // char do op
                double z = 0; // resultado
                switch(sw)
                {
                    case '+': z = a + b; break;
                    case '-': z = b - a; break;
                    case '*': z = a * b; break;
                    case '/': z = a / b; break;
                }
                pilha.push(z); // empilha resultado
            }
            else
                pilha.push(new Double(tk)); // caso contrario empilha operando
                
                
        }
        
        return pilha.pop(); // empilha resultado final da expressao
    }
    
    public static void processa(String exp)
    {
        // Representa��o dos parenteses
        final String abre = "{[(";
        final String fecha ="}])";
        
        // cria stack que serve de verificador de pares...
        Stack<String> pilha = new Stack<String>();
        
        // para cada caracter na express�o...
        for(int i=0; i < exp.length(); i++)
        {
            // retira caracter. NOTA: substring(primeiro char, ultimo char)...
            String parent = exp.substring(i,i+1); // inicio i e tamanho 1!!
            
            int x = abre.indexOf(parent);
            if(x != -1)  // � um parenteses de abertura?
               pilha.push(parent);  // guarda na stack
            else
            {   // caso contr�rio verifica se � de fecho...
                int y = fecha.indexOf(parent);
                if(!pilha.empty())  // pilha vazia?
                {
                  
                  if(y != -1)  // � mesmo parenteses de fecho?
                  {
                    String c = pilha.pop(); // vai buscar parenteses de abertura
                    if(y != abre.indexOf(c)) // par de parenteses errado?
                    {
                      System.out.println("Erro: o parenteses "+c+" � fechado pelo parenteses "+fecha.substring(y,y+1)+" em "+exp.substring(0,i+1));
                      return;
                    }
                  }
                }
                else
                {   
                    if(y != -1) // stack vazia mas temos um parenteses de fecho?
                    {
                      System.out.println("Erro: o parenteses "+fecha.substring(y,y+1)+" est� a mais em "+exp.substring(0,i+1));
                      return;
                    }
                }
            }
        }
        
        if(!pilha.empty())  // fim da express�o mas pilha n�o vazia??
        {
            System.out.println("Erro: Falta fechar o parenteses "+pilha.pop()+" em "+exp);
        }
        else
            System.out.println("A expressao "+exp+ " esta correcta");
    }
    
    
    // testar
    public static void main(String s[])
    {
        // string com a express�o matem�tica
        String exp = s[0];
        
        //System.out.println(exp);
        //processa(exp);
        
        System.out.println(exp+" = "+ posfixo(exp));
    }
    
}
