
/**
 * Write a description of class Conta here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class Conta
{
    
    private static int contas = 0;
    
    public static int getNC()
    { return Conta.contas;}
    
    // instance variables - replace the example below with your own
    private String titular;
    private double saldo;
    private int num;
    private ArrayList<Movs> movs;
    /**
     * Constructor for objects of class Conta
     */
    public Conta(String t, double i, int n)
    {
        // initialise instance variables
        this.titular = t;
        this.saldo = i;
        this.num = n;
        this.movs = new ArrayList<Movs>();
        this.movs.add(new Movs("saldo inicial",i));
        this.contas++;
    }
    public Conta()
    {
        this.titular = "";
        this.saldo = 0.0;
        this.movs = new ArrayList<Movs>();
        Conta.contas++;
    }
    
    public String getTitular()
    {
        return this.titular;
    }
    public double getSaldo()
    {
        return this.saldo;
    }
    public int getNum()
    {
        return this.num;
    }
    
    public boolean debito(int dia, int mes, int ano, String d, double v)
    {
        if(this.saldo - v >= 0.0)
        {
            this.movs.add(new Movs(dia,mes,ano,d,-1*v));
            this.saldo -= v;
            return true;
        }
        else
            return false;
    }
    public void credito(int dia, int mes, int ano, String d, double v)
    {
        this.movs.add(new Movs(dia,mes,ano,d,v));
        this.saldo += v;
    }
    
    public boolean equals(Conta c)
    {
        return c.getNum() == this.num;
    }
    
    public Conta clone()
    {
        Iterator<Movs> i = this.movs.iterator();
        Conta aux = null;
        if(i.hasNext())
            aux = new Conta(this.titular, i.next().getValor(), this.num);
        while(i.hasNext())
        {
            Movs temp = i.next();
            if(temp.getValor() < 0)
                aux.debito(temp.getDia(),temp.getMes(),temp.getAno(),temp.getDesc(),temp.getValor());
            else
                aux.credito(temp.getDia(),temp.getMes(),temp.getAno(),temp.getDesc(),temp.getValor());
        }       
        return aux;
    }
    
    public String toString()
    {
        String x = this.titular+","+this.num+","+this.saldo+",";
        for(Movs m: this.movs)
            x += m.toString();
        return x;
    }
}
