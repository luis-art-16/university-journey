
/**
 * Write a description of class Banco here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class Banco
{
    
    // instance variables - replace the example below with your own
    private String nome;
    private ArrayList<Conta> contas;


    /**
     * Constructor for objects of class Banco
     */
    public Banco(String n)
    {
        // initialise instance variables
        this.nome =n;
        this.contas = new ArrayList<Conta>();
    }

    public void nova(String t, double si, int n)
    {
        this.contas.add(new Conta(t,si,n));
    }
    
    public String getNome()
    { return this.nome;}
    
    public int num_contas()
    {
        return Conta.getNC();
    }
    
    public boolean debito(int dia, int mes, int ano, String d, double v, int n)
    {
        boolean flag = false;
        Iterator<Conta> i = this.contas.iterator();
        Conta aux = null;
        while(!flag && i.hasNext())
        {
            aux = i.next();
            if(aux.getNum() == n)
                flag = true;
        }
        if(flag)
            return aux.debito(dia,mes,ano,d,v);
        else
            return false;
    }
    public boolean credito(int dia, int mes, int ano, String d, double v, int n)
    {
        
        boolean flag = false;
        Iterator<Conta> i = this.contas.iterator();
        Conta aux = null;
        while(!flag && i.hasNext())
        {
            aux = i.next();
            if(aux.getNum() == n)
                flag = true;
        }
        if(flag)
            aux.credito(dia,mes,ano,d,v);
        
        return flag;
    }
    
    public void despesas(int dia, int mes, int ano, double v)
    {
        for(Conta c : this.contas)
        {
                c.debito(dia,mes,ano,"despesa bancaria", v);
        }
    }
    
    public double saldo()
    {
        double tot = 0.0;
        for(Conta c : this.contas)
        {
                tot += c.getSaldo();
        }
        
        return tot;
    }
}
