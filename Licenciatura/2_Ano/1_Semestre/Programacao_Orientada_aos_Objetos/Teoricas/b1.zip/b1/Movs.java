
/**
 * Write a description of class Movs here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class Movs
{
    // instance variables - replace the example below with your own
    private String desc;
    private double valor;
    private GregorianCalendar data;

    /**
     * Constructor for objects of class Movs
     */
    public Movs(int dia, int mes, int ano, String d, double v)
    {
        this.desc = d;
        this.valor = v;
        this.data = new GregorianCalendar(ano,mes,dia);
    }
    public Movs(String d, double v)
    {
        this.desc = d;
        this.valor = v;
        this.data = new GregorianCalendar();
    }
    
    public String getDesc()
    {
        return this.desc;
    }
    public double getValor()
    {
        return this.valor;
    }
    public GregorianCalendar getData()
    {
        return (GregorianCalendar)this.data.clone();
    }
    
    public String getData2()
    {
        return this.data.get(Calendar.YEAR)+"/"+this.data.get(Calendar.MONTH)+"/"+
        this.data.get(Calendar.DAY_OF_MONTH);
    }

    public int getDia()
    {
        return this.data.get(Calendar.DAY_OF_MONTH);
    }
    public int getMes()
    {
        return this.data.get(Calendar.MONTH);
    }
    public int getAno()
    {
        return this.data.get(Calendar.YEAR);
    }
    public Movs clone()
    {
        return new Movs(this.data.get(Calendar.DAY_OF_MONTH),data.get(Calendar.MONTH),this.data.get(Calendar.YEAR),this.desc,this.valor);
    }
    public String toString()
    {
        return this.getData2()+","+this.desc+","+this.valor;
    }
}
