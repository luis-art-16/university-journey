
/**
 * Write a description of class Banco here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Banco
{
    private static final int TAM2 = 1000;
    // instance variables - replace the example below with your own
    private String nome;
    private Conta[] contas;
    private int idx;

    /**
     * Constructor for objects of class Banco
     */
    public Banco(String n)
    {
        // initialise instance variables
        this.nome =n;
        this.contas = new Conta[TAM2];
    }

    public void nova(String t, double si, int n)
    {
        this.contas[idx++] = new Conta(t,si,n);
    }
    
    public String getNome()
    { return this.nome;}
    
    public int num_contas()
    {
        return Conta.getNC();
    }
    
    public boolean debito(int n, double v)
    {
        int i = 0;
        while(i < this.contas.length && this.contas[i].getNum() != n) i++;
        
        if(i < this.contas.length)
        {
            return this.contas[i].debito(v);
        }
        else
            return false;
    }
    public boolean credito(int n, double v)
    {
        int i = 0;
        while(i < this.contas.length && this.contas[i].getNum() != n) i++;
        
        if(i < this.contas.length)
        {
            this.contas[i].credito(v);
            return true;
        }
        else
            return false;
    }
    
    public void despesas(double v)
    {
        for(Conta c : this.contas)
        {
            if( c != null)
            {
                c.debito(v);
            }
        }
    }
    
    public double saldo()
    {
        double tot = 0.0;
        for(Conta c : this.contas)
        {
            if( c != null)
            {
                tot += c.getSaldo();
            }
        }
        
        return tot;
    }
}
