
/**
 * Write a description of class teste here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class teste
{
    public static void main()
    {
        
        Banco x = new Banco("BPPPPPP");
        x.nova("Jose",100.0,1);
        x.nova("Ana",15000.0,2);
        x.nova("Zezinho",150.0,3);
        x.nova("Paula",1200.0,4);
        
        x.debito(1,12.30);
        x.debito(2,101.0);
        x.debito(3,56.0);
        x.debito(4,11.9);
        
        x.credito(3,150.0);
        
        System.out.println("O banco "+x.getNome()+" tem "+x.num_contas()+" contas");
        System.out.println("saldo = "+x.saldo()); x.despesas(1.55);
        System.out.println("agora o saldo e = "+x.saldo());
    }
}
