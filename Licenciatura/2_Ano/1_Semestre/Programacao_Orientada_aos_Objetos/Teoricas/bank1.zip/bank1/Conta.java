
/**
 * Write a description of class Conta here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Conta
{
    private static final int TAM = 1000;
    private static int contas = 0;
    
    public static int getNC()
    { return Conta.contas;}
    
    // instance variables - replace the example below with your own
    private String titular;
    private double saldo;
    private int num;
    private double[] movs;
    private int idx;
    /**
     * Constructor for objects of class Conta
     */
    public Conta(String t, double i, int n)
    {
        // initialise instance variables
        this.titular = t;
        this.saldo = i;
        this.num = n;
        this.idx = 0;
        this.movs = new double[TAM];
        this.movs[this.idx++] = i;
        this.contas++;
    }
    public Conta()
    {
        this.titular = "";
        this.saldo = 0.0;
        this.idx = 0;
        this.movs = null;
        Conta.contas++;
    }
    
    public String getTitular()
    {
        return this.titular;
    }
    public double getSaldo()
    {
        return this.saldo;
    }
    public int getNum()
    {
        return this.num;
    }
    
    public boolean debito(double v)
    {
        if(this.saldo - v >= 0.0)
        {
            this.movs[idx++] = -1*v;
            this.saldo -= v;
            return true;
        }
        else
            return false;
    }
    public void credito(double v)
    {
        this.movs[idx++] = v;
        this.saldo += v;
    }
    
    public boolean equals(Conta c)
    {
        return c.getNum() == this.num;
    }
    
    public Conta clone()
    {
        Conta aux = new Conta(this.titular, this.movs[0], this.num);
        for(int i=1; i < this.idx; i++)
            if(this.movs[i] < 0)
                aux.debito(this.movs[i]);
            else
                aux.credito(this.movs[i]);
                
        return aux;
    }
    
    public String toString()
    {
        String x = this.titular+","+this.num+","+this.saldo+","+this.idx+",";
        for(double d: this.movs)
            x += d+",";
        return x;
    }
}
