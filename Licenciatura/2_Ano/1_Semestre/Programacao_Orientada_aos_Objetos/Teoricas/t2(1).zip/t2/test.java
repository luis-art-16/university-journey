
/**
 * Write a description of class test here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class test
{
    public static void main()
    {
        Ponto p1 = new Ponto(1,2);
        Ponto p2 = new Ponto(2,3);
        Circulo c1 = new Circulo(4,5,1);
        Circulo c2 = new Circulo(p1,3);
        Circulo c3 = new Circulo(p2,5);
        
        System.out.println("area do c3 = "+c3.area());
        System.out.println("area do c3 = "+c3.perimetro());
    }
}
