
/**
 * Write a description of class Circulo here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Circulo
{
    // instance variables - replace the example below with your own
    private Ponto centro;
    private double raio;

    /**
     * Constructor for objects of class Circulo
     */
    public Circulo()
    {
        // initialise instance variables
        this.raio = 0.0;
        this.centro = new Ponto(0.0,0.0);
    }
    public Circulo(double x, double y, double r)
    {
        // initialise instance variables
        this.raio = r;
        this.centro = new Ponto(x,y);
    }
    public Circulo(Ponto p, double r)
    {
        // initialise instance variables
        this.raio = r;
        this.centro = p.clone();
    }
    public Circulo(double x, int r)
    {
        // initialise instance variables
        this.raio = (double)r;
        this.centro = new Ponto(x,0.0);
    }
    public Circulo(double x, double y)
    {
        // initialise instance variables
        this.raio = 0.0;
        this.centro = new Ponto(x,y);
    }

    public double getRaio()
    {
        return this.raio;
    }
    public double getX()
    {
        return this.centro.getX();
    }
    public double getY()
    {
        return this.centro.getY();
    }
    
    public Ponto getCentro()
    {
        return this.centro.clone();
    }
    
    public void setX(double x)
    {
        this.centro.setX(x);
    }
    public void setY(double y)
    {
        this.centro.setY(y);
    }
    
    // três métodos esperados em cada classe escrita!
    public boolean equals(Circulo c)
    {
        if(c != null)
        {
            return c.getRaio() == this.raio && this.centro.equals(c.getCentro());
        }
        else
            return false;
    }
    public Circulo clone()
    {
        return new Circulo(this.centro, this.raio);
    }
    public String toString()
    {
        return this.centro.toString()+";"+this.raio;
    }
    
    public double area()
    {
        return Math.PI * Math.pow(this.raio,2.0);
    }
    public double perimetro()
    {
        return 2*Math.PI * this.raio;
    }
}
