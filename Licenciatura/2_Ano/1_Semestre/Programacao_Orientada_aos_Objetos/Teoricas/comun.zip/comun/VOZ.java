
/**
 * Write a description of class VOZ here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class VOZ extends Comunicacao
{
    // instance variables - replace the example below with your own
    private boolean happy;

    /**
     * Constructor for objects of class VOZ
     */
    public VOZ(int n, int d, double p, boolean h)
    {
        // initialise instance variables
        super(n,d,p);
        this.happy = h;
    }

    public double valor()
    {
        if(this.happy)
            return super.getDura() * 0.1;
        else
            return super.getDura() * super.getPreco() / 60; 
            
    }
    
    public VOZ clone()
    {
        return new VOZ(super.getNum(),super.getDura(),super.getPreco(),this.happy);
    }
}
