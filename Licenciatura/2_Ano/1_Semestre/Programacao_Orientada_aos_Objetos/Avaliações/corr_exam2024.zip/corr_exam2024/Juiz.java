import java.util.*;
public abstract class Juiz
{ 
    private int cod; // código do juiz
    private String resid; // residência do juiz
    private int anos; // anos de serviço
    private List<Processo> lista; // registo dos processos tratados

    public Juiz(int c, String r, int a)
    { 
        this.cod=c; this.resid = r; this.anos = a;
    this.lista = new ArrayList<Processo>();
    }

    public int getCod() 
    { return this.cod;}
    public String getRes() 
    { return this.resid;}
    public int getAnos() 
    { return this.anos;}
    
    public void add(Processo p) 
    { if(p != null) this.lista.add(p); }
    
    public int tamanho() 
    { return this.lista.size();}
    
    public List<Processo> processos()
    { 
        List<Processo> tmp = new ArrayList<Processo>();
        for(Processo p : this.lista)
            tmp.add(p);
        return tmp;
    }
    
    public abstract double rendimento(); // proveito do processo
    public abstract int duracao(Processo c); // duração em horas do processo
    public abstract Juiz clone();

}
