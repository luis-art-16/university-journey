
/**
 * Write a description of interface Processo here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.List;
public interface Processo
{
    public int getCod();
    public String getLocal() ; // localização do processo
    public List<Integer> elementos(); //lista dos códigos dos funcionários�
}
