
/**
 * Write a description of class Conselheiro here.
 *
 * @author (your name)
 * @version (a version number or a date)
 * 
 * 1.1)
 */
public class Conselheiro extends Juiz
{
    

    /**
     * Constructor for objects of class Conselheiro
     */
    public Conselheiro(int c, String r, int a)
    {
        // initialise instance variables
        super(c,r,a);
    }

    public double rendimento()
    {
        double valor = 0.0;
        for(Processo p : super.processos())
            if(p.elementos().size() > 10)
                valor += this.duracao(p) * 15.0;
            else
                valor += this.duracao(p) * 10.0;
        
        return valor;
    }
    public int duracao(Processo p)
    {
        return p.elementos().size() * 2;
    }
    
    public Conselheiro clone()
    {
        Conselheiro tmp = new Conselheiro(super.getCod(),super.getRes(),super.getAnos());
        for(Processo p : super.processos())
            tmp.add(p);
        
        return tmp;
    }
}
