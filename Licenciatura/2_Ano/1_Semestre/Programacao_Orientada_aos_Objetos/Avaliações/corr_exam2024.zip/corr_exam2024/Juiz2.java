
/**
 * Write a description of class Juiz2 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 * 
 * 1.2)
 */

// por exemplo!
public class Juiz2 extends Juiz
{
    /**
     * Constructor for objects of class Conselheiro
     */
    public Juiz2(int c, String r, int a)
    {
        // initialise instance variables
        super(c,r,a);
    }

    public double rendimento()
    {
        return 100.00;  // processo com valor fixo
    }
    public int duracao(Processo p)
    {
        return p.elementos().size();  // para ser diferente
    }
    
    public Juiz2 clone()
    {
        Juiz2 tmp = new Juiz2(super.getCod(),super.getRes(),super.getAnos());
        for(Processo p : super.processos())
            tmp.add(p);
        
        return tmp;
    }
}
