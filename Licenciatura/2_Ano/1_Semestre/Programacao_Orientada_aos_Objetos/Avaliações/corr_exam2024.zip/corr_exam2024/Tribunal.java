
/**
 * Write a description of class Tribunal here.
 *
 * @author (your name)
 * @version (a version number or a date)
 * 
 * 
 * 2.1
 */
import java.util.*;

public class Tribunal
{
    // instance variables - replace the example below with your own
    private Map<Integer,Juiz> lista;

    /**
     * Constructor for objects of class Tribunal
     */
    public Tribunal()
    {
        // initialise instance variables
        this.lista = new HashMap<Integer,Juiz>();
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public boolean add(Juiz j)
    {
        if(j != null)
        {
            if(this.lista.containsKey(j.getCod()))
                return false;
            else
            {
                this.lista.put(j.getCod(),j.clone());
                return true;
            }
        }
        else
            return false;
    }
    
    
    /*
     * 2.2.
     */
    public String maior_residencia()
    {
        String max="";
        double max2=-1.0;
        for(Juiz j : this.lista.values())
            if(j.rendimento() > max2)
            {
                max = j.getRes();
                max2 = j.rendimento();
            }
            
        return  max;
    }
    
    /*
     * 2.3
     */
    public Map<Integer,ArrayList<Integer>> funcionarioProcs()
    {
        HashMap<Integer,ArrayList<Integer>> tmp = new HashMap<Integer,ArrayList<Integer>>();
        
        for(Juiz j : this.lista.values())
        {
            for(Processo p : j.processos())
                for(Integer f : p.elementos())
                {
                    ArrayList<Integer> novo = null;
                    if(tmp.containsKey(f))
                        novo = tmp.get(f);
                    else
                    {
                        novo = new ArrayList<Integer>();
                        tmp.put(f,novo);
                    }
                    novo.add(p.getCod());
                }
        }
        
        return tmp;
    }
    
    /*
     * 2.4.
     */
    public int func_max()
    {
        HashMap<Integer,Integer> tmp = new HashMap<Integer,Integer>();
        
        for(Juiz j : this.lista.values())
        {
            for(Processo p : j.processos())
            {
                int dura = j.duracao(p);
                for(Integer f : p.elementos())
                {
                    int tot = 0;
                    if(tmp.containsKey(f))
                        tmp.put(f, tmp.get(f) + dura);
                    else
                    {
                        tmp.put(f, dura);
                    }
                }
            }
        }
        
        // procurar maior valor de duraçao
        int max = 0;
        int imax = -1;
        for(int f : tmp.keySet())
            if(tmp.get(f) > max)
            {  max = tmp.get(f); imax = f; }
            
        return imax;
    }
    
    
    /*
     * 2.5.
     */
    public Set<Processo> ordemProcs(int cod)
    {
        TreeSet<Processo> conj = null;
        Juiz j = this.lista.get(cod);
        if( j != null)
        {
            Comparator<Processo> ord = (p1,p2) -> 
            {
                // caso de empate, desempate por local lexicograficamente
                if(j.duracao(p1) == j.duracao(p2))
                {
                    return p1.elementos().size() - p2.elementos().size();
                }
                if(j.duracao(p1) < j.duracao(p2))
                    return -1;
                else
                    return 1;
            };
            conj = new TreeSet<Processo>(ord);
            
            for(Processo p : j.processos())
                conj.add(p);
        }
        
        return conj;
    }
    
    /*
     * 2.6.
     * 
     * Mencionar pelo menos o seguinte:
     * 1) get() implica execução de uma inserção numa tabela de hash.
     * 2) em Java a classe HashMap implementa hashing via closed addressing i.e., chaining.
     * 3) Explicar hashing e o uso da função de hash durante o get().
     * 4) Explicar chaining na resolução das colisões com exemplos.
     * 5) Usar exemplos.
     * 6) Justificar porque esta estrutura de dados é uma boa ideia.
     * 
     */
}
