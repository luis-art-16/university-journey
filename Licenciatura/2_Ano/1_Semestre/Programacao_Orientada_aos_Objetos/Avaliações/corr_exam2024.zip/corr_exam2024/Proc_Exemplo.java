
/**
 * Write a description of class Proc_Exemplo here.
 *
 * @author (your name)
 * @version (a version number or a date)
 * 
 * 1.2)
 * Exemplo de um processo i.e., uma classe que implementa Processo.
 */
import java.util.List;
import java.util.ArrayList;
public class Proc_Exemplo implements Processo
{
    
    private int cod, dias;
    private String local;
    private List<Integer> funcionarios;

    /**
     * Constructor for objects of class Proc_Exemplo
     */
    public Proc_Exemplo(int cod, String l, int d)
    {
        // initialise instance variables
        this.cod = cod;
        this.local = l;
        this.dias = d;
        this.funcionarios = new ArrayList<Integer>();
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public int getCod()
    { return this.cod; }
    
    public String getLocal()
    { return this.local; }
    
    public List<Integer> elementos()
    {
        ArrayList<Integer> tmp = new ArrayList<Integer>();
        for(int x : this.funcionarios)
            tmp.add(x);
            
        return tmp;
    }
}
