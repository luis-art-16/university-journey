
/**
 * Write a description of class ObraException here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class ObraException extends Exception
{
    

    /**
     * Constructor for objects of class ObraException
     */
    public ObraException(String s)
    {
        // initialise instance variables
        super(s);
    }

    
}
