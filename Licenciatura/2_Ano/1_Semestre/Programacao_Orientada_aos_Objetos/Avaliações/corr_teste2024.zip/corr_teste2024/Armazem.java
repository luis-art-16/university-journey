
/**
 * Write a description of class Armazem here.
 *
 * @author (your name)
 * @version (a version number or a date)
 * 
 * 1.2
 */
public class Armazem extends Obra
{
    /**
     * Constructor for objects of class Vivenda
     */
    public Armazem(int c, double p, String l)
    {
        // initialise instance variables
        super(c,p,l);
    }

    
    public double custo()
    {
        return ((double)super.horasObra() / 24.0 / 7.0) * super.getPreco();
    }
    
    public Armazem clone()
    {
        Armazem v = new Armazem(super.getCod(),super.getPreco(),super.getLocal());
        for(int c : super.emps())
            v.addEmp(c,super.getEmp(c));
        return v;
    }
}
