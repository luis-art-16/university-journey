
/**
 * Write a description of class Empresa here.
 *
 * @author (your name)
 * @version (a version number or a date)
 * 
 * 2.1 classe empresa 
 */
import java.util.*;
public class Empresa
{
    // instance variables - replace the example below with your own
    private HashMap<Integer,Obra> obras;

    /**
     * Constructor for objects of class Empresa
     */
    public Empresa()
    {
        // initialise instance variables
        this.obras = new HashMap<Integer,Obra>();
    }

    public void add(Obra o) throws ObraException
    {
        if(o != null)
        {
            if(this.obras.containsKey(o.getCod()))
                throw new ObraException("Obra ja existe");
            else
                this.obras.put(o.getCod(),o.clone());
        }
    }
    
    /**
     * 2.2.
     */
    public String maior_equipa()
    {
        String max = "";
        double maxvalor = 0;
        for(Obra o : this.obras.values())
        {
            if(o.num_emps() > maxvalor)
            {
                maxvalor = o.num_emps();
                max = o.getLocal();
            }
        }
        return max;
    }
    
    /**
     * 2.3
     */
    public Set<Obra> ordemNasObras()
    {
        // define comparador 
        Comparator<Obra> ordem = (x1,x2) -> 
        {
            // caso de empate, desempate por local lexicograficamente
            if(x1.custo() == x2.custo())
            {
                return x1.getLocal().compareTo(x2.getLocal());
            }
            if(x1.custo() < x2.custo())
                return -1;
            else
                return 1;
        };
        Set<Obra> tmp = new TreeSet<Obra>(ordem);
        
        for(Obra o : this.obras.values())
            tmp.add(o.clone());
            
        return tmp;
    }
    
    /**
     * 2.4
     */
    public String mais_distintos()
    {
        HashMap<String,TreeSet<Integer>> tmp = new HashMap<String,TreeSet<Integer>>();
        
        for(Obra o : this.obras.values())
        {
            TreeSet<Integer> xxx;
            if(tmp.containsKey(o.getLocal()))
            {
                xxx = tmp.get(o.getLocal());
            }
            else
            {
                xxx = new TreeSet<Integer>();
                tmp.put(o.getLocal(),xxx);
            }
            for(Integer e : o.emps())
            {
                xxx.add(e); // adiciona a um set => logo fica com elementos distintos!
            }
        }
        
        // identifica local com mais emps distintos
        String max = "";
        int maxvalor = 0;
        for(String l : tmp.keySet())
        {
            if(tmp.get(l).size() > maxvalor)
            {
                maxvalor = tmp.get(l).size();
                max = l;
            }
        }
        
        return max;
    }
    
    /**
     * 2.5
     */
    public Map<String,Map<Integer,List<Integer>>> mapeia()
    {
        HashMap<String,Map<Integer,List<Integer>>> tmp = new HashMap<String,Map<Integer,List<Integer>>>();
        
        for(Obra o : this.obras.values())
        {
            Map<Integer,List<Integer>> tmp2;
            if(tmp.containsKey(o.getLocal()))
            {
                tmp2 = tmp.get(o.getLocal());
            }
            else
            {
                tmp2 = new HashMap<Integer,List<Integer>>();
                tmp.put(o.getLocal(), tmp2);
            }
            
            // processa horas dos empregados da obra
            for(int e : o.emps())
            {
                int horas = o.getEmp(e);
                if(tmp2.containsKey(horas))
                {
                    tmp2.get(horas).add(e);
                }
                else
                {
                    ArrayList<Integer> xxx = new ArrayList<Integer>();
                    xxx.add(e);
                    tmp2.put(horas,xxx);
                }
            }
        }
        
        return tmp;
    }
    
    /**
     * 2.6
     */
    
    public Set<Integer> emp_todas_obras()
    {
        TreeSet<Integer> todos = new TreeSet<Integer>(); // coleciona todos os empregados
        for(Obra o : this.obras.values())
        {
            for(Integer e : o.emps())
                todos.add(e);
        }
        
        Iterator<Integer> i = todos.iterator();
        while(i.hasNext())
        {
            int novo = i.next();
            for(Obra o : this.obras.values())
            {
                if(!o.emps().contains(novo))  // emp não existe na obra?
                    i.remove();
            }
        }
        
        return todos;
    }
    
    
}
