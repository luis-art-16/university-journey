
/**
 * Abstract class Obra - write a description of the class here
 *
 * @author (your name here)
 * @version (version number or date here)
 * 
 * 1.1
 */
import java.util.*;
public abstract class Obra
{
    private int cod;// código
    private double preco; // preço por hora.
    private String local; // localização da obra
    private Map<Integer, Integer> horas; // emp → horas, registo de horas
    
    public Obra(int c, double p, String l)
    {
        this.cod = c;
        this.preco = p;
        this.local = l;
        this.horas = new HashMap<Integer,Integer>();
    }
    
    // gets
    public int getCod()
    { return this.cod;}
    public double getPreco()
    { return this.preco;}
    public String getLocal()
    { return this.local;}
    
    // adicionar horas a um empregado
    public void addEmp(int e, int h)
    {
        if(this.horas.containsKey(e))
            this.horas.put(e, this.horas.get(e) + h);
        else
            this.horas.put(e, h);
    }
    //consultar horas 
    public int getEmp(int e)
    {
        if(this.horas.containsKey(e))
            return this.horas.get(e);
        else
            return 0;
    }
    // obter conj dos codigos de emps
    public Set<Integer> emps()
    {
        Set<Integer> temp = new TreeSet<Integer>();
        for(Integer c : this.horas.keySet())
            temp.add(c);
        return temp;
    }
    // #empregados na Obra
    public int num_emps()
    {
        return this.horas.size();
    }
    
    // outro metodo que vai dar jeito para calcular os custos
    // horas da obra
    public int horasObra()
    {
        int tot = 0;
        for(int h : this.horas.values())
            tot += h;
        return tot;
    }
    
    // por exemplo...
    public boolean equals(Object o)
    {
        if ( this == o ) return true; // é o próprio !!
        if ( o == null ) return false;
        if ( this.getClass() != o.getClass() ) return false;
        
        // Aqui temos a certeza que é uma Obra
        Obra pp = (Obra) o; // casting obrigatório
        return this.getCod() == pp.getCod(); 
    }
    
    public abstract double custo(); // custo da obra
    public abstract Obra clone();
}
