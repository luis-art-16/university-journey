
/**
 * Write a description of class Vivenda here.
 *
 * @author (your name)
 * @version (a version number or a date)
 * 
 * 1.2
 */
public class Vivenda extends Obra
{
    
    /**
     * Constructor for objects of class Vivenda
     */
    public Vivenda(int c, double p, String l)
    {
        // initialise instance variables
        super(c,p,l);
    }

    public double custo()
    {
        return super.getPreco() * super.horasObra();
    }
    
    public Vivenda clone()
    {
        Vivenda v = new Vivenda(super.getCod(),super.getPreco(),super.getLocal());
        for(int c : super.emps())
            v.addEmp(c,super.getEmp(c));
        return v;
    }
}
