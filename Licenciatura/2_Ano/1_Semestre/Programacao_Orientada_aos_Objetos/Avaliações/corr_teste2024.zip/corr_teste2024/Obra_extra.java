
/**
 * Write a description of class Obra_extra here.
 *
 * @author (your name)
 * @version (a version number or a date)
 * 
 * 1.3
 * Um exemplo... podia ser outra coisa qualquer que fosse subclasse de Obra
 * mas com as implementações dos métodos abstractos.
 */
public class Obra_extra extends Obra
{
    // instance variables - replace the example below with your own
    

    /**
     * Constructor for objects of class Obra_extra
     */
    public Obra_extra(int c, double p, String l)
    {
        // initialise instance variables
        super(c,p,l);
    }

    // preço conta só como metada! (por exemplo).
    public double custo()
    {
        return (super.getPreco()/2.0) * super.horasObra();
    }
    
    public Obra_extra clone()
    {
        Obra_extra v = new Obra_extra(super.getCod(),super.getPreco(),super.getLocal());
        for(int c : super.emps())
            v.addEmp(c,super.getEmp(c));
        return v;
    }
}
