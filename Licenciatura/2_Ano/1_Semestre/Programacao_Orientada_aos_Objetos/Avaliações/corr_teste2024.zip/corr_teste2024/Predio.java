
/**
 * Write a description of class Predio here.
 *
 * @author (your name)
 * @version (a version number or a date)
 * 
 * 1.2.
 */
public class Predio extends Obra
{
    private int area;
    /**
     * Constructor for objects of class Vivenda
     */
    public Predio(int c, double p, String l, int a)
    {
        // initialise instance variables
        super(c,p,l);
        this.area = a;
    }

    public int getArea()
    { return this.area;}
    
    public double custo()
    {
        double tot = 0.0;
        for(int e : super.emps())
        {
            if(e % 2 == 0) // codigo par
                tot += super.getPreco() * 2 * super.getEmp(e);
            else   // codigo impar
                tot += super.getPreco() * super.getEmp(e);
        }
        return tot;
    }
    
    public Predio clone()
    {
        Predio v = new Predio(super.getCod(),super.getPreco(),super.getLocal(),this.area);
        for(int c : super.emps())
            v.addEmp(c,super.getEmp(c));
        return v;
    }
}
