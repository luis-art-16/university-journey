
/**
 * Abstract class Conteudo - write a description of the class here
 *
 * @author (your name here)
 * @version (version number or date here)
 */
import java.util.*;
public abstract class Conteudo
{

    private String nome; // nome do conteúdo
    private ArrayList<Episodio> eps; // lista de episódios
    
    public Conteudo(String n)
    { this.nome = n; this.eps = new ArrayList<Episodio>(); }
    
    public String getNome()
    { return this.nome; }
    public void add(Episodio e)
    { this.eps.add(e); } // imutável
    public int tamanho()
    { return this.eps.size(); }
    
    public List<Episodio> listaEps()
    { 
        ArrayList<Episodio> temp = new ArrayList<Episodio>();
        for(Episodio e : this.eps)
            temp.add(e);
        return temp;
    }

//1.1
public double duracao()
{
    double total = 0.0;
    for(Episodio e : this.eps)
        total += e.duracao();
    
    return total;
}
public boolean equals(Object o)
{

    if ( this == o ) return true; // é o próprio !!
    if ( o == null ) return false;
    if ( this.getClass() != o.getClass() ) return false;
    // Aqui temos a certeza que é um Conteudo
    Conteudo cc = (Conteudo) o; // casting obrigatório
	
    return this.nome.equals(cc.getNome());
}


public abstract double valor(); //valor atribuído ao conteúdo
public abstract Conteudo clone();
}
