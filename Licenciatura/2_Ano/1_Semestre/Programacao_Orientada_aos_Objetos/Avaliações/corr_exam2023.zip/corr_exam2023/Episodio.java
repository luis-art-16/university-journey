public interface Episodio
{ 
    public int getNum(); // ID do episodio
    public double duracao(); // duração do episodio
    public int classificacao(); // valor entre 1-10
}
