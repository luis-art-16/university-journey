
/**
 * Write a description of class Documentario here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Documentario extends Conteudo
{
    // instance variables - replace the example below with your own


    /**
     * Constructor for objects of class Documentario
     */
    public Documentario(String n)
    {
        // initialise instance variables
        super(n);
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public double valor()
    {
        // verifica cada episodio
        double total = 0.0;
        for(Episodio e : super.listaEps())
        {
            switch(e.classificacao())
            {
                case '1': total += 3.0; break;
                case '2': total += 1.2; break;
                default : total += 1.0; break;
            }
        }
        
        return total;
    }
    
    public Documentario clone()
    {
        Documentario d = new Documentario(super.getNome());
        for(Episodio e : super.listaEps())
            d.add(e);
        return d;
    }
}
