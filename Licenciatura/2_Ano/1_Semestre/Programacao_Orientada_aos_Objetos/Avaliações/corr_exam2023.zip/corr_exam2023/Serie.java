
/**
 * Write a description of class Serie here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Serie extends Conteudo
{
    // instance variables - replace the example below with your own
    private double custo;

    /**
     * Constructor for objects of class Serie
     */
    public Serie(String n, double c)
    {
        // initialise instance variables
        super(n);
        this.custo = c;
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public double valor()
    {
        return super.tamanho() * this.custo;
    }
    
    public Serie clone()
    {
        Serie s = new Serie(super.getNome(),this.custo);
        for(Episodio e : super.listaEps())
            s.add(e);
        return s;
    }
}
