
/**
 * Write a description of class EXE here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class EXE implements Episodio
{
    // instance variables - replace the example below with your own
    private int num;
    private double dur;
    private int cla;

    /**
     * Constructor for objects of class EXE
     */
    public EXE(int n, double d, int c)
    {
        // initialise instance variables
        this.num = n; this.dur = d; this.cla = c;
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public int getNum()
    { return this.num; }
    
    public double duracao()
    {
        return this.dur;
    }
    public int classificacao()
    {
        return this.cla;
    }
}
