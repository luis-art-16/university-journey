
/**
 * Write a description of class NetFlops here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;
public class NetFlops
{
    // instance variables - replace the example below with your own
    private HashMap<String,Conteudo> lista;

    /**
     * 2.1)
     * Constructor for objects of class NetFlops
     */
    public NetFlops()
    {
        // initialise instance variables
        this.lista = new HashMap<String, Conteudo>();
    }
    
    public void add(Conteudo c)
    {
        if(c != null)
            this.lista.put(c.getNome(),c.clone());
    }
    
    // 2.2
    public String menor_valor()
    {
        String s="";
        double v = Double.MAX_VALUE;
        for(Conteudo c : this.lista.values())
            if(c.valor() < v)
            { s = c.getNome();  v = c.valor(); }
            
        return s;
    }

    
    // 2.3
    public String maxEps()
    {
        String s ="";
        int max = 0;
        for(Conteudo c : this.lista.values())
        {
            int cc = 0;
            for(Episodio e : c.listaEps())
                if(e.classificacao() == 1) cc++;
            
            if(cc > max)
            { max = cc; s = c.getNome(); }
        }
        
        return s;
    }
    
    // 2.4
    public Map<Integer,ArrayList<String>> class_cont()
    {
        HashMap<Integer,ArrayList<String>> temp = new HashMap<Integer,ArrayList<String>>();
        for(Conteudo c : this.lista.values())
            for(Episodio e : c.listaEps())
            {
                if(temp.containsKey(e.classificacao()))
                    temp.get(e.classificacao()).add(c.getNome());
                else
                {
                    ArrayList<String> aux = new ArrayList<String>();
                    aux.add(c.getNome());
                    temp.put(e.classificacao(), aux);
                }
            }
        return temp;
    }
    
    // 2.5
    public String intervalos()
    {
        // calcula maior e menor duracao em todos os episodios
        double max=0.0, min=0.0;
        for(Conteudo c : this.lista.values())
            for(Episodio e : c.listaEps())
            {
                if(e.duracao() > max)
                    max = e.duracao();
                if(e.duracao() < min)
                    min = e.duracao();   
            }
        
        // faz tabela de intervalos usando o extremo superior de cada intervalo
        double amp = max - min;
        double inc = amp / 10.0; // dez intervalos...
        TreeMap<Double,Double> temp = new TreeMap<Double,Double>();
        for(double x = min; x < max-inc; x=x+inc)
            temp.put(x,0.0);
        // ultimo (10th intervalo) é o valor max
        temp.put(max,0.0);
        
        // percorre episodios (pela ordem do treemap) e adiciona valor dos conteudos
        // assumimos que um conteudo pode contar duas vezes 
        // por conter dois episodios diferentes com durações no mesmo intervalo!.
        for(Conteudo c : this.lista.values())
            for(Episodio e : c.listaEps())
            {
                // procura intervalo onde colocar valor do conteudo (pela ordem do treemap)
                Iterator<Double> i = temp.keySet().iterator();
                double dd = 0.0;
                do
                {
                    dd = i.next();
                } while(i.hasNext() && e.duracao() > dd);
                
                temp.put(dd,temp.get(dd) + c.valor()); // coloca valor
                
            }
            
        // calcula maximo (com maior valor acumulado) e retorna representacao do intervalo
        max = 0.0;
        double sup = 0;
        for(Double d : temp.keySet())
            if(temp.get(d) > max)
            { max = temp.get(d); sup =d; }
            
        return ""+(sup-inc)+" - "+sup;  // formação do intervalo com o resultado.
    }
    
}
