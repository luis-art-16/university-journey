import java.util.*;
public class Contacto {
    private String numero; private String nome;

    public Contacto(String nome, String numero) {
        this.nome = nome;
        this.numero = numero;
    }
    //Get's
    public String getNome() {
        return nome;
    }
    public String getNumero() {
        return numero;
    }
}

