import java.util.*;
import java.io.Serializable;
public class ChamadaNormal extends Comunicacao implements Serializable {
    private int duracaodechamada;

    public ChamadaNormal(Dispositivo origem,Dispositivo destino,int duracaodechamada) {
     super(origem,destino,TipoComunicacao.CHAMADA_NORMAL);
     this.duracaodechamada = duracaodechamada;
    }
    //Get's
    public int getDuracaoChamada() {
        return duracaodechamada;
    }
    
    public double calcularCusto() {
        return 0.2 * duracaodechamada;
    }
    //Método Clone
    public ChamadaNormal clone()
    {
        ChamadaNormal ChamadaNormal = new ChamadaNormal(super.getOrigem(), super.getDestino(), this.duracaodechamada);
        return ChamadaNormal;
    }
    @Override
    public String toString() {
    return "Chamada Normal - Duração: " + this.duracaodechamada; // Adicione os outros detalhes se necessário
    }
}
