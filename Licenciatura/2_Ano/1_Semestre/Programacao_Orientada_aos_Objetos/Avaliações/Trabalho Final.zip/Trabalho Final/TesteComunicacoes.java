public class TesteComunicacoes {
    public static void main(String[] args) {
        testarCriacaoComunicacoes();
    }

    public static void testarCriacaoComunicacoes() {
        Comunicacao sms = new SMS(3, 4, 50, "Olá, como vai?");
        Comunicacao mensagemImagem = new MensagemImagem(1, 2, 1024, "JPEG", 800600);

        // Adicione impressões ou assertivas aqui para verificar se as instâncias foram criadas corretamente.
        System.out.println(sms);
        System.out.println(mensagemImagem);
    }
}
