import java.util.*;
import java.io.Serializable;
public abstract class Comunicacao implements Serializable {
    private Dispositivo origem;
    private Dispositivo destino;
    private TipoComunicacao tipo;

    public Comunicacao(Dispositivo origem, Dispositivo destino,TipoComunicacao tipo) {
        this.origem = origem;
        this.destino = destino;
        this.tipo = tipo;
    }
    //Get's e Set's
    public Dispositivo getOrigem() {
        return origem;
    }
    public Dispositivo getDestino() {
        return destino;
    }
    public TipoComunicacao getTipo() {
    return tipo;
    }
    public void setTipo(TipoComunicacao tipo) {
        this.tipo = tipo;
    }
    
    public abstract double calcularCusto();
}