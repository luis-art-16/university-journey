import java.util.*;
import java.io.Serializable;
public class Oldie extends Dispositivo implements Serializable{
    // Capacidades de receber e fazer chamadas de Voz
    // Chamadas normais
    public Oldie(String numero,String modoRede,String tipo) {
        super(numero,modoRede,tipo);
    }
    //Métodos
    public boolean PermitidoRealizarComunicacao(Comunicacao comunicacao) {
        if (comunicacao instanceof ChamadaNormal) {
            return true;
        } 
        return false;
    }
   
    public Oldie clone()
    {
        Oldie oldie = new Oldie(super.getNumero(), super.getModoRede(),super.getTipo());
        for(Comunicacao com : super.getComunicacoes())
        {
            oldie.adicionarComunicacao(com);
        }
        return oldie;
    }
    
}
