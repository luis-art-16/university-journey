import java.util.*;
import java.io.Serializable;
//Conta de cada cliente
public class Conta implements Serializable{
    private String codigo; private List<Dispositivo> dispositivos;
    private Map<TipoComunicacao, Double> tabelaPrecos;

    public Conta(String codigo) {
        this.codigo = codigo;
        this.dispositivos = new ArrayList<>();
        inicializarTabelaPrecos();
    }
    //Get's
     public String getCodigo() {
    return codigo;
    }
    
    public Map<TipoComunicacao, Double> getTabelaPrecos() {
        if (tabelaPrecos == null) {
            inicializarTabelaPrecos();
        }
        return tabelaPrecos;
    }
    //Métodos
     private void inicializarTabelaPrecos() {
        tabelaPrecos = new HashMap<>();
        tabelaPrecos.put(TipoComunicacao.SMS, 0.1);
        tabelaPrecos.put(TipoComunicacao.MENSAGEM_IMAGEM, 0.5);
        tabelaPrecos.put(TipoComunicacao.MENSAGEM_VIDEO, 1.0);
        tabelaPrecos.put(TipoComunicacao.CHAMADA_NORMAL, 0.2);
        tabelaPrecos.put(TipoComunicacao.CHAMADA_VIDEO, 0.5);
        tabelaPrecos.put(TipoComunicacao.DOWNLOAD, 2.0);
        System.out.println("Tabela de preços inicializada: " + tabelaPrecos);
    }
     
    public List<Dispositivo> getDispositivos() {
        return dispositivos;
    }
    
    public void adicionarDispositivos(Dispositivo dispositivo) {
            dispositivos.add(dispositivo);
    }
    
     public void listarDispositivosMode5G() {
        System.out.println("Dispositivos da Conta " + getCodigo() + ":");
        for (Dispositivo dispositivo : dispositivos) {
            if (dispositivo.Modo5G()) {
                System.out.println("Número do Dispositivo: " + dispositivo.getNumero());
            }
        }
    }
    
    public List<Comunicacao> getComunicacoes() {
        List<Comunicacao> comunicacoes = new ArrayList<>();
        for (Dispositivo dispositivo : dispositivos) {
            comunicacoes.addAll(dispositivo.getComunicacoes());
        }
        return comunicacoes;
    }
}
