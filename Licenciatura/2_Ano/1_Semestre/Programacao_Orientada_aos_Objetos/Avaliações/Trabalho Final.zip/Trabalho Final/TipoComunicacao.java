public enum TipoComunicacao {
    SMS,
    MENSAGEM_IMAGEM,
    MENSAGEM_VIDEO,
    CHAMADA_NORMAL,
    CHAMADA_VIDEO,
    DOWNLOAD
}