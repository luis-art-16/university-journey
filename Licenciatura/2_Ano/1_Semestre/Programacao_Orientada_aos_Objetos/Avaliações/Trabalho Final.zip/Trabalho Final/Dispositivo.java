import java.util.*;
import java.io.Serializable;
public abstract class Dispositivo implements Serializable {
    private String numero;
    private String modoRede;
    private String tipo;
    private ArrayList<Comunicacao> comunicacoes;
    
    private static final int NUMERO_SERVIDOR_DOWNLOADS = 169;

    public Dispositivo(String numero, String modoRede, String tipo) {
        this.numero = numero;
        this.modoRede = modoRede;
        this.tipo = tipo;
        this.comunicacoes= new ArrayList<>();
    }
    //Get's
    public String getNumero() {
        return numero;
    }
    public String getModoRede() {
        return modoRede;
    }
    public String getTipo() {
        return tipo;
    }
    public ArrayList<Comunicacao> getComunicacoes() {
        return comunicacoes;
    }
     //Métodos
    public void adicionarComunicacao(Comunicacao comunicacao) {
        this.comunicacoes.add(comunicacao);
    }
    
    public static Dispositivo NovoDispositivo(String tipo, String numero, String modo) {
        switch (tipo.toLowerCase()) {
            case "tablet":
                return new Tablet(numero, modo, tipo, 64);
            case "oldie":
                return new Oldie(numero, modo, tipo);
            case "telemovel":
                return new Telemovel(numero, modo, tipo);
            default:
                throw new IllegalArgumentException("Tipo de dispositivo desconhecido: " + tipo);
        }
    }
    
     public ArrayList<Comunicacao> listaComunicacoesRecebidas(String numDispositivo) {
        ArrayList<Comunicacao> temp = new ArrayList<>();

        for(Comunicacao com : this.comunicacoes) {
            if(com.getDestino().equals(numDispositivo)) {
                temp.add(com);
            }
        }

        return temp;
    }    
    public void VerComunicacoesRecebidas(String numDispositivo) {
        ArrayList<Comunicacao> temp = listaComunicacoesRecebidas(numDispositivo);
        if (temp.isEmpty()) {
            System.out.println("Nenhuma comunicação enviada pelo dispositivo.");
        } else {
            System.out.println("Comunicações Recebidas pelo Dispositivo:");
            for (Comunicacao com : temp) {
                System.out.println("Tipo de Comunicação: " + com.getClass().getSimpleName());
                System.out.println("Origem: " + com.getOrigem());
                System.out.println("Destino: " + com.getDestino());
                
            }
        }
    }

    public void fazerComunicacao(Dispositivo destino, Comunicacao comunicacao) {
        if (PermitidoRealizarComunicacao(comunicacao)) {
            this.adicionarComunicacao(comunicacao);
            destino.adicionarComunicacao(comunicacao);
            System.out.println("Comunicação realizada com sucesso!");
        } else {
            System.out.println("Este dispositivo não suporta este tipo de comunicação.");
        }
    }

    protected abstract boolean PermitidoRealizarComunicacao(Comunicacao comunicacao);
    
    public abstract Dispositivo clone();

    public ArrayList<Comunicacao> listaComunicacoesEnviadas(String numDispositivo) {
        ArrayList<Comunicacao> temp = new ArrayList<>();
    
        for(Comunicacao com : this.comunicacoes) {
            if(com.getOrigem().equals(numDispositivo)) {
                temp.add(com);
            }
        }
        return temp;
    }

    public void VerComunicacoesEnviadas(String numDispositivo) {
        ArrayList<Comunicacao> temp = listaComunicacoesEnviadas(numDispositivo);
        if (temp.isEmpty()) {
            System.out.println("Nenhuma comunicação enviada pelo dispositivo.");
        } else {
            System.out.println("Comunicações Enviadas pelo Dispositivo:");
            for (Comunicacao com : temp) {
                System.out.println("Tipo de Comunicação: " + com.getClass().getSimpleName());
                System.out.println("Origem: " + com.getOrigem());
                System.out.println("Destino: " + com.getDestino());
                }
        }
    }
    
    public boolean Modo5G() {
        return "5G".equals(modoRede);
    }

    public boolean permiteDownload() {
        return Modo5G() && numero.equals(String.valueOf(NUMERO_SERVIDOR_DOWNLOADS));
    }

    public boolean permiteChamadaVideo(Dispositivo outroDispositivo) {
        return Modo5G() && outroDispositivo.Modo5G();
    }
    
    //lógicas e métodos para o case11
    public ArrayList<Comunicacao> listarComunicacoesEnviadas(Dispositivo outroDispositivo) {
        ArrayList<Comunicacao> comunicacoesEnviadas = new ArrayList<>();

        for (Comunicacao comunicacao : comunicacoes) {
            if (comunicacao.getOrigem() == this && comunicacao.getDestino() == outroDispositivo) {
                comunicacoesEnviadas.add(comunicacao);
            }
        }

        return comunicacoesEnviadas;
    }

    public ArrayList<Comunicacao> listarComunicacoesRecebidas(Dispositivo outroDispositivo) {
        ArrayList<Comunicacao> comunicacoesRecebidas = new ArrayList<>();

        for (Comunicacao comunicacao : comunicacoes) {
            if (comunicacao.getOrigem() == outroDispositivo && comunicacao.getDestino() == this) {
                comunicacoesRecebidas.add(comunicacao);
            }
        }

        return comunicacoesRecebidas;
    }
    
}   

