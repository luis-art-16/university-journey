import java.util.*;
import java.io.Serializable;
public class Tablet extends Dispositivo implements Serializable{
    private int capacidadeMemoria;
    private ArrayList<String> contactos;

    public Tablet(String numero,String modoRede,String tipo,int capacidadeMemoria) {
        super(numero, modoRede,tipo);
        this.capacidadeMemoria = capacidadeMemoria;
        this.contactos = new ArrayList<>();
    }
    //Get's
    public int getCapacidade() {
        return this.capacidadeMemoria;
    }
    //Métodos
    public void adicionarContacto(String contacto) {
        this.contactos.add(contacto);
    }

    public void removerContacto(String contacto) {
        this.contactos.remove(contacto);
    }

    public ArrayList<String> getContactos() {
        return this.contactos;
    }
    
     public boolean PermitidoRealizarComunicacao(Comunicacao comunicacao) {
        return true;
    }
    
    public Tablet clone() {
        Tablet tablet = new Tablet(super.getNumero(), super.getModoRede(), super.getTipo(), this.getCapacidade());
        for (String s : this.contactos) {
            tablet.adicionarContacto(s);
        }
        for (Comunicacao com : super.getComunicacoes()) {
            tablet.adicionarComunicacao(com);
        }
        return tablet;
    }
}
