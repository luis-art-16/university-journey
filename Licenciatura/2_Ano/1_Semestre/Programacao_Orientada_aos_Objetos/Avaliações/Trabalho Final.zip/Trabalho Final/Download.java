import java.util.*;
import java.io.Serializable;
public class Download extends Comunicacao implements Serializable{
    private int tamanhoBytes; 
    private int duracaoDownld;
    private double velocidadeTransmissaoPorByte;
    
    public Download(Dispositivo origem, Dispositivo destino,int tamanhoBytes,int duracaoDownld,  double velocidadeTransmissaoPorByte) {
     super(origem,destino,TipoComunicacao.DOWNLOAD);
       // Verificar se origem e destino são dispositivos e estão em modo 5G
        
            Dispositivo origemDispositivo = (Dispositivo) getOrigem();
            Dispositivo destinoDispositivo = (Dispositivo) getDestino();

    if (!origemDispositivo.Modo5G() || !destinoDispositivo.Modo5G()) {
     throw new IllegalArgumentException("Download permitido apenas entre dispositivos em modo 5G.");
            }       
     this.tamanhoBytes = tamanhoBytes;
     this.duracaoDownld = duracaoDownld;
     this.velocidadeTransmissaoPorByte = velocidadeTransmissaoPorByte;
    
    }
    //Get's
    public int getTamanhoEmBytes() {
        return tamanhoBytes;
    }
    public int getDuracaoDownload() {
            return duracaoDownld;
     }
    public double getVelocidadeTransmissaoPorByte() {
        return velocidadeTransmissaoPorByte;
    }
    public void setVelocidadeTransmissaoPorByte(double velocidadeTransmissaoPorByte) {
        this.velocidadeTransmissaoPorByte = velocidadeTransmissaoPorByte;
    }
    //Métodos
    public double calcularCusto() {
        return 0.1 * tamanhoBytes + 0.2 * duracaoDownld;
    }
    //Método Clone
     public Download clone()
    {
        Download download = new Download(super.getOrigem(), super.getDestino(), this.tamanhoBytes, this.duracaoDownld, this.velocidadeTransmissaoPorByte);
        return download;
    }
    
     @Override
    public String toString() {
        return String.format("Download [Origem: %s, Destino: %s, Tamanho: %d, Duração: %d, Velocidade/Byte: %.2f]",
                getOrigem().getNumero(), getDestino().getNumero(), tamanhoBytes, duracaoDownld, velocidadeTransmissaoPorByte);
    }
}
