import java.util.*;
import java.io.Serializable;
public class ChamadaVideo extends Comunicacao implements Serializable {
    private double duracao; private int resolucao;
    
    public ChamadaVideo(Dispositivo origem,Dispositivo destino,double duracao,int resolucao) {
     super(origem,destino,TipoComunicacao.CHAMADA_VIDEO);
     this.duracao = duracao;
     this.resolucao = resolucao;
    }
    //Get's
    public double getDuracao()
    {
        return this.duracao;
    }
    public int getReolucao()
    {
        return this.resolucao;
    }
    public double calcularCusto() {
        return 0.3 * duracao;  
    }
    //Método Clone
    public ChamadaVideo clone()
    {
        ChamadaVideo ChamadaVideo = new ChamadaVideo(super.getOrigem(), super.getDestino(), this.duracao, this.resolucao);
        return ChamadaVideo;
    }
    
    @Override
    public String toString() {
    return "ChamadaVideo {" +
           "Origem: " + super.getOrigem().getNumero() +
           ", Destino: " + super.getDestino().getNumero() +
           ", Duração da Chamada de Vídeo: " + duracao +
           ", Resolução da Chamada de Vídeo: " + resolucao +
           '}';
    }
}