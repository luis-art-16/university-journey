import java.util.*;
public class Menu
{
    public static void main(String a[])
    {
      Scanner scanner = new Scanner(System.in);
      TouChim touChim = new TouChim();
      int op = -1;
      
      
        System.out.println("=============================================");
        System.out.println("<<<<<<<<<<< APP de Gestão TouChim >>>>>>>>>>>");
        System.out.println("=============================================");
        System.out.println();
        
      while(op != 0)
          {
            System.out.println("1  - Adicionar Cliente");
            System.out.println("2  - Criar Conta");
            System.out.println("3  - Adicionar Dispositivo");
            System.out.println("4  - Registar Comunicação");
            System.out.println("5  - Lista de Dispositivos 5G");
            System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
            System.out.println("6  - Lista de Clientes, Contas e Dispositivos");
            System.out.println("7  - Lista de Comunicações efetuadas por um dado Dispositivo");
            System.out.println("8  - Lista de Comunicações Recebidas por Dispositivo");
            System.out.println("9  - Adicionar Contacto");
            System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
            System.out.println("10 - Emitir Fatura Detalhada para uma Conta");
            System.out.println("11 - Exibir listas comunicações entre dois dispositivos");
            System.out.println("12 - Gravar Estado Geral do Sistema");
            System.out.println("13 - Recuperar Estado Geral do Sistema");
            System.out.println("0  - Sair");
            System.out.println();

            op = scanner.nextInt();

            switch (op) {
                case 1:
                    touChim.adicionarCliente(scanner);
                    break;
                case 2:
                    touChim.adiconarNovaContaParaCliente(scanner);
                    break;
                case 3:
                    touChim.adicionarDispositivoDaContax(scanner);
                    break;
                case 4:
                    touChim.realizarcomunicacao(scanner);
                    break;
                case 5:
                     System.out.print("Digite o código da conta: ");
                    String codigoContaListar5G = scanner.next();
                    touChim.ListarDispositivosnoModo5G(codigoContaListar5G);
                    break;
                case 6:
                    touChim.ListaClientesContasDisp();
                    break;
                case 7:
                   touChim.VerComunicacoesEfetuadas(scanner);
                    break;
                case 8:
                    touChim.VerComunicacoesRecebidas(scanner);
                    break;
                case 9:
                    touChim.adicionarContacto(scanner);
                    break;
                case 10:
                    touChim.emitirFaturaDetalhada(scanner);
                    break;
                case 11:
                    touChim.exibirComunicacoes(scanner);
                    break;
                case 12:
                    touChim.gravarEstadoGeral();
                    break;
                case 13:
                    touChim.recuperarEstadoGeral();
                    break;
                case 0:
                    System.out.println("A fechar programa...");
                    break;
                default:
                    System.out.println("Opção inválida. Tente de novo.");
                    break;
            }

            System.out.println();
        }
    }
}
