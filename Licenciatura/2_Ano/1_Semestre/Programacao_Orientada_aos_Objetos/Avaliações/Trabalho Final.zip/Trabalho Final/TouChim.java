import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.IOException;
import java.util.*;
import java.io.*;
import java.io.Serializable;
import java.text.DecimalFormat;

// Registar as comunicações efetuadas pelos clientes.
// Produzir a faturação associada a cada conta.
public class TouChim implements Serializable {
    private List<Cliente> clientes;


    public TouChim() {
        this.clientes = new ArrayList<>();
    }
    //Get's
    public List<Cliente> getClientes() {
        return clientes;
    }
    //Métodos
    public void adicionarCliente(Cliente cliente) {
        clientes.add(cliente);
    }
    //case 1
    public void adicionarCliente(Scanner scanner) {
            System.out.println("== Adicionar Cliente à empresa ==");
            System.out.println();
            System.out.print("Como se chama: ");
            String nome = scanner.next();
            System.out.println();
            System.out.print("Qual vai ser o seu código: ");
            String codigo = scanner.next();
            System.out.println();
            Cliente novoCliente = new Cliente(codigo, nome);
            adicionarCliente(novoCliente);
            System.out.println("Cliente adicionado com sucesso!");
        }
       public Cliente encontrarClientePorCodigo(String codigoCliente) {
        
        for (Cliente cliente : clientes) {
            if (cliente.getCodigo().equals(codigoCliente)) {
                return cliente;
            }
        }
        return null;
    }
    //case 2
    public void adiconarNovaContaParaCliente(Scanner scanner) {
            System.out.println("== Adicionar nova conta para o cliente ==");
            System.out.println();
            System.out.print("Código do cliente: ");
            System.out.println();
            String codigoCliente = scanner.next();
            Cliente cliente = encontrarClientePorCodigo(codigoCliente);
    
            if (cliente != null) {
                System.out.print("Qual é o número da conta que deseja ter: ");
                String codigoConta = scanner.next();
                System.out.println();
                Conta novaConta = new Conta(codigoConta);
                cliente.adicionarConta(novaConta);
                System.out.println("A sua conta foi criada com sucesso, " + cliente.getNome());
            } else {
                System.out.println("Cliente não encontrado.");
            }
        }
    //case 3   
    public void adicionarDispositivoDaContax(Scanner scanner) {
        System.out.println("== Adicionar Dispositivo à Conta ==");
        System.out.println();
        System.out.print("Código do cliente: ");
        String codigoCliente = scanner.next();
        System.out.println();
        Cliente cliente = encontrarClientePorCodigo(codigoCliente);
    
        if (cliente != null) {
            System.out.print("Código da conta respetiva ao novo dispositivo: ");
            String codigoConta = scanner.next();
            System.out.println();
            Conta conta = cliente.encontrarContacomCodigox(codigoConta);
            
            if (conta != null) {
            System.out.print("Escolher o tipo de dispositivo a associar - oldie,tablet ou telemovel :  ");
            String tipoDispositivo = scanner.next();
            System.out.println();
            System.out.print("Número do novo dispositivo: ");
            String numeroDispositivo = scanner.next();
            System.out.println();
            String modoDispositivo;
                
                while (true) {
                System.out.print("Escolher o modo do dispositivo a associar - 4G ou 5G : ");
                modoDispositivo = scanner.next();
        
                if (modoDispositivo.equals("4G") || modoDispositivo.equals("5G")) {
                    break;
                } else {
                    System.out.println("Inserir (4G ou 5G).");
                }
                }
    
            Dispositivo novoDispositivo = Dispositivo.NovoDispositivo(tipoDispositivo, numeroDispositivo, modoDispositivo);
    
                
                if (novoDispositivo != null) {
                    conta.adicionarDispositivos(novoDispositivo);
                    // sistema.adicionarComunicacaoComVelocidade(novoDispositivo);
                    System.out.println("Dispositivo adicionado e associado com sucesso à conta " + conta.getCodigo() +
                            " do cliente " + cliente.getNome());
                } else {
                    System.out.println("Dados do dispositivo inválidos.");
                }
            } else {
                System.out.println("Conta não encontrada para o cliente " + cliente.getNome());
            }
        } else {
            System.out.println("Cliente não encontrado.");
        }
    }
    //Método adicional
    public Dispositivo encontrarDispositivoPorNumero(String numero) {
        for (Cliente cliente : clientes) {
            for (Conta conta : cliente.getContas()) {
                for (Dispositivo dispositivo : conta.getDispositivos()) {
                    if (dispositivo.getNumero().equals(numero)) {
                        return dispositivo;
                    }
                }
            }
        }
        return null;
    }

   //case 4
   public void realizarcomunicacao(Scanner scanner) {
        System.out.print("Número do dispositivo de origem: ");
        int numeroOrigem = scanner.nextInt();
        System.out.println();
        System.out.print("Número do dispositivo de destino: ");
        int numeroDestino = scanner.nextInt();
        System.out.println();
        
        Dispositivo origem = encontrarDispositivoPorNumero(String.valueOf(numeroOrigem));
        Dispositivo destino = encontrarDispositivoPorNumero(String.valueOf(numeroDestino));

        if (origem == null || destino == null) {
        System.out.println("Dispositivo de origem ou dispositivo de destino não encontrado.");
        return;
        }

        System.out.println("Tipo de comunicação:");
        System.out.println("1. Download");
        System.out.println("2. SMS");
        System.out.println("3. Chamada Normal");
        System.out.println("4. Chamada de Vídeo");
        System.out.println("5. Mensagem de Vídeo");
        System.out.println("6. Mensagem de Imagem");

        int escolhaTipoComunicacao = scanner.nextInt();
        scanner.nextLine();
        Comunicacao comunicacao = null;

        switch (escolhaTipoComunicacao) {
            case 1:
                System.out.print("Tamanho do download (em bytes): ");
                int tamanhoDownload = scanner.nextInt();
                scanner.nextLine(); 
                System.out.print("Duração do download: ");
                int duracaoDownload = scanner.nextInt();
                scanner.nextLine(); 
                System.out.print("Velocidade de Transmissão: ");
                double velocidadeTransmissaoPorByte = scanner.nextInt();
                comunicacao = new Download(origem, destino, tamanhoDownload, duracaoDownload, velocidadeTransmissaoPorByte);
                break;
            default:
                System.out.println("Opção inválida.");
                return;
            case 2:
                System.out.print("Tamanho da mensagem: ");
                int tamanhoMensagem = scanner.nextInt();
                scanner.nextLine();
                System.out.print("Escreva o texto da mensagem: ");
                String texto = scanner.nextLine();
                comunicacao = new SMS(origem, destino, tamanhoMensagem, texto);
                break;
            case 3:
                System.out.print("Duração da chamada: ");
                int duracaodechamada = scanner.nextInt();
                comunicacao = new ChamadaNormal(origem, destino, duracaodechamada);
                break;
                
            case 4:
                System.out.print("Duração do vídeo: ");
                int duracaodeVID= scanner.nextInt();
                System.out.print("Formato do vídeo: ");
                String formatodeVID = scanner.nextLine();
                System.out.print("Resolução do vídeo: ");
                String resolucaodeVID = scanner.nextLine();
                comunicacao = new MensagemVideo(origem, destino, duracaodeVID, resolucaodeVID, formatodeVID);
                break;
                
            case 5:
                System.out.print("Duração do vídeo: ");
                int duracaoVID= scanner.nextInt();
                System.out.print("Formato do vídeo: ");
                String formatoVID = scanner.nextLine();
                System.out.print("Resolução do vídeo: ");
                String resolucaoVID = scanner.nextLine();
                comunicacao = new MensagemVideo(origem, destino, duracaoVID, resolucaoVID, formatoVID);
                break;
            case 6:
                System.out.print("Tamanho da imagem: ");
                int tamanhoBytes= scanner.nextInt();
                scanner.nextLine(); 
                System.out.print("Formato da imagem: ");
                String formatoIMG = scanner.nextLine();
                System.out.print("Resolução da imagem: ");
                int resolucaoIMG = scanner.nextInt();
                comunicacao = new MensagemImagem(origem, destino, tamanhoBytes, formatoIMG, resolucaoIMG);
                break;
        }

        origem.fazerComunicacao(destino, comunicacao);
        System.out.println("Esta comunicação foi realizada com sucesso!");
    }
   //case 5
    public void ListarDispositivosnoModo5G(String codigoConta){
        System.out.println("Lista de Dispositivos em Modo 5G:");
    
        // Encontrar a conta pelo código
        Conta conta = ContacomCodigox(codigoConta);
    
        if (conta != null) {
            // Iterar sobre os dispositivos associados à conta
            for (Dispositivo dispositivo : conta.getDispositivos()) {
                if (dispositivo.Modo5G()) {
                    System.out.println("Número do Dispositivo: " + dispositivo.getNumero());
                }
            }
        } else {
            System.out.println("Conta não encontrada para o código " + codigoConta);
        }
    }
    //case 6
    public void ListaClientesContasDisp() {
            System.out.println("Lista:");
            for (Cliente cliente : clientes) {
                System.out.println("Nome: " + cliente.getNome());
                System.out.println("Contas associadas:");
                for (Conta conta : cliente.getContas()) {
                    System.out.println(" Codigo: " + conta.getCodigo());
                    System.out.println(" Dispositivos associados:");
                    for (Dispositivo dispositivo : conta.getDispositivos()) {
                        System.out.println("     Tipo: " + dispositivo.getTipo());
                        System.out.println("     Número: " + dispositivo.getNumero());
                        System.out.println("     Modo: " + dispositivo.getModoRede());
                    }
                }
            }
        }
    //case 7
    public void VerComunicacoesEfetuadas(Scanner scanner) {
        System.out.print("Digite o número do dispositivo para visualizar as comunicações enviadas: ");
        String numeroDispositivo = scanner.nextLine();

        Dispositivo dispositivo = encontrarDispositivoPorNumero(numeroDispositivo);

        if (dispositivo != null) {
            dispositivo.VerComunicacoesEnviadas(numeroDispositivo);
        } else {
            System.out.println("Dispositivo não encontrado.");
        }
    }
   //case 8
   public void VerComunicacoesRecebidas(Scanner scanner) {
        System.out.print("Digite o número do dispositivo para visualizar as comunicações recebidas: ");
        String numeroDispositivo = scanner.nextLine();

        Dispositivo dispositivo = encontrarDispositivoPorNumero(numeroDispositivo);

        if (dispositivo != null) {
            dispositivo.VerComunicacoesRecebidas(numeroDispositivo);
        } else {
            System.out.println("Dispositivo não encontrado.");
        }
    }
    
   private void exibirComunicacoes(List<Comunicacao> comunicacoes) {
        if (comunicacoes.isEmpty()) {
            System.out.println("Nenhuma comunicação disponível.");
        } else {
            for (Comunicacao comunicacao : comunicacoes) {
                System.out.println(comunicacao);
            }
        }
    }
   //Método adicional
    public Conta ContacomCodigox(String codigoConta) {
        for (Cliente cliente : clientes) {
            for (Conta conta : cliente.getContas()) {
                if (conta.getCodigo().equals(codigoConta)) {
                    return conta;
                }
            }
        }
        return null;
    }
   //caso 9
    public void adicionarContacto(Scanner scanner) {
        System.out.println("Adicionar Contacto:");
        System.out.println();
        System.out.print("Nome do contacto: ");
        String nomeContacto = scanner.next();
        System.out.print("Número do contacto: ");
        String numeroContacto = scanner.next();
        System.out.println();

        Contacto novoContacto = new Contacto(nomeContacto, numeroContacto);
        System.out.println("O seu contacto foi adicionado com sucesso!");
    }
   //caso 10
   public void emitirFaturaDetalhada(Scanner scanner) {
    System.out.println("== Emitir Fatura Detalhada para uma Conta ==");
    System.out.println();
    System.out.print("Digite o código do cliente: ");
    String codigoCliente = scanner.next();
    System.out.println();

    Cliente cliente = encontrarClientePorCodigo(codigoCliente);

    if (cliente != null) {
        System.out.print("Digite o código da conta: ");
        String codigoConta = scanner.next();
        System.out.println();

        Conta conta = cliente.encontrarContacomCodigox(codigoConta);

        if (conta != null) {
            System.out.println("Fatura detalhada para a Conta " + conta.getCodigo() + " do/da Cliente " + cliente.getNome());
            System.out.println("=============================================================");

            
            if (conta.getTabelaPrecos() != null) {
                double totalFatura = calcularFaturacao(conta);

                // Calcular o valor do IVA (23%)
                double valorIVA = 0.23 * totalFatura;

                // Adicionar o valor do IVA ao total da fatura
                totalFatura += valorIVA;
                // Formatar o total da fatura para exibir apenas 2 casas decimais
                DecimalFormat decimalFormat = new DecimalFormat("#.##");
                String totalFaturaFormatado = decimalFormat.format(totalFatura);

                for (Comunicacao comunicacao : conta.getComunicacoes()) {
                    // Verificar se o tipo de comunicação não é null
                    if (comunicacao.getTipo() != null) {
                        double custo = conta.getTabelaPrecos().get(comunicacao.getTipo());
                        
                        System.out.println("Tipo: " + comunicacao.getTipo());
                        System.out.println("Custo: " + custo);
                        System.out.println("------------------------------");
                    } else {
                        System.out.println("Tipo de comunicação não suportado pela tabela de preços.");
                    }
                }

                //double totalFatura = calcularFaturacao(conta);
                System.out.println("Total da Fatura (com IVA): " + totalFaturaFormatado);
            } else {
                System.out.println("Tabela de preços não encontrada para a conta " + conta.getCodigo());
            }
        } else {
            System.out.println("Conta não encontrada para o cliente " + cliente.getNome());
        }
    } else {
        System.out.println("Cliente não encontrado.");
    }
    System.out.println();
    }
    //Método Adicional
    public double calcularFaturacao(Conta conta) {
    double totalFatura = 0.0;
    for (Comunicacao comunicacao : conta.getComunicacoes()) {
        TipoComunicacao tipo = comunicacao.getTipo();
        
        System.out.println("Tipo: " + tipo);
        
        if (tipo != null && conta.getTabelaPrecos().containsKey(tipo)) {
            double custo = conta.getTabelaPrecos().get(tipo);
            totalFatura += custo;
            System.out.println("Custo: " + custo);
        } else {
            System.out.println("Tipo de comunicacao nao encontrado na tabela de precos ou tipo nulo.");
        }
    }
    return totalFatura;
    }
    //case 11
    public void exibirComunicacoes(Scanner scanner) { 
    System.out.print("Número do primeiro dispositivo: ");
    String numeroDispositivo1 = scanner.next();
    System.out.print("Número do segundo dispositivo: ");
    String numeroDispositivo2 = scanner.next();

    Dispositivo dispositivo1 = encontrarDispositivoPorNumero(numeroDispositivo1);
    Dispositivo dispositivo2 = encontrarDispositivoPorNumero(numeroDispositivo2);

    if (dispositivo1 != null && dispositivo2 != null) {
        ArrayList<Comunicacao> comunicacoesEnviadas = dispositivo1.listarComunicacoesEnviadas(dispositivo2);
        ArrayList<Comunicacao> comunicacoesRecebidas = dispositivo1.listarComunicacoesRecebidas(dispositivo2);

        System.out.println("Comunicações Enviadas de " + dispositivo1.getNumero() + " para " + dispositivo2.getNumero());
        exibirComunicacoes(comunicacoesEnviadas);

        System.out.println("Comunicações Recebidas por " + dispositivo1.getNumero() + " de " + dispositivo2.getNumero());
        exibirComunicacoes(comunicacoesRecebidas);
    } else {
        System.out.println("Pelo menos um dos dispositivos não foi encontrado.");
    }
    }
    //caso 12
    public void gravarEstadoGeral() {
     String caminhoArquivo ="C:\\Users\\luisp\\OneDrive\\Ambiente de Trabalho\\Trabalho Poo\\estado_geral.ser";
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("estado_geral.ser"))) {
        oos.writeObject(this);
        System.out.println("Estado geral gravado com sucesso.");
    } catch (IOException e) {
        System.err.println("Erro ao gravar estado geral: " + e.getMessage());
        e.printStackTrace();  // Adiciona esta linha para imprimir o rastreamento da exceção
    }
    }
    //caso 14
    public void recuperarEstadoGeral() {
     String caminhoArquivo = "C:\\Users\\luisp\\OneDrive\\Ambiente de Trabalho\\Trabalho Poo\\estado_geral.ser";
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("estado_geral.ser"))) {
        TouChim estadoGeralRecuperado = (TouChim) ois.readObject();
        System.out.println("Estado geral recuperado com sucesso.");
        // Use 'estadoGeralRecuperado' conforme necessário
    } catch (IOException | ClassNotFoundException e) {
        System.err.println("Erro ao recuperar estado geral: " + e.getMessage());
        e.printStackTrace();  // Adiciona esta linha para imprimir o rastreamento da exceção
    }
    }
}
    
    
    
    
    
    
    
    
    
    
    
    
