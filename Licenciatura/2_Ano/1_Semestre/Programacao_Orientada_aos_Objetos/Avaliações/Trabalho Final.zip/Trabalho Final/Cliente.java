import java.util.*;
import java.io.Serializable;
public class Cliente implements Serializable {
    private String codigoCliente;
    private String nome; 
    private List<Conta> contas;
   
   public Cliente(String codigoCliente, String nome) {
        this.nome = nome;
        this.codigoCliente = codigoCliente;
        this.contas = new ArrayList<>();
    }
   //Get's e Set's
   public String getNome() {
        return nome;
    }
   public String getCodigo() {
        return codigoCliente;
   }
   public List<Conta> getContas() {
       return contas;
   }
   public void setNome(String nome) {
        this.nome = nome;
    }
   public void setCodigo(String codigo) {
        this.codigoCliente = codigo;
    }
   //Métodos
    public Conta encontrarContacomCodigox(String codigoConta) {
        for (Conta conta : contas) {
            if (conta.getCodigo().equals(codigoConta)) {
                return conta;
            }
        }
        return null; 
   }
   public void adicionarConta(Conta conta) {
        if (!contas.contains(conta)) {
        contas.add(conta);
    }
   }
    
}