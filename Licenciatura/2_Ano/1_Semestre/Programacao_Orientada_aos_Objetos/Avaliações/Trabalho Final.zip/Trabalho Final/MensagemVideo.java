import java.util.*;
import java.io.Serializable;
public class MensagemVideo extends Comunicacao implements Serializable{
    private int duracaoVID; private String resolucaoVID; private String formatoVID;    

    public MensagemVideo(Dispositivo origem, Dispositivo destino,int duracaoVID, String resolucaoVID, String formatoVID) {
     super(origem,destino,TipoComunicacao.MENSAGEM_VIDEO);
     this.duracaoVID = duracaoVID;
     this.resolucaoVID = resolucaoVID;
     this.formatoVID = formatoVID;
    }
    //Get's
    public int getDuracaoVideo() {
        return duracaoVID;
    }
    public String getResolucaoVideo() {
        return resolucaoVID;
    }
    public String getFormatoVideo() {
        return formatoVID;
    }
    public double calcularCusto() {
        return 0.5 * duracaoVID;
    }
    //Método Clone
    public MensagemVideo clone()
    {
        MensagemVideo MensagemVideo = new MensagemVideo(super.getOrigem(), super.getDestino(), this.duracaoVID,this.resolucaoVID,this.formatoVID);
        return MensagemVideo;
    }
    
    @Override
    public String toString() {
    return "MensagemVideo {" +
           "Origem: " + super.getOrigem().getNumero() +
           ", Destino: " + super.getDestino().getNumero() +
           ", Duração do Vídeo: " + duracaoVID +
           ", Resolução do Vídeo: " + resolucaoVID +
           ", Formato do Vídeo: " + formatoVID +
           '}';
    }
}
