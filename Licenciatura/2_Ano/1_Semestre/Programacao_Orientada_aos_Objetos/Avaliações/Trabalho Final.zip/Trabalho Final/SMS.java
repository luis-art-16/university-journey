import java.util.*;
import java.io.Serializable;
public class SMS extends Comunicacao implements Serializable{
    private int tamanhoMensagem; private String texto;

    public SMS(Dispositivo origem,Dispositivo destino,int tamanhoMensagem,String texto) {
     super(origem,destino,TipoComunicacao.SMS);
     this.tamanhoMensagem = tamanhoMensagem;
     this.texto = texto;
    }
    //Get's
    public int getTamanho(){
        return this.tamanhoMensagem;
    }
    public String getTexto(){
        return this.texto;
    }
    //Método Clone
    public SMS clone()
    {
        SMS sms = new SMS(super.getOrigem(), super.getDestino(), this.tamanhoMensagem, this.texto);
        return sms;
    }
    
     public double calcularCusto() {
        return 0.1;
    }
    
    public String toString() {
    return "SMS - Tamanho da Mensagem: " + tamanhoMensagem + " caracteres, Texto: " + texto;
    }
}

