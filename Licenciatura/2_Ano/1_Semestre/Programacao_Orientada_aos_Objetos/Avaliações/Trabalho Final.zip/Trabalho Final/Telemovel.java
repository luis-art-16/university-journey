import java.util.*;
import java.io.Serializable;
class Telemovel extends Dispositivo implements Serializable{
    private ArrayList<Contacto> contactos;
    
    public Telemovel(String numero, String modoRede, String tipo) {
        super(numero, modoRede, tipo);
        this.contactos = new ArrayList<>();
    }
    
    public void adicionarContacto(Contacto contacto) {
        this.contactos.add(contacto);
    }

    public ArrayList<Contacto> getContactos() {
        return this.contactos;
    }

    public boolean PermitidoRealizarComunicacao(Comunicacao comunicacao) {
        if (comunicacao instanceof MensagemImagem) {
            return true;
        } else if (comunicacao instanceof ChamadaVideo) {
            return true;
        } else if (comunicacao instanceof ChamadaNormal) {
            return true;
        } else if (comunicacao instanceof MensagemVideo) {
            return true;
        } else if (comunicacao instanceof SMS) {
            return true;
        }
        return false;
    }

    public Telemovel clone() {
        Telemovel tele = new Telemovel(super.getNumero(), super.getModoRede(), super.getTipo());

        for (Contacto contacto : this.contactos) {
            tele.adicionarContacto(contacto);
        }

        for (Comunicacao com : super.getComunicacoes()) {
            tele.adicionarComunicacao(com);
        }

        return tele;
    }
}
