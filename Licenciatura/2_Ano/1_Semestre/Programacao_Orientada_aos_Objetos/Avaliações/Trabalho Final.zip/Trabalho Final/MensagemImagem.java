import java.util.*;
import java.io.Serializable;
public class MensagemImagem extends Comunicacao implements Serializable{
    private int tamanhoBytes; private int resolucaoIMG; private String formatoIMG;
   
    public MensagemImagem(Dispositivo origem,Dispositivo destino,int tamanhoBytes,String formatoIMG,int resolucaoIMG) {
     super(origem,destino,TipoComunicacao.MENSAGEM_IMAGEM);
     this.tamanhoBytes = tamanhoBytes;
     this.formatoIMG = formatoIMG;
     this.resolucaoIMG = resolucaoIMG;
    }
    //Get's
     public int getTamanhoImagem() {
        return tamanhoBytes;
    }
    public String getFormatoImagem() {
        return formatoIMG;
    }
    public int getResolucaoImagem() {
        return resolucaoIMG;
    }
    //Método Clone
    public MensagemImagem clone()
    {
        MensagemImagem MensagemImagem = new MensagemImagem(super.getOrigem(), super.getDestino(), this.tamanhoBytes, this.formatoIMG,this.resolucaoIMG);
        return MensagemImagem;
    }
    
     public double calcularCusto() {
        return 0.5;
    }

    public String toString() {
    return "Mensagem de Imagem - Tamanho: " + tamanhoBytes + " bytes, Formato: " + formatoIMG + ", Resolução: " + resolucaoIMG;
    }
}
 
