atpl 150
atget id my_id

set C1_HOP_REVERSO 27 
set C2_ID 33         

set timer_segundos 0

set cmd_enviado 0

set frame "CONFIG"

atget id my_id

cprint "GATEWAY INICIADO. A escutar..."

loop
    
    receive msg 500
    
    if (msg != "")

        time t_rececao
        vdata v msg
        vget tipo v 1
        
        if (tipo == "PARK")
            vget sensor_id v 2
            vget status v 4


            cprint "------------------------------------------------"
            if (status == 1)
                cprint t_rececao "| P | ESTADO LUGAR" sensor_id ": OCUPADO"
            else
                cprint t_rececao "| P | ESTADO LUGAR" sensor_id ": LIVRE"
            end

            cprint "------------------------------------------------"
        else
            if (tipo == "DATA")
                vget id_sensor v 2
                vget temp v 4
                vget hum v 5
                vget co2 v 6
                vget pm10 v 7
             
                cprint "================================================"
                cprint t_rececao " | A | DADOS AMBIENTAIS (Sensor" id_sensor ")"
                cprint "================================================"
                cprint "    > Temp: " temp " C   | Hum: " hum " %"
                cprint "    > CO2:  " co2 " ppm | PM10: " pm10
                cprint "================================================"
            else
                cprint "Msg desconhecida:" msg
            end
        end
    end
    inc timer_segundos
    
    if ((timer_segundos > 60) && (cmd_enviado == 0))
        set cmd_enviado 1 
        time timestamp
        data p_config timestamp frame my_id 15000
        
        send p_config C1_HOP_REVERSO
        
        send p_config C2_ID

        cprint "GATEWAY" my_id "ENVIOU DOWNLINK para" C1_HOP_REVERSO "e" C2_ID
        
    end
