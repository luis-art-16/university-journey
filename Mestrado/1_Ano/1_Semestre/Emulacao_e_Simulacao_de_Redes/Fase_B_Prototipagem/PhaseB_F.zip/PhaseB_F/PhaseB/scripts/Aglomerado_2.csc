atget id my_id
atpl 150
set GW_ID 30    
set VENT_ID 69 
set vent_status 0
set sample_period 10000
set frame_type "DATA"

cprint "Sensor Amb" my_id "iniciado..."

loop
    areadsensor s
    
    if (s != "X")
        vdata values s
        vget temp values 2
        vget hum values 4
        vget co2 values 6
        vget pm10 values 8
        
        time timestamp
        
        data p timestamp frame_type my_id GW_ID temp hum co2 pm10

        randb backoff 0 250
        delay backoff

        send p GW_ID
        
        cprint "Sensor" my_id "ENVIOU (Amb):" p

        set command 0
        if (co2 > 1000)
             set command 1
        end
        if (command != vent_status)
            set vent_status command
            if (vent_status == 1)
                send "VENT_ON" VENT_ID
            else
                send "VENT_OFF" VENT_ID
            end
        end
        
    else
        cprint "NADA LIDO (Amb)"
    end
    
    receive msg_downlink sample_period
    if (msg_downlink != "")
        rdata msg_downlink cmd_tipo cmd_valor
        if (cmd_tipo == "CONFIG")
            set sample_period cmd_valor
            time t_rec
            cprint t_rec "| Sensor" my_id "RECEBEU DOWNLINK (Config):" cmd_valor "ms"
        end
    end