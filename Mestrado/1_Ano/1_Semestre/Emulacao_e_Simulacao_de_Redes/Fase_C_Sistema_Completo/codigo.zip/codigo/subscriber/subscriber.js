const mqtt = require('mqtt');
const mysql = require('mysql2/promise');

const client = mqtt.connect('mqtt://127.0.0.1:1883');
const pool = mysql.createPool({
    host: process.env.DB_HOST || '127.0.0.1',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASS,  // <-- Agora é dinâmico
    database: process.env.DB_NAME || 'iot_cloud'
});

client.on('connect', () => {
    console.log('Subscriber Connected');
    client.subscribe('sensors/+/data');
});

client.on('message', async (topic, message) => {
    try {
        const payload = JSON.parse(message.toString());
        const { device_id, api_key, timestamp, data } = payload;

        // 1. Validar Key
        const [devs] = await pool.execute('SELECT id FROM devices WHERE device_id = ? AND api_key = ?', [device_id, api_key]);
        if (devs.length === 0) return console.log(`⛔ Key invalida: ${device_id}`);

        // 2. Gravar
        console.log(`📥 ${data.type} recebido`);
        
        if (data.type === 'parking') {
            await save(device_id, timestamp, 'occupied', data.occupied ? 1 : 0, 'bool');
            await save(device_id, timestamp, 'distance', data.distance_cm, 'cm');
        } else if (data.type === 'environmental') {
            await save(device_id, timestamp, 'temperature', data.temperature_c, 'C');
            await save(device_id, timestamp, 'humidity', data.humidity_percent, '%');
            await save(device_id, timestamp, 'co2', data.co2_ppm, 'ppm');
            await save(device_id, timestamp, 'pm10', data.pm10_ugm3, 'ug/m3');
        }
    } catch (e) { console.error(e.message); }
});

async function save(dev, time, type, val, unit) {
    if(val === undefined) return;
    await pool.execute('INSERT INTO readings (device_id, timestamp, measurement_type, value, unit) VALUES (?,?,?,?,?)', [dev, time, type, val, unit]);
}
