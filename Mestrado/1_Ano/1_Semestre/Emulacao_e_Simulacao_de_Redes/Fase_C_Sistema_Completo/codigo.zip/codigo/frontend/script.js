const API = '/api';
let mainChart;
let socket;
let lastReadings = []; // Guardar dados para trocar de gráfico sem fetch
let currentSensor = null; // Qual o gráfico atual? (null = nenhum)

// Configuração visual de cada sensor
const SENSOR_CONFIG = {
    'temperature': { label: 'Temperatura', unit: '°C', color: '#f97316', bg: 'rgba(249, 115, 22, 0.1)' }, // Laranja
    'humidity':    { label: 'Humidade',    unit: '%',  color: '#3b82f6', bg: 'rgba(59, 130, 246, 0.1)' }, // Azul
    'co2':         { label: 'CO2',         unit: 'ppm', color: '#4b5563', bg: 'rgba(75, 85, 99, 0.1)' },  // Cinza
    'pm10':        { label: 'PM10',        unit: 'µg/m³', color: '#a855f7', bg: 'rgba(168, 85, 247, 0.1)' } // Roxo
};

// --- FUNÇÃO PARA SELECIONAR SENSOR (CLICK) ---
// --- FUNÇÃO PARA SELECIONAR SENSOR (CLICK) ---
function selectSensor(type) {
    currentSensor = type;

    // 1. Mostrar o Canvas e esconder o Aviso
    document.getElementById('chart-placeholder').classList.add('hidden');
    const canvas = document.getElementById('mainChart');
    canvas.classList.remove('hidden');
    document.getElementById('chart-title').classList.remove('hidden');
    document.getElementById('chart-title').innerText = "Histórico de " + SENSOR_CONFIG[type].label;

    // 2. Destruir gráfico anterior se existir
    if (mainChart) mainChart.destroy();

    // 3. Preparar dados
    const hist = lastReadings
        .filter(r => r.measurement_type === type)
        .slice(0, 20)
        .reverse();

    const ctx = canvas.getContext('2d');
    const config = SENSOR_CONFIG[type];

    // Gradiente
    const gradient = ctx.createLinearGradient(0, 0, 0, 400);
    gradient.addColorStop(0, config.color);
    gradient.addColorStop(1, 'rgba(255, 255, 255, 0)');

    // 4. Criar o Gráfico com Ajustes de Layout
    mainChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: hist.map(r => new Date(r.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit', second:'2-digit'})),
            datasets: [{
                label: config.label,
                borderColor: config.color,
                backgroundColor: gradient,
                borderWidth: 2,
                pointRadius: 3,
                pointHoverRadius: 6,
                tension: 0.4,
                fill: true,
                data: hist.map(r => r.value)
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,

            // --- CORREÇÃO DO TÍTULO ---
            layout: {
                padding: {
                    top: 40,   // Espaço extra no topo para o título não tapar a linha
                    left: 10,
                    right: 10,
                    bottom: 10
                }
            },

            interaction: {
                mode: 'index',
                intersect: false,
            },
            plugins: {
                legend: { display: false },
                tooltip: {
                    backgroundColor: 'rgba(30, 41, 59, 0.9)',
                    titleColor: '#fff',
                    bodyColor: '#cbd5e1',
                    padding: 10,
                    cornerRadius: 8,
                    displayColors: false
                }
            },
            scales: {
                x: {
                    display: false // --- CORREÇÃO: REMOVER EIXO DO TEMPO ---
                },
                y: {
                    border: { display: false },
                    grid: {
                        color: '#f1f5f9',
                        borderDash: [5, 5]
                    },
                    ticks: {
                        color: '#94a3b8',
                        font: { family: "'Segoe UI', sans-serif", size: 11 },
                        callback: function(value) {
                            return value + ' ' + config.unit;
                        }
                    }
                }
            }
        }
    });

    // 5. Destacar visualmente o cartão selecionado
    ['temperature','humidity','co2','pm10'].forEach(t => {
        const card = document.getElementById('card-'+t);
        if(t === type) card.classList.add('ring-2', 'ring-offset-2', 'ring-gray-300');
        else card.classList.remove('ring-2', 'ring-offset-2', 'ring-gray-300');
    });
}

// --- AUTH ---
async function login() {
    const email = document.getElementById('email').value;
    const pass = document.getElementById('pass').value;
    try {
        const res = await fetch(API+'/users/login', {
            method: 'POST', headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({email, password: pass})
        });
        const data = await res.json();
        if(data.token) {
            localStorage.setItem('token', data.token);
            localStorage.setItem('role', data.role);
            localStorage.setItem('name', data.name || data.user);
            checkAuth();
        } else document.getElementById('error').innerText = data.error;
    } catch(e) { alert("Erro de conexão"); }
}

function logout() { localStorage.clear(); location.reload(); }

function checkAuth() {
    const token = localStorage.getItem('token');
    const role = localStorage.getItem('role');
    const name = localStorage.getItem('name');

    if(token) {
        document.getElementById('login-screen').classList.add('hidden');
        document.getElementById('sidebar').classList.remove('hidden');
        document.getElementById('sidebar').classList.add('flex');
        document.getElementById('main-content').classList.remove('hidden');

        document.getElementById('user-name').innerText = name;
        document.getElementById('user-role').innerText = role === 'admin' ? 'Administrador' : 'Utilizador';
        document.getElementById('user-initial').innerText = name.charAt(0).toUpperCase();

        // SE FOR ADMIN: Mostra menus extra E o painel de controlo
        if(role === 'admin') {
            document.getElementById('admin-menu').classList.remove('hidden');
            // Tenta encontrar o painel de controlo e mostra-o
            const controls = document.getElementById('admin-controls');
            if(controls) controls.classList.remove('hidden');
        }

        fetchData();
        initSocket();
    }
}

// --- DASHBOARD DATA ---
async function fetchData() {
    const token = localStorage.getItem('token');
    if(!token) return;
    try {
        const res = await fetch(API+'/data/latest', { headers: { 'Authorization': 'Bearer '+token } });
        if(res.status === 401) logout();
        const json = await res.json();

        // GUARDAR DADOS GLOBAIS (A parte que faltava no código antigo)
        lastReadings = json.data || [];
        updateCards(lastReadings);

        // Se já tivermos um sensor selecionado, atualizamos o gráfico
        if(currentSensor) selectSensor(currentSensor);

    } catch(e){}
}

function updateCards(rows) {
    const park = rows.find(r => r.measurement_type === 'occupied');
    const dist = rows.find(r => r.measurement_type === 'distance');
    const temp = rows.find(r => r.measurement_type === 'temperature');
    const hum = rows.find(r => r.measurement_type === 'humidity');
    const co2 = rows.find(r => r.measurement_type === 'co2');
    const pm10 = rows.find(r => r.measurement_type === 'pm10');

    if(park) {
        const isOcc = park.value == 1;
        document.getElementById('park-status').innerText = isOcc ? "OCUPADO" : "LIVRE";
        document.getElementById('park-status').className = "text-5xl font-black " + (isOcc ? "text-red-500" : "text-green-500");
        document.getElementById('car-icon').className = "h-20 w-20 rounded-full flex items-center justify-center text-4xl border-4 shadow-inner transition-colors duration-500 " +
            (isOcc ? "bg-red-100 text-red-500 border-red-200" : "bg-green-100 text-green-500 border-green-200");
    }
    if(dist) document.getElementById('park-dist-badge').innerText = `Dist: ${dist.value} cm`;
    if(temp) document.getElementById('temp').innerText = Number(temp.value).toFixed(1);
    if(hum) document.getElementById('hum').innerText = Number(hum.value).toFixed(1);
    if(co2) document.getElementById('co2').innerText = Math.round(co2.value);
    if(pm10) document.getElementById('pm10').innerText = Number(pm10.value).toFixed(2);
}

// --- SOCKET.IO ---
function initSocket() {
    socket = io();
    socket.on('connect', () => console.log("🟢 WebSocket Conectado!"));

    socket.on('new-data', (payload) => {
        const data = payload.data;

        // 1. Atualizar números nos cartões imediatamente
        if (data.type === 'environmental') {
            if(data.temperature_c !== undefined) document.getElementById('temp').innerText = Number(data.temperature_c).toFixed(1);
            if(data.humidity_percent !== undefined) document.getElementById('hum').innerText = Number(data.humidity_percent).toFixed(1);
            if(data.co2_ppm !== undefined) document.getElementById('co2').innerText = Math.round(data.co2_ppm);
            if(data.pm10_ugm3 !== undefined) document.getElementById('pm10').innerText = Number(data.pm10_ugm3).toFixed(2);

            // 2. Processar TODOS os campos que vieram na mensagem
            const mapping = [
                { key: 'temperature_c', type: 'temperature' },
                { key: 'humidity_percent', type: 'humidity' },
                { key: 'co2_ppm', type: 'co2' },
                { key: 'pm10_ugm3', type: 'pm10' }
            ];

            mapping.forEach(item => {
                if (data[item.key] !== undefined) {
                    const val = data[item.key];

                    // A. Guardar em memória
                    lastReadings.unshift({
                        measurement_type: item.type,
                        value: val,
                        timestamp: payload.timestamp
                    });

                    // B. Se este é o sensor que estamos a ver AGORA, atualizar o gráfico
                    if (currentSensor === item.type && mainChart) {
                        const timeLabel = new Date(payload.timestamp).toLocaleTimeString();
                        mainChart.data.labels.push(timeLabel);
                        mainChart.data.datasets[0].data.push(val);

                        if (mainChart.data.labels.length > 20) {
                            mainChart.data.labels.shift();
                            mainChart.data.datasets[0].data.shift();
                        }
                        mainChart.update();
                    }
                }
            });
        }
        else if (data.type === 'parking') {
            const isOcc = data.occupied ? 1 : 0;
            document.getElementById('park-status').innerText = isOcc ? "OCUPADO" : "LIVRE";
            document.getElementById('park-status').className = "text-5xl font-black " + (isOcc ? "text-red-500" : "text-green-500");
            document.getElementById('car-icon').className = "h-20 w-20 rounded-full flex items-center justify-center text-4xl border-4 shadow-inner transition-colors duration-500 " +
            (isOcc ? "bg-red-100 text-red-500 border-red-200" : "bg-green-100 text-green-500 border-green-200");
        }
    });
}

// --- USERS MANAGEMENT ---
function openModal() { document.getElementById('modal-user').classList.remove('hidden'); }
function closeModal() { document.getElementById('modal-user').classList.add('hidden'); }

async function createUser() {
    const name = document.getElementById('new-name').value;
    const email = document.getElementById('new-email').value;
    const pass = document.getElementById('new-pass').value;
    const role = document.getElementById('new-role').value;

    if(!name || !email || !pass) return alert("Preencha tudo!");

    const res = await fetch(API+'/users/register', {
        method: 'POST',
        headers: {'Content-Type': 'application/json', 'Authorization': 'Bearer '+localStorage.getItem('token')},
        body: JSON.stringify({username: name, email, password: pass, role})
    });
    const data = await res.json();
    if(data.success) {
        alert("Utilizador Criado!");
        closeModal();
        fetchUsers();
    } else {
        alert("Erro: " + data.error);
    }
}

async function fetchUsers() {
    const res = await fetch(API+'/admin/users', { headers: { 'Authorization': 'Bearer '+localStorage.getItem('token') } });
    const users = await res.json();
    document.getElementById('users-table-body').innerHTML = users.map(u => `
        <tr class="hover:bg-gray-50">
            <td class="p-4 font-bold">${u.username}</td>
            <td class="p-4">${u.email}</td>
            <td class="p-4"><span class="px-2 py-1 rounded text-xs font-bold ${u.role==='admin'?'bg-purple-100 text-purple-600':'bg-green-100 text-green-600'}">${u.role.toUpperCase()}</span></td>
            <td class="p-4"><button onclick="deleteUser(${u.id})" class="text-red-400 hover:text-red-600"><i class="fa-solid fa-trash"></i></button></td>
        </tr>
    `).join('');
}

async function deleteUser(id) {
    if(confirm("Eliminar utilizador?")) {
        await fetch(API+'/admin/users/'+id, { method: 'DELETE', headers: { 'Authorization': 'Bearer '+localStorage.getItem('token') } });
        fetchUsers();
    }
}


// --- CONTROLO REMOTO ---
async function sendCommand(type, cmd) {
    const token = localStorage.getItem('token');
    if(!token) return alert("Precisa de fazer login!");

    // Feedback visual imediato (Opcional)
    // Mostra um "toast" ou muda o botão, mas por agora usamos alert simples

    try {
        const res = await fetch(API + '/command', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + token
            },
            body: JSON.stringify({ device_type: type, command: cmd })
        });

        const data = await res.json();

        if(data.success) {
            alert("✅ " + data.message);
        } else {
            alert("❌ Erro: " + data.error);
        }
    } catch (e) {
        alert("Erro de comunicação com a API");
    }
}

// --- DEVICES MANAGEMENT ---
function openDeviceModal() { document.getElementById('modal-device').classList.remove('hidden'); }
function closeDeviceModal() { document.getElementById('modal-device').classList.add('hidden'); }

async function fetchDevices() {
    try {
        const res = await fetch(API+'/admin/devices', { headers: { 'Authorization': 'Bearer '+localStorage.getItem('token') } });
        const devices = await res.json();

        document.getElementById('devices-table-body').innerHTML = devices.map(d => `
            <tr class="hover:bg-gray-50">
                <td class="p-4 font-bold text-gray-700">${d.device_id}</td>
                <td class="p-4"><span class="px-2 py-1 rounded text-xs font-bold ${d.type==='parking'?'bg-red-100 text-red-600':'bg-green-100 text-green-600'}">${d.type.toUpperCase()}</span></td>
                <td class="p-4 text-gray-500">${d.description || '-'}</td>
                <td class="p-4 font-mono text-xs text-blue-500">${d.api_key}</td>
                <td class="p-4"><button onclick="deleteDevice(${d.id})" class="text-red-400 hover:text-red-600"><i class="fa-solid fa-trash"></i></button></td>
            </tr>
        `).join('');
    } catch(e) { console.error(e); }
}

async function createDevice() {
    const device_id = document.getElementById('dev-id').value;
    const type = document.getElementById('dev-type').value;
    const description = document.getElementById('dev-desc').value;
    const api_key = document.getElementById('dev-key').value;

    if(!device_id || !api_key) return alert("ID e Key são obrigatórios!");

    const res = await fetch(API+'/admin/devices', {
        method: 'POST',
        headers: {'Content-Type': 'application/json', 'Authorization': 'Bearer '+localStorage.getItem('token')},
        body: JSON.stringify({ device_id, type, description, api_key })
    });
    const data = await res.json();

    if(data.success) {
        alert("Dispositivo Criado!");
        closeDeviceModal();
        fetchDevices();
    } else {
        alert("Erro: " + data.error);
    }
}

async function deleteDevice(id) {
    if(confirm("Tem a certeza? Isto não apaga o sensor físico, apenas o registo.")) {
        await fetch(API+'/admin/devices/'+id, { method: 'DELETE', headers: { 'Authorization': 'Bearer '+localStorage.getItem('token') } });
        fetchDevices();
    }
}

// Procure a função showPage existente e mude para isto:
function showPage(id) {
    ['dashboard','users','devices'].forEach(p => document.getElementById('page-'+p).classList.add('hidden'));
    document.getElementById('page-'+id).classList.remove('hidden');

    if(id === 'users') fetchUsers();
    if(id === 'devices') fetchDevices(); // <--- NOVA LINHA
}

checkAuth();