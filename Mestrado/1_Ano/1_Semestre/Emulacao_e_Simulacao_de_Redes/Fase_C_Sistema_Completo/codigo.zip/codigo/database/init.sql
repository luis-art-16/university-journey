CREATE DATABASE IF NOT EXISTS iot_cloud;
USE iot_cloud;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50),
    email VARCHAR(100) UNIQUE,
    password_hash VARCHAR(255),
    role ENUM('admin', 'user') DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE devices (
    id INT AUTO_INCREMENT PRIMARY KEY,
    device_id VARCHAR(100) UNIQUE,
    api_key VARCHAR(100) UNIQUE,
    type ENUM('parking', 'environmental'),
    last_seen TIMESTAMP NULL
);

CREATE TABLE readings (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    device_id VARCHAR(100),
    timestamp DATETIME,
    measurement_type VARCHAR(50),
    value FLOAT,
    unit VARCHAR(20),
    FOREIGN KEY (device_id) REFERENCES devices(device_id) ON DELETE CASCADE
);

-- Admin (Pass: admin123)
INSERT INTO users (username, email, password_hash, role) VALUES 
('admin', 'admin@g3.uminho.pt', '$2a$10$tyRknKWGvAcEkTx2VGqCN.AQqFCKPEaluKxC0nGBGqJmwHSLyhAti', 'admin');

-- Dispositivos
INSERT INTO devices (device_id, api_key, type) VALUES 
('sensor_parking_01', 'key_park_p1', 'parking'),
('sensor_ambient_01', 'key_env_a1', 'environmental');
