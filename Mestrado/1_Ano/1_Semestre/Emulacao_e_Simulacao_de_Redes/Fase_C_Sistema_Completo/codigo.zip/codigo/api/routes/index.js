const express = require('express');
const router = express.Router();
const { authenticate, isAdmin } = require('../middleware/auth');

// Controladores
const authController = require('../controllers/authController');
const dataController = require('../controllers/dataController');
const deviceController = require('../controllers/deviceController');

// --- Rotas de Autenticação ---
router.post('/users/login', authController.login);
router.post('/users/register', authenticate, isAdmin, authController.register);

// --- Rotas de Admin ---
router.get('/admin/users', authenticate, isAdmin, authController.getUsers);
router.delete('/admin/users/:id', authenticate, isAdmin, authController.deleteUser);

// --- Rotas de Dados e Comandos ---
router.get('/data/latest', authenticate, dataController.getLatestData);
router.post('/command', authenticate, isAdmin, dataController.sendCommand);

// --- Rotas de Dispositivos (Admin) ---
router.get('/admin/devices', authenticate, isAdmin, deviceController.getDevices);
router.post('/admin/devices', authenticate, isAdmin, deviceController.createDevice);
router.delete('/admin/devices/:id', authenticate, isAdmin, deviceController.deleteDevice);

module.exports = router;