const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/User'); // Importar o Modelo
const JWT_SECRET = process.env.JWT_SECRET || 'segredo_fase_c';

exports.login = async (req, res) => {
    const { email, password } = req.body;
    try {
        // VERSÃO ANTIGA: const [users] = await pool.execute('SELECT * FROM users...', [email]);
        // VERSÃO NOVA (SEQUELIZE):
        const user = await User.findOne({ where: { email } });

        if (!user) return res.status(401).json({ error: 'Utilizador não encontrado' });

        const valid = await bcrypt.compare(password, user.password_hash);
        if (!valid) return res.status(401).json({ error: 'Password incorreta' });

        const token = jwt.sign(
            { id: user.id, role: user.role, name: user.username },
            JWT_SECRET,
            { expiresIn: '4h' }
        );
        res.json({ token, role: user.role, name: user.username });
    } catch (e) { res.status(500).json({ error: e.message }); }
};

exports.register = async (req, res) => {
    const { username, email, password, role } = req.body;
    try {
        // Verificar se existe
        const exists = await User.findOne({ where: { email } });
        if (exists) return res.status(400).json({ error: "Email já existe" });

        const hash = await bcrypt.hash(password, 10);

        // Criar utilizador
        await User.create({
            username,
            email,
            password_hash: hash,
            role: role || 'user'
        });

        res.json({ success: true, message: "Utilizador criado" });
    } catch (e) { res.status(500).json({ error: e.message }); }
};

exports.getUsers = async (req, res) => {
    try {
        const users = await User.findAll({
            attributes: ['id', 'username', 'email', 'role', 'created_at'] // Selecionar apenas campos seguros
        });
        res.json(users);
    } catch (e) { res.status(500).json({ error: e.message }); }
};

exports.deleteUser = async (req, res) => {
    try {
        await User.destroy({ where: { id: req.params.id } });
        res.json({ success: true });
    } catch (e) { res.status(500).json({ error: e.message }); }
};