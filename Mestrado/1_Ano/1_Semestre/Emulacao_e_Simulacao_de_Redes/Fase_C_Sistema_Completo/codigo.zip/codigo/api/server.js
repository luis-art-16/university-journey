const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');

const sequelize = require('./config/db');
require('./models/User');   // Carregar modelos
require('./models/Reading');
require('./models/Device'); // <--- Carregar o novo modelo

// Importar os nossos módulos novos
const routes = require('./routes/index'); // Onde estão as rotas
const mqttClient = require('./services/mqtt'); // O serviço MQTT

const app = express();
app.use(cors());
app.use(express.json());

// 1. Setup Servidor HTTP + Socket.io
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });

// 2. Usar as Rotas (Tudo o que for /api vai para o nosso ficheiro de rotas)
app.use('/api', routes);

// 3. Lógica WebSocket (MQTT -> Browser)
// O MQTT já está conectado (no services/mqtt.js), aqui só ouvimos mensagens
mqttClient.on('message', (topic, message) => {
    try {
        const msgString = message.toString();
        // console.log("📥 MQTT -> Socket:", msgString); // Descomente para debug
        const payload = JSON.parse(msgString);
        io.emit('new-data', payload);
    } catch (e) {
        console.error("❌ Erro JSON no Socket:", e.message);
    }
});

// 4. Iniciar Servidor
const PORT = 3000;
sequelize.sync({ alter: true }).then(() => { // <--- ESTA LINHA CRIA AS TABELAS QUE FALTAM
    server.listen(PORT, () => {
        console.log(`🚀 API Professional (MVC) running on port ${PORT}`);
    });
});