const mqtt = require('mqtt');
const host = process.env.MQTT_HOST || '127.0.0.1';
const port = process.env.MQTT_PORT || 1883;

const client = mqtt.connect(`mqtt://${host}:${port}`);

client.on('connect', () => {
    console.log('✅ MQTT Service: Conectado ao Broker');
    client.subscribe('sensors/+/data'); // Subscrever para ouvir dados
});

module.exports = client;