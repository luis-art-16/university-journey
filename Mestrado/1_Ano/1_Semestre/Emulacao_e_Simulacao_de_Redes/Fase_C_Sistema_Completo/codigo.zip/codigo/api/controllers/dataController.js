const Reading = require('../models/Reading');
const mqttClient = require('../services/mqtt');

exports.getLatestData = async (req, res) => {
    try {
        // Busca as últimas 50 leituras ordenadas por tempo
        const rows = await Reading.findAll({
            limit: 50,
            order: [['timestamp', 'DESC']]
        });

        // (Opcional) Se quiser Alertas, teria de criar o Model Alert também.
        // Por agora, retornamos array vazio para não partir o frontend
        res.json({ data: rows, alerts: [] });
    } catch (e) { res.status(500).json({ error: e.message }); }
};

exports.sendCommand = (req, res) => {
    // (Esta função mantém-se igual porque não usa base de dados, só MQTT)
    const { device_type, command } = req.body;

    let topic = "";
    if (device_type === 'parking') topic = 'sensors/parking/cmd';
    else if (device_type === 'environmental') topic = 'sensors/environmental/cmd';
    else return res.status(400).json({ error: "Tipo de dispositivo desconhecido" });

    const payload = JSON.stringify({
        command: command,
        user: req.user.name,
        timestamp: new Date().toISOString()
    });

    mqttClient.publish(topic, payload);
    console.log(`📢 Comando enviado para ${topic}: ${command}`);

    res.json({ success: true, message: `Comando ${command} enviado!` });
};