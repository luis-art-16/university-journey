const Device = require('../models/Device');

// Listar todos os dispositivos
exports.getDevices = async (req, res) => {
    try {
        const devices = await Device.findAll();
        res.json(devices);
    } catch (e) { res.status(500).json({ error: e.message }); }
};

// Criar novo dispositivo
exports.createDevice = async (req, res) => {
    const { device_id, type, description, api_key } = req.body;
    try {
        // Verificar duplicados
        const exists = await Device.findOne({ where: { device_id } });
        if (exists) return res.status(400).json({ error: "ID do dispositivo já existe!" });

        await Device.create({ device_id, type, description, api_key });
        res.json({ success: true, message: "Dispositivo adicionado!" });
    } catch (e) { res.status(500).json({ error: e.message }); }
};

// Apagar dispositivo
exports.deleteDevice = async (req, res) => {
    try {
        await Device.destroy({ where: { id: req.params.id } });
        res.json({ success: true });
    } catch (e) { res.status(500).json({ error: e.message }); }
};