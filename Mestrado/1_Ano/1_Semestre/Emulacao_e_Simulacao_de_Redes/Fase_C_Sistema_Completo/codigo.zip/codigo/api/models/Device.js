const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

const Device = sequelize.define('Device', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    device_id: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true // "sensor_park_01" não pode repetir
    },
    type: {
        type: DataTypes.ENUM('parking', 'environmental'),
        allowNull: false
    },
    description: {
        type: DataTypes.STRING, // Ex: "Entrada Principal"
        allowNull: true
    },
    api_key: {
        type: DataTypes.STRING, // A chave de segurança para este sensor
        allowNull: false
    }
}, {
    tableName: 'devices',
    timestamps: false
});

module.exports = Device;