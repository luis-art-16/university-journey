const { Sequelize } = require('sequelize');

// Configuração da conexão usando variáveis de ambiente (ou valores default)
const sequelize = new Sequelize(
    process.env.DB_NAME || 'iot_cloud',
    process.env.DB_USER || 'root',
    process.env.DB_PASS || '1234',
    {
        host: process.env.DB_HOST || '127.0.0.1',
        dialect: 'mysql',
        logging: false, // Define como console.log para ver o SQL se quiser debug
        pool: {
            max: 5,
            min: 0,
            acquire: 30000,
            idle: 10000
        }
    }
);

// Testar conexão
sequelize.authenticate()
    .then(() => console.log('✅ Sequelize: Conectado ao MySQL com sucesso!'))
    .catch(err => console.error('❌ Sequelize: Erro de conexão:', err));

module.exports = sequelize;