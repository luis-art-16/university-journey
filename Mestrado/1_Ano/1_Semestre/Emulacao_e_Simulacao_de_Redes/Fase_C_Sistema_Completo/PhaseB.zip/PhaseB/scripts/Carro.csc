
cprint "Motorista pronto! A iniciar rota..."

loop
    // 1. Avançar um passo
    move
    
    // 2. Ler coordenadas atuais (x=Long, y=Lat)
    getpos x y
    
    // 3. Verificar se estamos na zona do estacionamento
    // Latitude alvo: 55.47195... -> Intervalo: 55.47190 a 55.47200
    if (X > 55.47190)
        if (X < 55.47200)
            
            // Só pára se ainda não tiver parado nesta viagem
            if (parou == 0)
                cprint "CHEGOU AO LUGAR! A estacionar..."
                
                delay 30000 
                
                cprint "Tempo esgotado. A sair do lugar..."
                set parou 1
            end
        end
    end