atget id my_id
atpl 150

set ROUTER_BS_ID 27 
set SENSOR_C1_ID 32 

loop
    receive msg
    vdata v msg
    vget tipo v 1
    
    if (tipo == "PARK")
        send msg ROUTER_BS_ID
        cprint "BS" my_id "REENVIOU (Park):" msg
    else
        if (tipo == "DATA")
            send msg ROUTER_BS_ID
            cprint "BS" my_id "REENVIOU (Amb):" msg
        else
            if (tipo == "ACTUATOR")
                send msg ROUTER_BS_ID
                cprint "BS" my_id "REENVIOU (Actuator):" msg
            else
                if (tipo == "CONFIG")
                    send msg SENSOR_C1_ID
                    cprint "BS" my_id "REENVIOU DOWNLINK (Config):" msg
                else
                    cprint "Recebida msg desconhecida:" msg
                end
            end
        end
    end
