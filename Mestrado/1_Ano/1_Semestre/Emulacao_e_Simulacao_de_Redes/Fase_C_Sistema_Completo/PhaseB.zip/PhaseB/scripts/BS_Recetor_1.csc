atget id my_id
atpl 150
set GW_ID 30        
set BS_PREV_ID 23   

loop
    receive msg
    vdata v msg
    vget tipo v 1
    
    if (tipo == "PARK")
        send msg GW_ID
        cprint "BS" my_id "REENVIOU (Park):" msg
    else
        if (tipo == "DATA")
            send msg GW_ID
            cprint "BS" my_id "REENVIOU (Amb):" msg
        else
            if (tipo == "ACTUATOR")
                send msg GW_ID
                cprint "BS" my_id "REENVIOU (Actuator):" msg
            else
                if (tipo == "CONFIG")
                    send msg BS_PREV_ID
                    cprint "BS" my_id "REENVIOU DOWNLINK (Config):" msg
                else
                    cprint "Recebida msg desconhecida:" msg
                end
            end
        end
    end