atpl 150
atget id my_id

set C1_HOP_REVERSO 27 
set C2_ID 33         

set timer_segundos 0
set cmd_enviado 0
set frame "CONFIG"

cprint "GATEWAY COMPLETO INICIADO. A gravar logs..."

// Cabeçalho no ficheiro
time t_start
printfile "--- NOVA SIMULACAO INICIADA EM" t_start "---"

loop
    receive msg 1000
    
    if (msg != "")
        time t_rececao
        vdata v msg
        vget tipo v 1
        
        // ==========================================
        // TIPO: PARK
        // ==========================================
        if (tipo == "PARK")
            vget sensor_id v 2
            vget status v 4
            
            cprint "------------------------------------------------"
            if (status == 1)
                cprint t_rececao "| P | ESTADO LUGAR" sensor_id ": [XXX] OCUPADO"
                printfile t_rececao "PARK" sensor_id "OCUPADO"
            else
                cprint t_rececao "| P | ESTADO LUGAR" sensor_id ": [   ] LIVRE"
                printfile t_rececao "PARK" sensor_id "LIVRE"
            end
            cprint "------------------------------------------------"
        else
            // ==========================================
            // TIPO: DATA (Ambiente)
            // ==========================================
            if (tipo == "DATA")
                vget id_sensor v 2
                vget temp v 4
                vget hum v 5
                vget co2 v 6
                vget pm10 v 7
                
                cprint "================================================"
                cprint t_rececao " | A | DADOS AMBIENTAIS (Sensor" id_sensor ")"
                cprint "    > Temp: " temp " C   | Hum: " hum " %"
                cprint "    > CO2:  " co2 " ppm | PM10: " pm10
                cprint "================================================"
                
                printfile t_rececao "DATA" id_sensor temp hum co2 pm10
            else
                // ==========================================
                // TIPO: ACTUATOR (Novo)
                // ==========================================
                if (tipo == "ACTUATOR")
                    vget origin_id v 2
                    vget device_type v 3
                    vget status v 4
                    
                    cprint "------------------------------------------------"
                    if (status == 1)
                        cprint t_rececao "| ACTUATOR |" device_type "ON (Origem:" origin_id ")"
                        printfile t_rececao "ACTUATOR" origin_id device_type "ON"
                    else
                        cprint t_rececao "| ACTUATOR |" device_type "OFF (Origem:" origin_id ")"
                        printfile t_rececao "ACTUATOR" origin_id device_type "OFF"
                    end
                    cprint "------------------------------------------------"
                else
                    cprint t_rececao "Msg desconhecida:" msg
                end
            end
        end
    end
    
    // --- DOWNLINK (Enviar Configuração a cada 60s) ---
    inc timer_segundos
    if ((timer_segundos > 60) && (cmd_enviado == 0))
        set cmd_enviado 1 
        time timestamp
        data p_config timestamp frame my_id 15000
        
        send p_config C1_HOP_REVERSO
        send p_config C2_ID

        cprint ">> GATEWAY ENVIOU DOWNLINK (CONFIG)"
        printfile timestamp "DOWNLINK" "CONFIG" "ENVIADO"
    end