atget id my_id

set GW_ID 30

atpl 150

loop
    
    receive msg
    
    vdata v msg
    vget tipo v 1
    
    if (tipo == "PARK")
        
        send msg GW_ID
        
        cprint "BS" my_id "REENVIOU (Park):" msg
        
    end
