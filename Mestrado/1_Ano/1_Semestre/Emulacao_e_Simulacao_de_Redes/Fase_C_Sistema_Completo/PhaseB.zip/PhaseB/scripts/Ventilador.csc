atpl 30
mark 0 

loop
    
    receive cmd
    
    if (cmd == "VENT_ON")
        mark 1 
        print "Recebido: VENT_ON"
    else
        if (cmd == "VENT_OFF")
            mark 0 
            print "Recebido: VENT_OFF"
        end
    end

