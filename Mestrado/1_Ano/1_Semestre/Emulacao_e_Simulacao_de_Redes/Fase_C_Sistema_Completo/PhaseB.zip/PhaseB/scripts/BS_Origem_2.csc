atget id my_id
set ROUTER_BS_ID 28 
atpl 150

loop
    receive msg
    
    vdata v msg
    vget tipo v 1

    if (tipo == "PARK")
        
        send msg ROUTER_BS_ID

        cprint "BS" my_id "REENVIOU (Park):" msg
        
    end