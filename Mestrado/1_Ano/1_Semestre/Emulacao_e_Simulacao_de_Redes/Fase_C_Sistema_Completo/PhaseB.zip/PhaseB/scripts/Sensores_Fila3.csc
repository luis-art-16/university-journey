set frame "PARK"
set BS_ID 26
set GW_ID 30
atpl 20
atget id my_id
set status 0
set timestamp 0
mark 0 
cprint "Sensor Parking" my_id "iniciado. Reporta para BS" BS_ID

loop
    dreadsensor s
    mark s
    
    if (s != status)
        set status s
        time timestamp

        data p timestamp frame my_id GW_ID s

        randb backoff 0 250
        
        delay backoff

        send p BS_ID
        
        cprint "Sensor" my_id "ENVIOU (Park):" p
        
    end
    
    delay 1000