#!/usr/bin/env python3
import time
import json
from pysnmp.hlapi import *

class TrafficMonitor:
    """Cliente simples para monitorizar o sistema de tráfego."""
    
    def __init__(self, host='127.0.0.1', community='public'):
        self.host = host
        self.community = community
    
    def snmp_get(self, oid):
        """Faz um pedido SNMP GET."""
        error_indication, error_status, error_index, var_binds = next(
            getCmd(SnmpEngine(),
                   CommunityData(self.community),
                   UdpTransportTarget((self.host, 161)),
                   ContextData(),
                   ObjectType(ObjectIdentity(oid)))
        )
        
        if error_indication:
            print(f"Error: {error_indication}")
            return None
        elif error_status:
            print(f"Error: {error_status.prettyPrint()}")
            return None
        else:
            for var_bind in var_binds:
                return var_bind[1]
        return None
    
    def monitor_continuously(self, interval=5):
        """Monitoriza o sistema continuamente."""
        print(f"Starting traffic monitoring (updates every {interval}s)")
        print("Press Ctrl+C to stop monitoring\n")
        
        try:
            while True:
                self.display_status()
                time.sleep(interval)
        except KeyboardInterrupt:
            print("\nMonitoring stopped.")
    
    def display_status(self):
        """Mostra o estado atual do sistema."""
        print(f"\n--- Traffic System Status - {time.strftime('%H:%M:%S')} ---")
        # Aqui iriamos fazer SNMP GET para obter os valores reais
        # Por agora, mostra informação estática
        print("Flow 1 - Entrada_Norte: 15 vehicles, GREEN (25s remaining)")
        print("Flow 2 - Rua_Principal: 32 vehicles, RED (18s remaining)")  
        print("Flow 3 - Saida_Sul: 8 vehicles, YELLOW (3s remaining)")

if __name__ == '__main__':
    monitor = TrafficMonitor()
    monitor.monitor_continuously()
