#!/usr/bin/env python3
import threading
import time
import json
from pysnmp.entity import engine, config
from pysnmp.entity.rfc3413 import cmdrsp, context
from pysnmp.carrier.asyncore.dgram import udp
from pysnmp.smi import builder, instrum, view
from pysnmp.proto import rfc1902

class TrafficFlow:
    """Classe que representa uma via de tráfego."""
    def __init__(self, index, flow_id, capacity, traffic_gen_rate, initial_vehicles=0):
        self.index = index
        self.flow_id = flow_id
        self.current_vehicle_count = initial_vehicles
        self.max_capacity = capacity
        self.traffic_gen_rate = traffic_gen_rate
        self.current_signal_state = 3  # red(3)
        self.signal_time_remaining = 0
        self.green_duration = 30
        self.red_duration = 30
        self.destinations = []  # [(dest_flow_index, cross_rate), ...]

    def add_vehicles(self, count):
        """Adiciona veículos, sem exceder a capacidade."""
        self.current_vehicle_count = min(self.max_capacity, self.current_vehicle_count + count)

    def remove_vehicles(self, count):
        """Remove veículos, sem ficar negativo."""
        self.current_vehicle_count = max(0, self.current_vehicle_count - count)

class TrafficManagementSystem:
    """Sistema principal de gestão de tráfego."""
    
    def __init__(self, config_file):
        self.flows = {}
        self.snmp_engine = engine.SnmpEngine()
        self.load_configuration(config_file)
        self.setup_snmp_agent()
        self.running = False
        self.simulation_thread = None
        self.simulation_step_seconds = 5
        self.yellow_duration = 5

    def load_configuration(self, config_file):
        """Carrega a configuração do ficheiro JSON."""
        try:
            with open(config_file, 'r') as f:
                config = json.load(f)
            
            self.simulation_step_seconds = config.get('simulation_step_seconds', 5)
            self.yellow_duration = config.get('yellow_duration', 5)
            
            # Criar flows a partir da configuração
            for flow_config in config['flows']:
                flow = TrafficFlow(
                    index=flow_config['index'],
                    flow_id=flow_config['id'],
                    capacity=flow_config['capacity'],
                    traffic_gen_rate=flow_config['traffic_gen_rate'],
                    initial_vehicles=flow_config.get('initial_vehicles', 0)
                )
                flow.green_duration = flow_config.get('green_duration', 30)
                flow.red_duration = flow_config.get('red_duration', 30)
                
                # Configurar destinos
                for dest in flow_config.get('destinations', []):
                    flow.destinations.append((dest['index'], dest['cross_rate']))
                
                self.flows[flow.index] = flow
            
            print(f"Loaded configuration: {len(self.flows)} traffic flows")
            
        except Exception as e:
            print(f"Error loading configuration: {e}")
            # Configuração de fallback
            self._create_fallback_config()

    def _create_fallback_config(self):
        """Cria uma configuração básica se o ficheiro não existir."""
        print("Creating fallback configuration...")
        flow1 = TrafficFlow(1, "Entrada_Norte", 50, 5, 10)
        flow2 = TrafficFlow(2, "Rua_Principal", 100, 0, 25)
        flow3 = TrafficFlow(3, "Saida_Sul", 30, 0, 5)
        
        flow1.destinations = [(2, 20)]
        flow2.destinations = [(3, 15)]
        
        self.flows = {1: flow1, 2: flow2, 3: flow3}

    def setup_snmp_agent(self):
        """Configura o agente SNMP básico."""
        try:
            # Configurar transporte UDP na porta 161
            config.addTransport(
                self.snmp_engine,
                udp.domainName + (1,),
                udp.UdpTransport().openServerMode(('127.0.0.1', 161))
            )

            # Configurar comunidade SNMPv2c
            config.addV1System(self.snmp_engine, 'read-write', 'public')
            
            # Obter o MIB builder
            mib_builder = self.snmp_engine.getMibBuilder()
            
            # Carregar MIBs SNMP padrão
            mib_builder.loadModules('SNMPv2-MIB')
            
            print("SNMP Agent configured on UDP:127.0.0.1:161")
            print("Community: 'public'")
            
        except Exception as e:
            print(f"Error setting up SNMP agent: {e}")

    def start_simulation(self):
        """Inicia a simulação de tráfego."""
        self.running = True
        self.simulation_thread = threading.Thread(target=self._simulation_loop)
        self.simulation_thread.daemon = True
        self.simulation_thread.start()
        print("Traffic simulation started.")

    def _simulation_loop(self):
        """Loop principal da simulação."""
        step = 0
        while self.running:
            step += 1
            time.sleep(1)  # 1 segundo real entre passos
            
            print(f"\n--- Simulation Step {step} ---")
            
            # 1. Atualizar semáforos
            self._update_traffic_lights()
            
            # 2. Processar movimentos de veículos
            self._process_vehicle_movement()
            
            # 3. Gerar novo tráfego
            self._generate_new_traffic()
            
            # 4. Executar sistema de decisão periodicamente
            if step % 12 == 0:  # A cada ~1 minuto (12 * 5s)
                self._run_decision_system()

    def _update_traffic_lights(self):
        """Atualiza o estado dos semáforos."""
        for flow in self.flows.values():
            flow.signal_time_remaining -= self.simulation_step_seconds
            
            if flow.signal_time_remaining <= 0:
                if flow.current_signal_state == 1:  # green -> yellow
                    flow.current_signal_state = 2
                    flow.signal_time_remaining = self.yellow_duration
                    print(f"  {flow.flow_id}: GREEN -> YELLOW ({self.yellow_duration}s)")
                elif flow.current_signal_state == 2:  # yellow -> red
                    flow.current_signal_state = 3
                    flow.signal_time_remaining = flow.red_duration
                    print(f"  {flow.flow_id}: YELLOW -> RED ({flow.red_duration}s)")
                else:  # red -> green
                    flow.current_signal_state = 1
                    flow.signal_time_remaining = flow.green_duration
                    print(f"  {flow.flow_id}: RED -> GREEN ({flow.green_duration}s)")

    def _process_vehicle_movement(self):
        """Processa o movimento de veículos entre vias."""
        for flow in self.flows.values():
            if flow.current_signal_state in (1, 2):  # Verde ou Amarelo
                total_moved = 0
                for dest_index, cross_rate in flow.destinations:
                    if flow.current_vehicle_count == 0:
                        break
                        
                    dest_flow = self.flows.get(dest_index)
                    if dest_flow and dest_flow.current_vehicle_count < dest_flow.max_capacity:
                        # Calcular veículos a mover
                        vehicles_to_move = min(
                            (cross_rate * self.simulation_step_seconds) // 60,
                            flow.current_vehicle_count,
                            dest_flow.max_capacity - dest_flow.current_vehicle_count
                        )
                        
                        if vehicles_to_move > 0:
                            flow.remove_vehicles(vehicles_to_move)
                            dest_flow.add_vehicles(vehicles_to_move)
                            total_moved += vehicles_to_move
                
                if total_moved > 0:
                    print(f"  {flow.flow_id}: moved {total_moved} vehicles")

    def _generate_new_traffic(self):
        """Gera novo tráfego nas vias de entrada."""
        for flow in self.flows.values():
            if flow.traffic_gen_rate > 0:
                new_vehicles = (flow.traffic_gen_rate * self.simulation_step_seconds) // 60
                if new_vehicles > 0:
                    flow.add_vehicles(new_vehicles)
                    print(f"  {flow.flow_id}: generated {new_vehicles} vehicles (now: {flow.current_vehicle_count})")

    def _run_decision_system(self):
        """Sistema de decisão para ajustar tempos dos semáforos."""
        print(">>> Decision System running...")
        for flow in self.flows.values():
            # Algoritmo simples: tempo verde proporcional ao número de veículos
            base_time = 20
            factor = 0.5  # 0.5 segundos por veículo
            new_green = base_time + int(flow.current_vehicle_count * factor)
            new_green = max(10, min(new_green, 60))  # Limitar entre 10-60 segundos
            
            if new_green != flow.green_duration:
                flow.green_duration = new_green
                print(f"  {flow.flow_id}: new green time = {new_green}s (vehicles: {flow.current_vehicle_count})")

    def get_system_status(self):
        """Retorna o estado atual do sistema para monitorização."""
        status = {}
        for index, flow in self.flows.items():
            status[index] = {
                'id': flow.flow_id,
                'vehicles': flow.current_vehicle_count,
                'signal': {1: 'GREEN', 2: 'YELLOW', 3: 'RED'}[flow.current_signal_state],
                'time_remaining': flow.signal_time_remaining,
                'capacity': f"{flow.current_vehicle_count}/{flow.max_capacity}"
            }
        return status

    def run(self):
        """Inicia o sistema."""
        self.start_simulation()
        print("\n=== Traffic Management System Started ===")
        print("Press Ctrl+C to stop the system")
        
        try:
            # Manter o programa principal em execução
            while self.running:
                time.sleep(1)
        except KeyboardInterrupt:
            self.shutdown()

    def shutdown(self):
        """Para o sistema graciosamente."""
        print("\nShutting down system...")
        self.running = False
        if self.simulation_thread:
            self.simulation_thread.join(timeout=5)
        print("System stopped.")

if __name__ == '__main__':
    system = TrafficManagementSystem('src/config.json')
    system.run()
