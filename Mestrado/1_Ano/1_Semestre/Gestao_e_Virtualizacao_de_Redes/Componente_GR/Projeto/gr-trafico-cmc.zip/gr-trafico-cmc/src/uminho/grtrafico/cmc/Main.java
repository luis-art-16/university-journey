package uminho.grtrafico.cmc;

// --- IMPORTS ---
import org.snmp4j.CommunityTarget;
import org.snmp4j.PDU;
import org.snmp4j.Snmp;
import org.snmp4j.TransportMapping;
import org.snmp4j.event.ResponseEvent;
import org.snmp4j.mp.SnmpConstants;
import org.snmp4j.smi.*;
import org.snmp4j.transport.DefaultUdpTransportMapping;
import org.snmp4j.util.TableUtils;
import org.snmp4j.util.TableEvent;
import org.snmp4j.util.DefaultPDUFactory;

import java.io.IOException;
import java.util.List;
import java.util.Scanner;

/**
 * CMC - Consola de Monitorização e Controlo.
 * Esta aplicação funciona como um Gestor SNMP (Cliente).
 * Liga-se ao Agente (Sistema Central) para ler dados (Monitorização)
 * e enviar comandos (Configuração de RGT e Semáforos).
 */
public class Main {

    // Objeto principal da sessão SNMP
    private Snmp snmp;
    // Define "quem" é o nosso alvo (o Agente)
    private CommunityTarget<Address> target;

    // --- DEFINIÇÃO DE OIDs (Object Identifiers) ---
    // Estes OIDs devem corresponder exatamente ao que está na MIB.

    // OID base da tabela de vias
    public static final OID OID_VIA_TABLE = new OID("1.3.6.1.3.2025.1.1.1");

    // Colunas da tabela que queremos ler
    public static final OID OID_VIA_NAME = new OID("1.3.6.1.3.2025.1.1.1.2");
    public static final OID OID_VIA_VEHICLES = new OID("1.3.6.1.3.2025.1.1.1.3");
    public static final OID OID_VIA_LIGHT = new OID("1.3.6.1.3.2025.1.1.1.4");
    public static final OID OID_VIA_RGT = new OID("1.3.6.1.3.2025.1.1.1.6");
    public static final OID OID_VIA_IS_EXIT = new OID("1.3.6.1.3.2025.1.1.1.7");

    // Objeto Escalar para Controlo Manual (viaControlRequest.0)
    // O ".0" no fim indica que é uma instância escalar única
    public static final OID OID_CONTROL_REQUEST = new OID("1.3.6.1.3.2025.1.3.0");

    /**
     * Inicia a sessão SNMP e configura o transporte.
     * @throws IOException Se a porta estiver ocupada.
     */
    public void start() throws IOException {
        // 1. Criar o transporte UDP
        // Não especificamos porta, o SO atribui uma porta aleatória livre para o cliente.
        TransportMapping<?> transport = new DefaultUdpTransportMapping();
        this.snmp = new Snmp(transport);
        transport.listen();

        // 2. Configurar o "Alvo" (Target) - O nosso Agente
        this.target = new CommunityTarget<>();
        target.setCommunity(new OctetString("gr2025")); // A "password" (Community String)
        target.setAddress(new UdpAddress("127.0.0.1/16102")); // IP e Porta do Agente
        target.setVersion(SnmpConstants.version2c); // Versão do protocolo
        target.setRetries(2); // Tentar 2 vezes se falhar
        target.setTimeout(1500); // Esperar 1.5s pela resposta
    }

    /**
     * Fecha a sessão SNMP e liberta a porta de rede.
     */
    public void stop() throws IOException {
        if (this.snmp != null) {
            this.snmp.close();
        }
    }

    /**
     * O Loop Principal do Menu da Consola.
     */
    public void runMenu() {
        Scanner scanner = new Scanner(System.in);
        boolean running = true;

        while (running) {
            System.out.println("\n--- Consola de Gestão de Tráfego (CMC) ---");
            System.out.println("1. Monitorizar Vias (Snapshot único)");
            System.out.println("2. Alterar RGT de uma Via (snmpset)");
            System.out.println("3. Controlo Manual de Semáforo (Forçar Verde)");
            System.out.println("4. Monitorizar Vias (Modo Contínuo / Live)");
            System.out.println("9. Sair");
            System.out.print("Escolha uma opção: ");

            try {
                String input = scanner.nextLine();
                // Previne erro se o user der Enter sem escrever nada
                if (input.isEmpty()) continue;

                int option = Integer.parseInt(input);
                switch (option) {
                    case 1:
                        monitorVias(); // Mostra a tabela uma vez
                        break;
                    case 2:
                        promptChangeRGT(scanner); // Pede dados e altera RGT
                        break;
                    case 3:
                        promptManualOverride(scanner); // Pede dados e força semáforo
                        break;
                    case 4:
                        promptContinuousMonitor(scanner); // Entra em loop de monitorização
                        break;
                    case 9:
                        running = false;
                        break;
                    default:
                        System.out.println("Opção inválida.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Por favor, insira um número válido.");
            } catch (Exception e) {
                System.err.println("Erro inesperado: " + e.getMessage());
                e.printStackTrace();
            }
        }
    }

    /**
     * Realiza um SNMP Walk na tabela de Vias e imprime os resultados.
     * Inclui um Dashboard com estatísticas globais (Total na estrada vs Total Saído).
     */
    public void monitorVias() {
        // Definir as colunas que queremos obter do Agente
        OID[] columns = new OID[]{
                OID_VIA_NAME,
                OID_VIA_VEHICLES,
                OID_VIA_LIGHT,
                OID_VIA_RGT,
                OID_VIA_IS_EXIT
        };

        // Usar a classe utilitária TableUtils para facilitar o GET de tabelas inteiras
        TableUtils tableUtils = new TableUtils(snmp, new DefaultPDUFactory());

        // Obter a tabela (o método getTable trata dos pedidos GETNEXT automaticamente)
        List<TableEvent> events = tableUtils.getTable(target, columns, null, null);

        // --- CÁLCULO DE ESTATÍSTICAS GLOBAIS ---
        int totalOnRoad = 0;
        int totalExited = 0;

        for (TableEvent event : events) {
            if (event == null || event.isError() || event.getColumns() == null) continue;

            // Coluna 1 = Veículos, Coluna 4 = É Saída
            int veiculos = (event.getColumns()[1] != null) ? event.getColumns()[1].getVariable().toInt() : 0;
            int isExit = (event.getColumns()[4] != null) ? event.getColumns()[4].getVariable().toInt() : 2;

            if (isExit == 1) totalExited += veiculos; // Se é saída, conta como escoado
            else totalOnRoad += veiculos;             // Se é entrada/estrada, conta como ativo
        }

        System.out.println("\n--- DASHBOARD GLOBAL ---");
        System.out.println("Carros em circulação/fila: " + totalOnRoad);
        System.out.println("Total de carros escoados:  " + totalExited);
        System.out.println("------------------------");

        // --- IMPRESSÃO DA TABELA ---
        System.out.println(String.format("%-4s | %-16s | %-10s | %-10s | %-5s | %-6s",
                "IDX", "Nome", "Veículos", "Luz", "RGT", "É Saída"));
        System.out.println("-----+------------------+------------+------------+-------+--------");

        for (TableEvent event : events) {
            if (event.isError()) {
                System.err.println("Erro na leitura da linha: " + event.getErrorMessage());
                continue;
            }

            VariableBinding[] varBindings = event.getColumns();
            if (varBindings == null) continue;

            // O índice da linha é o último número do OID (ex: ...1.1.1.2.99 -> índice 99)
            int rowIndex = event.getIndex().last();

            // Extrair valores (tratamento de nulos com "???")
            String name = (varBindings[0] != null) ? varBindings[0].getVariable().toString() : "???";
            String vehicles = (varBindings[1] != null) ? varBindings[1].getVariable().toString() : "0";
            String light = (varBindings[2] != null) ? formatLight(varBindings[2].getVariable()) : "DESC.";
            String rgt = (varBindings[3] != null) ? varBindings[3].getVariable().toString() : "0";
            String isExit = (varBindings[4] != null) ? formatExit(varBindings[4].getVariable()) : "???";

            System.out.println(String.format("%-4d | %-16s | %-10s | %-10s | %-5s | %-6s",
                    rowIndex, name, vehicles, light, rgt, isExit));
        }
    }

    /**
     * Modo Contínuo: Limpa o ecrã e pede a tabela a cada X segundos.
     */
    private void promptContinuousMonitor(Scanner scanner) {
        try {
            System.out.print("  Intervalo de atualização em segundos (ex: 2): ");
            int seconds = Integer.parseInt(scanner.nextLine());
            if (seconds < 1) seconds = 1;

            System.out.println("\n--- MODO LIVE (Intervalo: " + seconds + "s) ---");
            System.out.println(">>> Pressione Ctrl+C para parar o programa e sair <<<");

            while (true) {
                // "Limpar" consola imprimindo linhas vazias
                for(int i = 0; i < 50; i++) System.out.println();

                System.out.println("=== ATUALIZAÇÃO EM TEMPO REAL (" + seconds + "s) ===");
                monitorVias();

                Thread.sleep(seconds * 1000);
            }
        } catch (NumberFormatException e) {
            System.out.println("Número inválido.");
        } catch (InterruptedException e) {
            System.out.println("Monitorização interrompida.");
        }
    }

    /**
     * Interface para pedir dados e alterar o RGT.
     */
    private void promptChangeRGT(Scanner scanner) throws IOException {
        try {
            System.out.print("  Insira o índice da Via (ex: 1): ");
            int viaIndex = Integer.parseInt(scanner.nextLine());

            System.out.print("  Insira o novo valor RGT (veículos/min): ");
            int newRGT = Integer.parseInt(scanner.nextLine());

            changeRGT(viaIndex, newRGT);
            System.out.println("Sucesso! Pedido enviado para alterar RGT da Via " + viaIndex);

        } catch (NumberFormatException e) {
            System.out.println("Valor inválido.");
        }
    }

    /**
     * Interface para pedir dados e forçar sinal verde.
     */
    private void promptManualOverride(Scanner scanner) throws IOException {
        try {
            System.out.print("  Insira o índice da Via para forçar o VERDE (ex: 1): ");
            int viaIndex = Integer.parseInt(scanner.nextLine());

            sendManualRequest(viaIndex);
            System.out.println("Pedido enviado! O Agente (SD) irá processar a prioridade.");

        } catch (NumberFormatException e) {
            System.out.println("Número inválido.");
        }
    }

    /**
     * Envia um pacote SNMP SET para alterar o RGT.
     */
    public void changeRGT(int viaIndex, int newRGT) throws IOException {
        // Construir o OID específico da linha: Base + Índice
        OID rgtOid = new OID(OID_VIA_RGT);
        rgtOid.append(viaIndex);

        // Criar o PDU (Protocol Data Unit)
        PDU pdu = new PDU();
        pdu.add(new VariableBinding(rgtOid, new Integer32(newRGT)));
        pdu.setType(PDU.SET); // Importante: Tipo SET

        // Enviar e aguardar resposta
        ResponseEvent<?> event = snmp.set(pdu, target);

        // Validar erros
        PDU responsePDU = event.getResponse();
        if (responsePDU == null) {
            throw new IOException("Erro: O Agente não respondeu (Timeout).");
        } else if (responsePDU.getErrorStatus() != PDU.noError) {
            // Se tentarmos alterar uma via que não existe, o erro aparece aqui
            throw new IOException("Erro no SET: " + responsePDU.getErrorStatusText());
        }
    }

    /**
     * Envia um pacote SNMP SET para o objeto escalar de controlo manual.
     */
    public void sendManualRequest(int viaIndex) throws IOException {
        PDU pdu = new PDU();
        // OID Escalar já tem o .0 no fim
        pdu.add(new VariableBinding(OID_CONTROL_REQUEST, new Integer32(viaIndex)));
        pdu.setType(PDU.SET);

        ResponseEvent<?> event = snmp.set(pdu, target);
        PDU responsePDU = event.getResponse();

        if (responsePDU == null) {
            throw new IOException("Erro: Timeout.");
        } else if (responsePDU.getErrorStatus() != PDU.noError) {
            throw new IOException("Erro no SET: " + responsePDU.getErrorStatusText());
        }
    }

    // --- Helpers de Formatação ---

    private String formatLight(Variable lightVar) {
        int light = lightVar.toInt();
        switch (light) {
            case 1: return "VERDE";
            case 2: return "AMARELO";
            case 3: return "VERMELHO";
            default: return "DESC.";
        }
    }

    private String formatExit(Variable exitVar) {
        int exit = exitVar.toInt();
        // Na MIB: 1=True, 2=False
        return (exit == 1) ? "SIM" : "NÃO";
    }

    /**
     * Ponto de entrada da CMC.
     */
    public static void main(String[] args) {
        try {
            Main cmc = new Main();
            cmc.start();
            cmc.runMenu();
            cmc.stop();
        } catch (IOException e) {
            System.err.println("Erro fatal ao iniciar a CMC: " + e.getMessage());
            e.printStackTrace();
        }
    }
}