import java.net.Socket;

public class TesteConectividade {
    public static void main(String[] args) {
        try {
            System.out.println("🔍 A testar conexão para localhost:16102...");
            Socket socket = new Socket("localhost", 16102);
            System.out.println("✅ CONEXÃO BEM SUCEDIDA!");
            socket.close();
        } catch (Exception e) {
            System.out.println("❌ FALHA NA CONEXÃO: " + e.getMessage());
        }
    }
}