package uminho.grtrafico.cmc;

import org.snmp4j.*;
import org.snmp4j.smi.*;
import org.snmp4j.transport.*;
import org.snmp4j.mp.*;
import org.snmp4j.PDU;
import org.snmp4j.event.ResponseEvent;
import java.util.*;

/**
 * Cliente SNMP CORRIGIDO - com OIDs compatíveis com o Agente
 */
public class CMCClient {
    private Snmp snmp;
    private String agentAddress;

    // ⭐⭐ OIDs CORRIGIDOS - compatíveis com o Agente ⭐⭐
    private static final OID BASE_OID = new OID("1.3.6.1.3.1");
    private static final OID GR_TRAFEGO = new OID(BASE_OID).append(1);
    private static final OID VIA_TABLE_OID = new OID(GR_TRAFEGO).append(1);
    private static final OID VIA_ENTRY_OID = new OID(VIA_TABLE_OID).append(1);
    private static final OID VIA_CONTROL_REQUEST_OID = new OID("1.3.6.1.3.1.2.0");

    // ⭐⭐ CAMPOS CORRETOS - pela ordem que o Agente espera ⭐⭐
    private static final int VIA_INDEX = 1;
    private static final int VIA_ID = 2;
    private static final int VIA_DESCRICAO = 3;
    private static final int VEICULOS_NA_VIA = 4;
    private static final int COR_SEMAFORO = 5;
    private static final int TEMPO_VERDE = 6;
    private static final int TEMPO_VERMELHO = 7;
    private static final int RITMO_ENTRADA = 8;


    public CMCClient(String agentHost, int agentPort) {
        this.agentAddress = agentHost + "/" + agentPort;
    }

    public void start() {
        try {
            System.out.println("📡 CMC Client a iniciar...");
            System.out.println("🔗 A conectar ao Agente: " + agentAddress);

            // Configurar transporte UDP
            TransportMapping<?> transport = new DefaultUdpTransportMapping();
            snmp = new Snmp(transport);
            transport.listen();

            System.out.println("✅ CMC Client iniciado com sucesso");

        } catch (Exception e) {
            System.err.println("❌ Erro ao iniciar CMC: " + e.getMessage());
        }
    }

    /**
     * Constrói OID completo CORRETO para um campo específico de uma via
     */
    private OID getViaOID(int viaIndex, int campo) {
        return new OID("1.3.6.1.3.1.1.1").append(campo).append(viaIndex);
    }

    /**
     * Obtém um valor específico do agente via SNMP GET
     */
    public String getValue(OID oid) {
        try {
            System.out.println("🔍 GET: " + oid);

            PDU pdu = new PDU();
            pdu.add(new VariableBinding(oid));
            pdu.setType(PDU.GET);

            Target target = getTarget();
            ResponseEvent response = snmp.send(pdu, target);

            if (response == null) {
                System.out.println("❌ TIMEOUT - Sem resposta do agente");
                return "TIMEOUT";
            }

            PDU responsePDU = response.getResponse();
            if (responsePDU == null) {
                System.out.println("❌ NO_RESPONSE - PDU de resposta nula");
                return "NO_RESPONSE";
            }

            if (responsePDU.getErrorStatus() != PDU.noError) {
                String erro = "ERROR: " + responsePDU.getErrorStatusText();
                System.out.println("❌ " + erro);
                return erro;
            }

            if (responsePDU.size() > 0) {
                VariableBinding vb = responsePDU.get(0);
                Variable variable = vb.getVariable();

                if (variable instanceof Null) {
                    System.out.println("❌ NO_SUCH_OID - OID não existe");
                    return "NO_SUCH_OID";
                }

                String valor = variable.toString();
                System.out.println("✅ GET bem-sucedido: " + oid + " = " + valor);
                return valor;
            }

        } catch (Exception e) {
            System.err.println("💥 EXCEÇÃO no GET: " + e.getMessage());
        }

        return "ERRO";
    }

    /**
     * Define um valor no agente via SNMP SET
     */
    public boolean setValue(OID oid, Variable value) {
        try {
            System.out.println("🔧 SET: " + oid + " = " + value);

            PDU pdu = new PDU();
            pdu.add(new VariableBinding(oid, value));
            pdu.setType(PDU.SET);

            Target target = getTarget();
            ResponseEvent response = snmp.send(pdu, target);

            if (response == null || response.getResponse() == null) {
                System.err.println("❌ TIMEOUT no SET");
                return false;
            }

            PDU responsePDU = response.getResponse();
            boolean success = (responsePDU.getErrorStatus() == PDU.noError);

            if (success) {
                System.out.println("✅ SET bem-sucedido: " + oid + " = " + value);
            } else {
                System.out.println("❌ SET falhou: " + responsePDU.getErrorStatusText());
            }

            return success;

        } catch (Exception e) {
            System.err.println("💥 EXCEÇÃO no SET: " + e.getMessage());
            return false;
        }
    }

    public void monitorizarSistema() {
        System.out.println("\n" + "=".repeat(60));
        System.out.println("📊 CMC - MONITORIZAÇÃO DO SISTEMA DE TRÁFEGO (CRUZAMENTO)");
        System.out.println("=".repeat(60));
        System.out.println("🕐 " + new Date());
        System.out.println("🔗 Agente: " + agentAddress);

        // Teste de conectividade (mantém-se igual)
        System.out.println("\n🔍 Testando conectividade...");
        String teste = getValue(getViaOID(1, VEICULOS_NA_VIA));
        if (!teste.contains("ERRO") && !teste.contains("TIMEOUT") && !teste.contains("NO_SUCH")) {
            System.out.println("✅ Conectividade OK! A monitorizar...");
        } else {
            System.out.println("❌ FALHA NA CONEXÃO! Verifica o Agente na porta 16102.");
            return;
        }

        // --- VIAS DE ENTRADA (1-4) ---
        System.out.println("\n" + "🚦".repeat(15) + " VIAS DE ENTRADA " + "🚦".repeat(15));

        System.out.println("\n📍 Via 1 - Entrada Norte");
        monitorizarViaEntrada(1); // Usar um método auxiliar

        System.out.println("\n📍 Via 2 - Entrada Este");
        monitorizarViaEntrada(2);

        System.out.println("\n📍 Via 3 - Entrada Sul");
        monitorizarViaEntrada(3);

        System.out.println("\n📍 Via 4 - Entrada Oeste");
        monitorizarViaEntrada(4);

        // --- VIAS DE SAÍDA (5-8) ---
        System.out.println("\n" + "🚗".repeat(15) + " VIAS DE SAÍDA " + "🚗".repeat(15));

        System.out.println(monitorizarViaSaida(5, "Saida Norte"));
        System.out.println(monitorizarViaSaida(6, "Saida Este"));
        System.out.println(monitorizarViaSaida(7, "Saida Sul"));
        System.out.println(monitorizarViaSaida(8, "Saida Oeste"));

        System.out.println("=".repeat(60));
    }

    private void monitorizarViaEntrada(int viaIndex) {
        String veiculos = getValue(getViaOID(viaIndex, VEICULOS_NA_VIA));
        String semaforo = getCorSemaforo(viaIndex); // Método que já tinhas
        String rgt = getValue(getViaOID(viaIndex, RITMO_ENTRADA));
        String tempoVerde = getValue(getViaOID(viaIndex, TEMPO_VERDE));
        String tempoVermelho = getValue(getViaOID(viaIndex, TEMPO_VERMELHO));

        System.out.println("  🚗 Veículos: " + formatarValor(veiculos));
        System.out.println("  🚦 Semaforo: " + semaforo);
        System.out.println("  📈 RGT: " + formatarValor(rgt) + " v/min");
        System.out.println("  🟢 T. Verde: " + formatarValor(tempoVerde) + "s");
        System.out.println("  🔴 T. Vermelho: " + formatarValor(tempoVermelho) + "s");
    }


    private String monitorizarViaSaida(int viaIndex, String nomeVia) {
        String veiculos = getValue(getViaOID(viaIndex, VEICULOS_NA_VIA));

        // Vias de saída não têm semáforos, RGT ou tempos
        return String.format("  📍 %-12s: 🚗 %s veículos",
                nomeVia, formatarValor(veiculos));
    }


    /**
     * Formata valores para melhor legibilidade
     */
    private String formatarValor(String valor) {
        if (valor.contains("ERRO") || valor.contains("TIMEOUT") || valor.contains("NO_SUCH")) {
            return "❌ " + valor;
        }
        return valor;
    }

    /**
     * Obtém a cor do semáforo como texto formatado
     */
    private String getCorSemaforo(int viaIndex) {
        String cor = getValue(getViaOID(viaIndex, COR_SEMAFORO));
        if (cor.contains("ERRO") || cor.contains("TIMEOUT") || cor.contains("NO_SUCH")) {
            return "❓ ERRO";
        }
        return switch (cor) {
            case "1" -> "🟢 VERDE";
            case "2" -> "🟡 AMARELO";
            case "3" -> "🔴 VERMELHO";
            default -> "❓ DESCONHECIDO (" + cor + ")";
        };
    }

    /**
     * Altera o RGT (Ritmo Gerador de Tráfego) de uma via
     */
    public void alterarRGT(int viaIndex, int novoRGT) {
        if (novoRGT < 0 || novoRGT > 100) {
            System.out.println("❌ RGT deve estar entre 0 e 100 veículos/minuto");
            return;
        }

        // ⭐⭐ USA OID CORRETO ⭐⭐
        OID oid = getViaOID(viaIndex, RITMO_ENTRADA);
        boolean success = setValue(oid, new Integer32(novoRGT));

        if (success) {
            System.out.println("✅ RGT da Via " + viaIndex + " alterado para " + novoRGT + " veículos/minuto");
        } else {
            System.out.println("❌ Erro ao alterar RGT da Via " + viaIndex);
        }
    }

    /**
     * Altera a cor do semáforo de uma via
     */
    public void solicitarVerde(int viaIndex) {
        if (viaIndex < 1 || viaIndex > 4) { // Assumindo 4 vias max
            System.out.println("❌ Via inválida (1-4).");
            return;
        }

        System.out.println("⏳ A solicitar ao Agente para por a Via " + viaIndex + " a VERDE...");
        System.out.println("💡 O Agente irá gerir a transição (Amarelo -> Vermelho -> Verde).");

        // Enviamos um SET para o OID de COMANDO
        boolean success = setValue(VIA_CONTROL_REQUEST_OID, new Integer32(viaIndex));

        if (success) {
            System.out.println("✅ Pedido enviado. O Agente irá processar.");
        } else {
            System.out.println("❌ Erro ao enviar pedido de controlo.");
        }
    }

    /**
     * Altera o tempo verde de uma via
     */
    public void alterarTempoVerde(int viaIndex, int novoTempo) {
        if (novoTempo < 5 || novoTempo > 120) {
            System.out.println("❌ Tempo deve estar entre 5 e 120 segundos");
            return;
        }

        // ⭐⭐ USA OID CORRETO ⭐⭐
        OID oid = getViaOID(viaIndex, TEMPO_VERDE);
        boolean success = setValue(oid, new Integer32(novoTempo));

        if (success) {
            System.out.println("✅ Tempo Verde da Via " + viaIndex + " alterado para " + novoTempo + " segundos");
        } else {
            System.out.println("❌ Erro ao alterar tempo verde da Via " + viaIndex);
        }
    }

    /**
     * Altera o tempo vermelho de uma via
     */
    public void alterarTempoVermelho(int viaIndex, int novoTempo) {
        if (novoTempo < 5 || novoTempo > 120) {
            System.out.println("❌ Tempo deve estar entre 5 e 120 segundos");
            return;
        }

        // ⭐⭐ USA OID CORRETO ⭐⭐
        OID oid = getViaOID(viaIndex, TEMPO_VERMELHO);
        boolean success = setValue(oid, new Integer32(novoTempo));

        if (success) {
            System.out.println("✅ Tempo Vermelho da Via " + viaIndex + " alterado para " + novoTempo + " segundos");
        } else {
            System.out.println("❌ Erro ao alterar tempo vermelho da Via " + viaIndex);
        }
    }

    /**
     * Teste de diagnóstico - verifica OIDs específicos
     */
    public void diagnostico() {
        System.out.println("\n🔧 MODO DIAGNÓSTICO");
        System.out.println("====================");

        // Testar OIDs específicos
        OID[] oidsTeste = {
                getViaOID(1, VEICULOS_NA_VIA),
                getViaOID(1, COR_SEMAFORO),
                getViaOID(1, RITMO_ENTRADA),
                getViaOID(2, VEICULOS_NA_VIA),
                getViaOID(3, VEICULOS_NA_VIA)
        };

        for (OID oid : oidsTeste) {
            System.out.println("\n🧪 Testando: " + oid);
            String resultado = getValue(oid);
            System.out.println("📊 Resultado: " + resultado);
        }
    }

    /**
     * Configuração do target SNMP
     */
    private Target getTarget() {
        CommunityTarget target = new CommunityTarget();
        target.setCommunity(new OctetString("gr2025"));
        target.setAddress(new UdpAddress(agentAddress));
        target.setRetries(3);
        target.setTimeout(5000); // 5 segundos
        target.setVersion(SnmpConstants.version2c);
        return target;
    }

    public void stop() {
        try {
            if (snmp != null) {
                snmp.close();
            }
            System.out.println("🛑 CMC Client terminado");
        } catch (Exception e) {
            System.err.println("Erro ao parar CMC: " + e.getMessage());
        }
    }
}