/*
===============================================================================
MÓDULO: script.js (Controlador DOM / WebSockets Vanilla)
===============================================================================
Descrição:
    A máquina de estados para a versão de Frontend tradicional (sem React).
    Cria a socket persistente para comunicação bidirecional de mensagens 
    com o app_cliente.py local. Modifica diretamente os nós da árvore DOM 
    para refletir as mudanças de estado da rede (Downlink/Uplink).
===============================================================================
*/

const socket = new WebSocket('ws://localhost:8765');

// ==========================================
// 1. GESTÃO DA LIGAÇÃO FÍSICA E ESTADO GLOBAL
// ==========================================
socket.onopen = () => {
    document.getElementById('dot').className = "badge rounded-pill bg-success mt-2";
    document.getElementById('dot').innerText = "ONLINE";
    document.getElementById('status-link').innerText = "Sincronizado com MUX";
    addLog("Sincronização estabelecida. Protocolo pronto.");
};

socket.onclose = () => {
    document.getElementById('dot').className = "badge rounded-pill bg-danger mt-2";
    document.getElementById('dot').innerText = "● OFFLINE";
    document.getElementById('status-link').innerText = "Ligação ótica perdida";
    addLog("Erro: Conexão Li-Fi perdida.");
};

// ==========================================
// 2. DESMULTIPLEXAGEM DE RECEÇÃO (DOWNLINK)
// ==========================================
socket.onmessage = (event) => {
    const mensagem = event.data;
    
    // Filtro visual: omite updates massivos de bytes do terminal
    if (!mensagem.startsWith("PROG:")) {
        addLog(`[DOWNLINK] ${mensagem}`);
    }
    
    // Tratamento Modular consoante o Subtipo L7 inferido da string
    if (mensagem.startsWith("PAINEL:")) {
        const dadosTabela = mensagem.replace("PAINEL:", "");
        desenharTabelaVoos(dadosTabela);
    }
    else if (mensagem.startsWith("REQ:")) {
        tratarRespostaCheckin(mensagem);
    }
    else if (mensagem.startsWith("ERRO:")) {
        document.getElementById('aviso-downloads').style.display = 'none';
        alert("Erro reportado pelo Servidor: " + mensagem.split(":")[1]);
    }
    else if (mensagem.startsWith("FILELIST:")) {
        const lista = mensagem.replace("FILELIST:", "");
        desenharBotoesFicheiros(lista);
    }
};

// ==========================================
// 3. ENVIO DE PEDIDOS (UPLINK API)
// ==========================================
function pedirVoo() {
    const voo = document.getElementById('user-voo').value;
    if(!voo) return;
    
    document.getElementById('resultado-pesquisa').style.display = 'none';
    
    socket.send("VOO:" + voo);
    addLog(`[UPLINK] Pedido enviado: VOO:${voo}`);
}

function pedirFicheiro(nomeFicheiro) {
    document.getElementById('aviso-downloads').style.display = 'block';
    
    socket.send("FILE:" + nomeFicheiro);
    addLog(`[UPLINK] Pedido enviado: FILE:${nomeFicheiro}`);
}

// ==========================================
// 4. FUNÇÕES AUXILIARES DE MANIPULAÇÃO DOM (RENDERING)
// ==========================================
function addLog(txt) {
    const log = document.getElementById('monitor-l7');
    const time = new Date().toLocaleTimeString();
    log.innerHTML += `<span class="text-secondary">[${time}]</span> ${txt}<br>`;
    log.scrollTop = log.scrollHeight; // Auto-scroll
}

function pedirListaFicheiros() {
    document.getElementById('grelha-documentos').innerHTML = '<p class="text-secondary text-center w-100 mt-4">A sincronizar catálogo com o servidor...</p>';
    socket.send("GET_FILELIST");
    addLog(`[UPLINK] Pedido enviado: GET_FILELIST`);
}

function desenharBotoesFicheiros(listaStr) {
    const grelha = document.getElementById('grelha-documentos');
    
    if (listaStr === "VAZIO") {
        grelha.innerHTML = '<p class="text-warning text-center w-100 mt-4">Não existem ficheiros no servidor de momento.</p>';
        return;
    }

    const ficheiros = listaStr.split('|');
    grelha.innerHTML = ''; 

    ficheiros.forEach(nomeFicheiro => {
        grelha.innerHTML += `
            <div class="col-md-6">
                <div class="card-dark p-4 text-center">
                    <h4 class="mb-3 text-white">${nomeFicheiro}</h4>
                    <button onclick="pedirFicheiro('${nomeFicheiro}')" class="btn btn-outline-warning w-100">Descarregar</button>
                </div>
            </div>
        `;
    });
}

function fazerCheckin() {
    const voo = document.getElementById('user-voo').value;
    if(!voo) return;
    
    document.getElementById('resultado-pesquisa').style.display = 'none';
    socket.send("CHECKIN:" + voo);
    addLog(`[UPLINK] Pedido Check-in enviado: CHECKIN:${voo}`);
}

function tratarRespostaCheckin(mensagem) {
    const partes = mensagem.split("|");
    const estado = partes[1]; // Dicotomia: CHECKIN_OK ou CHECKIN_ERRO
    const voo = partes[2];
    const info = partes[3];   
    
    const cartao = document.getElementById('resultado-pesquisa');
    cartao.style.display = 'block';
    document.getElementById('res-voo').innerText = voo;
    
    cartao.classList.remove('border-warning', 'border-success', 'border-danger');
    
    if (estado === "CHECKIN_OK") {
        cartao.classList.add('border-success');
        document.getElementById('res-titulo').innerText = "CHECK-IN CONFIRMADO";
        document.getElementById('res-titulo').className = "text-success fw-bold";
        
        const dadosVoo = info.split(",");
        document.getElementById('res-destino').innerText = dadosVoo[0];
        document.getElementById('res-hora').innerText = dadosVoo[1];
        document.getElementById('res-estado').innerText = dadosVoo[2];
        document.getElementById('res-label-hora').style.display = 'inline'; 
    } else {
        cartao.classList.add('border-danger');
        document.getElementById('res-titulo').innerText = "CHECK-IN RECUSADO";
        document.getElementById('res-titulo').className = "text-danger fw-bold";
        
        document.getElementById('res-destino').innerText = info; 
        document.getElementById('res-estado').innerText = "NEGADO";
        document.getElementById('res-label-hora').style.display = 'none'; 
    }
}

function desenharTabelaVoos(linha) {
    const tbody = document.getElementById('painel-voos');
    const colunas = linha.split(",");
    
    if (colunas.length === 4) {
        let badgeClass = "bg-secondary";
        if (colunas[3] === "EMBARQUE") badgeClass = "bg-success";
        else if (colunas[3].includes("ATRASADO")) badgeClass = "bg-danger";
        
        // Append assíncrono (útil para streaming de voos iterativo)
        tbody.innerHTML += `
            <tr>
                <td class="fw-bold">${colunas[0]}</td>
                <td>${colunas[1]}</td>
                <td>${colunas[2]}</td>
                <td><span class="badge ${badgeClass}">${colunas[3]}</span></td>
            </tr>
        `;
    }
}