"""
===============================================================================
MÓDULO: constantes_l7.py
===============================================================================
Descrição:
    Dicionário de dados da Camada de Aplicação (Layer 7). 
    Centraliza todas as constantes e "magic numbers" do protocolo.
    A sua utilização garante coerência entre Servidor e Cliente e facilita 
    a manutenção (e.g., alterar tamanhos de pacote no futuro).

Principais Definições:
    - Otimização: Tamanhos máximos de payload e cabeçalho.
    - Diretórios: Estrutura lógica local.
    - Módulos L7 (Famílias): Voos (0x10), Ficheiros (0x20), Erros (0x30).
    - Subtipos: Identificam a ação/comando específico dentro de cada módulo.
===============================================================================
"""

# ==========================================
# OTIMIZAÇÃO DE REDE
# ==========================================
TAMANHO_MAX_PAYLOAD_L7 = 128

# ==========================================
# PASTAS DO SISTEMA
# ==========================================
PASTA_ENVIO = "disco_local/para_enviar"
PASTA_RECEBIDOS = "disco_local/recebidos"

# ==========================================
# FAMÍLIAS DE TIPOS (MÓDULOS)
# ==========================================
TIPO_VOO = 0x10
TIPO_FILE = 0x20
TIPO_ERRO = 0x30

# ==========================================
# SUBTIPOS - Módulo 0x10 (Informação de Voos)
# ==========================================
SUBTIPO_PAINEL_PEDIDO = 0x01    # Cliente pede todos os voos
SUBTIPO_PAINEL_RESPOSTA = 0x02  # Servidor envia a lista completa de voos
SUBTIPO_CHECKIN_PEDIDO = 0x03   # Cliente pede check-in
SUBTIPO_CHECKIN_RESPOSTA = 0x04 # Servidor confirma ou rejeita

# ==========================================
# SUBTIPOS - Módulo 0x20 (Ficheiros)
# ==========================================
SUBTIPO_FILE_PEDIDO = 0x01       # Download
SUBTIPO_FILE_ATRIBUTOS = 0x02    # Metadados (Nome, Tamanho, FlowID)
SUBTIPO_FILE_DADOS = 0x03        # Bloco de Bytes
SUBTIPO_FILE_FIM = 0x04          # Fim/Checksum
SUBTIPO_FILE_ABORT = 0x05        # Interrupção voluntária (Pausing)
SUBTIPO_FILE_LISTA_PEDIDO = 0x06 # Cliente pede catálogo
SUBTIPO_FILE_LISTA_RESPOSTA = 0x07 # Servidor devolve catálogo

# ==========================================
# SUBTIPOS - Módulo 0x30 (Erros)
# ==========================================
SUBTIPO_ERRO_NOT_FOUND = 0x01 # Ficheiro não existe / Falha I/O

# ==========================================
# CABEÇALHOS
# ==========================================
# Formato D: Tipo(1B) + Subtipo(1B) + FlowID(1B) + FragID(4B) = 7 Bytes
TAMANHO_CABECALHO_DADOS_L7 = 7