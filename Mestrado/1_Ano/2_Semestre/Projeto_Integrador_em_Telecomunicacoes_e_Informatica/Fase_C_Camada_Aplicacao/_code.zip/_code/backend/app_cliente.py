"""
===============================================================================
MÓDULO: app_cliente.py
===============================================================================
Descrição:
    Aplicação cliente do sistema de aeroporto. Atua como um gateway (ponte) 
    entre a interface de utilizador (Frontend Web) e a rede de comunicação 
    física/simulada (Camada 2).

Principais Funcionalidades / Serviços (API):
    - Servidor WebSocket (ws://localhost:8765): Recebe comandos do frontend 
      e envia atualizações em tempo real (barras de progresso, mensagens).
    - Tradução de Protocolo: Converte pedidos em texto do WebSocket para 
      PDUs binários da Camada 7 (Li-Fi / Série).
    - Gestão de Pedidos: Suporta Check-in de voos, requisição de catálogos 
      de ficheiros, pedidos de download de ficheiros (com continuição) e quadros 
      de partidas.
    - Threading: Executa a receção de rede e o loop assíncrono do WebSocket 
      em threads separadas para evitar bloqueios (non-blocking IO).
===============================================================================
"""

import sys
import os
# Adiciona a pasta raiz (PITI-FaseC) aos caminhos que o Python conhece
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import threading
import time
import asyncio
import websockets
import struct
from camada2.camada_ligacao_dados import CamadaDeLigacao
from backend.constantes_l7 import *
from backend.multiplexador_l7 import MultiplexadorL7

class ClienteAeroporto:
    def __init__(self, porta_com='COM6'):
        print("[CLIENTE] A inicializar o Cliente do Aeroporto...")
        self.camada2 = CamadaDeLigacao(porta_com= 'COM6')
        self.mux = MultiplexadorL7()
        self.a_correr = False

        self.contador_req_id = 1
        
        self.clientes_ws = set()
        self.loop_async = None

        # O MUX avisa a interface gráfica quando chega um Voo ou atualização
        self.mux.definir_callback_voo(self._notificar_interface)

    # ==========================================
    # LIGAÇÃO COM A INTERFACE GRÁFICA (WEBSOCKETS)
    # ==========================================
    def _notificar_interface(self, texto_voo):
        """ Callback do MUX: Injeta mensagens no loop assíncrono do WebSocket. """
        if self.loop_async and self.loop_async.is_running():
            asyncio.run_coroutine_threadsafe(self._broadcast_ws(texto_voo), self.loop_async)

    async def _broadcast_ws(self, mensagem):
        """ Dispara mensagens (broadcast) para todas as páginas web ligadas. """
        if self.clientes_ws:
            if not mensagem.startswith("PROG:"):
                print(f"[WEBSOCKET ] A atualizar ecrã: {mensagem}")
                
            await asyncio.gather(*(cliente.send(mensagem) for cliente in self.clientes_ws))

    async def _handler_websocket(self, websocket):
        """ Mantém a sessão WebSocket aberta e reage a comandos do utilizador. """
        print("\n[WEBSOCKET] Interface gráfica ligada!")
        self.clientes_ws.add(websocket)
        try:
            async for mensagem in websocket:
                print(f"[WEBSOCKET] O utilizador pediu: {mensagem}")
                self._processar_pedido_frontend(mensagem)
        finally:
            self.clientes_ws.remove(websocket)
            print("[WEBSOCKET] Interface gráfica desligada.")

    async def iniciar_servidor_ws(self):
        """ Inicializa o listener do WebSocket. """
        self.loop_async = asyncio.get_running_loop()
        print("[MAIN] Ponte WebSocket aberta em ws://localhost:8765...")
        async with websockets.serve(self._handler_websocket, "localhost", 8765):
            await asyncio.Future()

    # ==========================================
    # TRADUÇÃO DE PEDIDOS (Frontend -> Protocolo L7)
    # ==========================================
    def _processar_pedido_frontend(self, mensagem: str):
        """ Faz o parse da string do Frontend e empacota para L7. """
        
        if mensagem.startswith("CHECKIN:"):
            codigo_voo = mensagem.split(":")[1]
            dados_bytes = codigo_voo.encode('utf-8')
            
            req_id = self.contador_req_id
            self.contador_req_id = (self.contador_req_id % 255) + 1 
            
            pdu_pedido = struct.pack(f'!B B B {len(dados_bytes)}s', TIPO_VOO, SUBTIPO_CHECKIN_PEDIDO, req_id, dados_bytes)
            self.camada2.enviar_bloco_dados(payload=pdu_pedido, tipo=0x01)
            print(f"[CLIENTE] Pedido de Check-in (ReqID {req_id}) para '{codigo_voo}' enviado.")

        elif mensagem.startswith("FILE:"):
            nome_ficheiro = mensagem.split(":")[1]
            
            # Cálculo de retoma: verifica estado atual no disco local
            caminho_local = os.path.join(PASTA_RECEBIDOS, nome_ficheiro)
            frag_inicial = 0
            if os.path.exists(caminho_local):
                tamanho_local = os.path.getsize(caminho_local)
                frag_inicial = tamanho_local // 121 
            
            pedido_str = f"{nome_ficheiro}|{frag_inicial}" if frag_inicial > 0 else nome_ficheiro
            dados_bytes = pedido_str.encode('utf-8')
            
            pdu_pedido = struct.pack(f'!B B {len(dados_bytes)}s', TIPO_FILE, SUBTIPO_FILE_PEDIDO, dados_bytes)
            self.camada2.enviar_bloco_dados(payload=pdu_pedido, tipo=0x01)
            print(f"[CLIENTE] Pedido de '{pedido_str}' enviado.")
        
        elif mensagem.startswith("ABORT:"):
            nome_ficheiro = mensagem.split(":")[1]
            
            flow_id_alvo = None
            for fid, sessao in self.mux.sessoes_ativas.items():
                if sessao['nome'] == nome_ficheiro:
                    flow_id_alvo = fid
                    break
                    
            if flow_id_alvo is not None:
                pdu_abort = struct.pack('!B B B', TIPO_FILE, SUBTIPO_FILE_ABORT, flow_id_alvo)
                self.camada2.enviar_bloco_dados(payload=pdu_abort, tipo=0x01)
                
                # Pausa a transferência apagando a sessão, mas mantém o ficheiro local
                del self.mux.sessoes_ativas[flow_id_alvo]
                print(f"[CLIENTE] Transferência PAUSADA. Progresso mantido localmente (FlowID {flow_id_alvo}).")
        
        elif mensagem == "GET_FILELIST":
            pdu_pedido = struct.pack('!B B', TIPO_FILE, SUBTIPO_FILE_LISTA_PEDIDO)
            self.camada2.enviar_bloco_dados(payload=pdu_pedido, tipo=0x01)
            print("[CLIENTE] Pedido de catálogo de ficheiros enviado.") 

        elif mensagem == "GET_PAINEL":
            pdu_pedido = struct.pack('!B B B', TIPO_VOO, SUBTIPO_PAINEL_PEDIDO, 0)
            self.camada2.enviar_bloco_dados(payload=pdu_pedido, tipo=0x01)
            print("[CLIENTE] Pedido do Quadro Geral de Partidas enviado.")

    # ==========================================
    # LÓGICA DE REDE E ARRANQUE
    # ==========================================
    def _tarefa_da_rede(self):
        """ Worker thread para sondar constantemente a Camada 2 por novas tramas. """
        print("[REDE] Thread de Rede iniciada. À escuta no cabo...")
        
        self.camada2.definir_destino_dados(self.mux.processar_pdu)
        self.camada2.iniciar_ligacao()
        
        while self.a_correr:
            self.camada2.processar_trama_recebida()
            time.sleep(0.01) 
            
        self.camada2.fechar_ligacao()
        print("[REDE] Thread de Rede encerrada.")

    def iniciar(self):
        """ Bootstrapper da aplicação. Inicia threads e loops de eventos. """
        self.a_correr = True
        
        thread_rede = threading.Thread(target=self._tarefa_da_rede, daemon=True)
        thread_rede.start()
        
        try:
            asyncio.run(self.iniciar_servidor_ws())
        except KeyboardInterrupt:
            print("\n[MAIN] A desligar o cliente...")
            self.a_correr = False
            thread_rede.join()

if __name__ == "__main__":
    app = ClienteAeroporto(porta_com='COM3')
    app.iniciar()