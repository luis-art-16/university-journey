"""
===============================================================================
MÓDULO: app_servidor.py
===============================================================================
Descrição:
    Servidor central do sistema do aeroporto. Fornece dados ao cliente 
    através da Camada 2. Responsável por garantir integridade de dados e 
    partilha justa de largura de banda.

Principais Funcionalidades / Serviços (API):
    - Gestão de Check-ins: Valida voos contra uma base de dados local (`voos.json`), 
      impede check-ins duplicados e bloqueia operações em voos fechados/cancelados.
    - Transferência de Ficheiros (Round-Robin): Implementa escalonamento 
      Round-Robin para o envio simultâneo de múltiplos ficheiros, garantindo 
      que nenhum download bloqueia a rede.
    - Suporte a Retoma (Resumption): Aceita um offset/fragmento inicial para 
      continuar envios em pausa sem retransmitir dados redundantes.
    - QoS Baseado em Filas: Utiliza uma fila prioritária para respostas 
      pequenas (voos, metadados) e uma fila normal para dados pesados.
===============================================================================
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import time
import struct
import json
from camada2.camada_ligacao_dados import CamadaDeLigacao
from backend.constantes_l7 import *
from backend.multiplexador_l7 import MultiplexadorL7

class ServidorAeroporto:
    def __init__(self, porta_com='COM7'): 
        print("[SERVIDOR] A inicializar o Servidor do Aeroporto...")
        self.camada2 = CamadaDeLigacao(porta_com= 'COM7')
        self.mux = MultiplexadorL7()
        self.a_correr = False
        
        # Variáveis para gerir a Multiplexagem Round-Robin e QoS
        self.fila_transferencias = [] 
        self.fila_mensagens_prioritarias = []   
        self.flow_id_contador = 1     
        self.voos_com_checkin = set()

        # Registo de callbacks para desmultiplexagem de pedidos
        self.mux.definir_callback_pedido(self._tratar_pedido_ficheiro)
        self.mux.definir_callback_voo(self._tratar_pedido_voo)
        self.mux.definir_callback_lista(self._tratar_pedido_listas)
        self.mux.definir_callback_abort(self._tratar_abort_ficheiro)
        
    def _tratar_pedido_voo(self, pedido_bruto):
        """ Trata pedidos de check-in, validando dados e gerindo estado na RAM. """
        req_id = 0
        voo_pedido = pedido_bruto
        
        if pedido_bruto.startswith("REQ:"):
            partes = pedido_bruto.split("|")
            if len(partes) >= 2:
                req_id_str = partes[0].split(":")[1]
                req_id = int(req_id_str) if req_id_str.isdigit() else 0
                voo_pedido = partes[1].upper().strip()

        # Comando de reset (útil para testes/demonstrações)
        if voo_pedido == "RESET":
            self.voos_com_checkin.clear()
            print("[SERVIDOR] !!! SISTEMA DE CHECK-IN REINICIADO !!!")
            resposta_bytes = b"CHECKIN_ERRO|RESET|O sistema foi reiniciado. Pode testar novamente."
            pdu_voo = struct.pack(f'!B B B {len(resposta_bytes)}s', TIPO_VOO, SUBTIPO_CHECKIN_RESPOSTA, req_id, resposta_bytes)
            self.fila_mensagens_prioritarias.append(pdu_voo)
            return
        
        print(f"[SERVIDOR] Tentativa de Check-in (ReqID {req_id}) no voo: {voo_pedido}")
        
        caminho_json = os.path.join(os.path.dirname(__file__), 'voos.json')
        try:
            with open(caminho_json, 'r', encoding='utf-8') as f:
                base_dados = json.load(f)
        except Exception:
            base_dados = {} 
        
        # ==========================================================
        # LÓGICA DE CHECK-IN (Com Validação de Regras de Negócio)
        # ==========================================================
        if voo_pedido in base_dados:
            info_voo = base_dados[voo_pedido]
            
            # 1. Extrair o estado atual do voo (esperado no índice 2)
            partes_info = info_voo.replace(",", " - ").split(" - ")
            estado_voo = partes_info[2].strip().upper() if len(partes_info) >= 3 else ""

            # 2. Definir os estados que bloqueiam a emissão de cartão
            estados_proibidos = ["CANCELADO", "PORTA FECHADA", "EMBARQUE"]

            if estado_voo in estados_proibidos:
                # Rejeita o check-in com base no estado do voo
                resposta = f"CHECKIN_ERRO|{voo_pedido}|Operação recusada. O voo encontra-se: {estado_voo}."
                print(f"[SERVIDOR] Check-in negado (Regra de Negócio). Voo '{voo_pedido}' está {estado_voo}.")
                
            elif voo_pedido in self.voos_com_checkin:
                # Rejeita se já tiver feito check-in
                resposta = f"CHECKIN_ERRO|{voo_pedido}|Check-in ja foi efetuado para este voo."
                print(f"[SERVIDOR] Check-in recusado (Duplicado): {voo_pedido}")
                
            else:
                # Aprova o check-in
                self.voos_com_checkin.add(voo_pedido)
                resposta = f"CHECKIN_OK|{voo_pedido}|{info_voo}"
                print(f"[SERVIDOR] Check-in confirmado: {voo_pedido}")
                
        else:
            # O voo não existe
            resposta = f"CHECKIN_ERRO|{voo_pedido}|Voo nao encontrado no sistema."
            print(f"[SERVIDOR] Check-in negado. Voo '{voo_pedido}' invalido.")
        
        resposta_bytes = resposta.encode('utf-8')
        pdu_voo = struct.pack(f'!B B B {len(resposta_bytes)}s', TIPO_VOO, SUBTIPO_CHECKIN_RESPOSTA, req_id, resposta_bytes)
        
        # Envia diretamente para a fila prioritária (bypass ao envio de ficheiros)
        self.fila_mensagens_prioritarias.append(pdu_voo)

    def _tratar_pedido_ficheiro(self, pedido_bruto):
        """ Abre o ficheiro local, aplica lógica de offset (retoma) e regista no Round-Robin. """
        partes = pedido_bruto.split("|")
        nome_ficheiro = partes[0]
        frag_inicial = int(partes[1]) if len(partes) > 1 else 0

        pasta_raiz = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        caminho = os.path.join(pasta_raiz, PASTA_ENVIO, nome_ficheiro)
        
        if not os.path.exists(caminho):
            erro_msg = f"Ficheiro '{nome_ficheiro}' nao encontrado."
            erro_bytes = erro_msg.encode('utf-8')
            pdu_erro = struct.pack(f'!B B {len(erro_bytes)}s', TIPO_ERRO, SUBTIPO_ERRO_NOT_FOUND, erro_bytes)
            self.fila_mensagens_prioritarias.append(pdu_erro)
            print(f"[SERVIDOR] Pedido rejeitado: {erro_msg}")
            return

        tamanho = os.path.getsize(caminho)
        f = open(caminho, 'rb')
        
        if frag_inicial > 0:
            f.seek(frag_inicial * 121) # Aplica offset
            print(f"[SERVIDOR] A retomar envio de '{nome_ficheiro}' a partir do fragmento {frag_inicial}")

        nome_bytes = nome_ficheiro.encode('utf-8')
        pdu_atributos = struct.pack(f'!B B B I {len(nome_bytes)}s', 
                                    TIPO_FILE, 
                                    SUBTIPO_FILE_ATRIBUTOS, 
                                    self.flow_id_contador, 
                                    tamanho, 
                                    nome_bytes)
        
        self.fila_mensagens_prioritarias.append(pdu_atributos)

        sessao = {
            'flow_id': self.flow_id_contador,
            'nome': nome_ficheiro,
            'tamanho_total': tamanho,              
            'ficheiro_aberto': f,
            'num_fragmento': frag_inicial,         
            'bytes_enviados': frag_inicial * 121,  
            'total_fragmentos': (tamanho + 120) // 121
        }
        
        self.fila_transferencias.append(sessao)
        self.flow_id_contador = (self.flow_id_contador + 1) % 256
        
    def _tratar_abort_ficheiro(self, flow_id):
        """ Interrompe e limpa a sessão local de envio caso o cliente cancele/pause. """
        for i, sessao in enumerate(self.fila_transferencias):
            if sessao['flow_id'] == flow_id:
                sessao['ficheiro_aberto'].close()
                del self.fila_transferencias[i]
                print(f"[SERVIDOR] Transferência cancelada a pedido do cliente (FlowID {flow_id}).")
                break

    def _tratar_pedido_listas(self, alvo="FICHEIROS"):
        """ Responde a pedidos de catálogos (ficheiros ou painel de voos). """
        if alvo == "PAINEL":
            print("[SERVIDOR] A enviar Painel Geral de Voos (Streaming)...")
            caminho_json = os.path.join(os.path.dirname(__file__), 'voos.json')
            try:
                with open(caminho_json, 'r', encoding='utf-8') as f:
                    base_dados = json.load(f)
                    
                    if not base_dados:
                        raise ValueError("O ficheiro está vazio")
                    
                    for voo, info in base_dados.items():
                        info_formatada = info.replace(" - ", ",")
                        linha_voo = f"{voo},{info_formatada}"
                        
                        dados_bytes = linha_voo.encode('utf-8')
                        pdu_painel = struct.pack(f'!B B B {len(dados_bytes)}s', TIPO_VOO, SUBTIPO_PAINEL_RESPOSTA, 0, dados_bytes)
                        self.fila_mensagens_prioritarias.append(pdu_painel)
                        
            except Exception as e:
                print(f"[SERVIDOR] Erro ao ler voos ({e}). A enviar painel VAZIO.")
                dados_bytes = b"VAZIO"
                pdu_painel = struct.pack(f'!B B B {len(dados_bytes)}s', TIPO_VOO, SUBTIPO_PAINEL_RESPOSTA, 0, dados_bytes)
                self.fila_mensagens_prioritarias.append(pdu_painel)

        elif alvo == "FICHEIROS":
            print("[SERVIDOR] A gerar catálogo dinâmico de ficheiros...")
            ficheiros = []
            pasta_raiz = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            caminho_envio = os.path.join(pasta_raiz, PASTA_ENVIO)
            
            if os.path.exists(caminho_envio):
                for f in os.listdir(caminho_envio):
                    if os.path.isfile(os.path.join(caminho_envio, f)):
                        ficheiros.append(f)
            
            catalogo_str = "|".join(ficheiros)
            if not catalogo_str: catalogo_str = "VAZIO"
            
            dados_bytes = catalogo_str.encode('utf-8')
            pdu_lista = struct.pack(f'!B B {len(dados_bytes)}s', TIPO_FILE, SUBTIPO_FILE_LISTA_RESPOSTA, dados_bytes)
            self.fila_mensagens_prioritarias.append(pdu_lista)  

    def _processar_round_robin(self):
        """ 
        Escalonador Round-Robin.
        Processa apenas 1 bloco da primeira transferência e re-insere-a no fim da fila.
        Garante que vários downloads paralelos avançam de forma equitativa.
        """
        if not self.fila_transferencias:
            return 
            
        sessao = self.fila_transferencias.pop(0)
        f = sessao['ficheiro_aberto']
        
        bloco = f.read(TAMANHO_MAX_PAYLOAD_L7 - TAMANHO_CABECALHO_DADOS_L7) 
        
        if bloco:
            tamanho_bloco = len(bloco)
            pdu_dados = struct.pack(f'!B B B I {tamanho_bloco}s', TIPO_FILE, SUBTIPO_FILE_DADOS, sessao['flow_id'], sessao['num_fragmento'], bloco)
            self.camada2.enviar_bloco_dados(payload=pdu_dados, tipo=0x01)
            
            sessao['bytes_enviados'] += tamanho_bloco
            if sessao['num_fragmento'] % 10 == 0 or sessao['bytes_enviados'] == sessao['tamanho_total']:
                print(f"[SERVIDOR] RR FlowID {sessao['flow_id']} | Frag {sessao['num_fragmento']} | Progresso: {sessao['bytes_enviados']}/{sessao['tamanho_total']} bytes")
            
            sessao['num_fragmento'] += 1 
            self.fila_transferencias.append(sessao)
            
        else:
            total_fragmentos = sessao['num_fragmento']
            pdu_fim = struct.pack('!B B B I', TIPO_FILE, SUBTIPO_FILE_FIM, sessao['flow_id'], total_fragmentos)
            self.camada2.enviar_bloco_dados(payload=pdu_fim, tipo=0x01)
            
            print(f"[SERVIDOR] Envio de '{sessao['nome']}' concluído com {total_fragmentos} fragmentos!")
            f.close() 

    def iniciar(self):
        """ Main loop do servidor: Escuta L2 -> Processa VIP Queue -> Processa RR Queue """
        self.a_correr = True
        self.camada2.definir_destino_dados(self.mux.processar_pdu)
        self.camada2.iniciar_ligacao()
        
        print("\n" + "="*40)
        print("      SERVIDOR DE AEROPORTO ATIVO")
        print("="*40)
        print("[MAIN] À escuta de pedidos no canal físico...")
        
        try:
            while self.a_correr:    
                self.camada2.processar_trama_recebida()
                
                # Qualidade de Serviço (QoS): Prioridade máxima para pedidos simples
                if self.fila_mensagens_prioritarias:
                    pdu_resposta = self.fila_mensagens_prioritarias.pop(0)
                    self.camada2.enviar_bloco_dados(payload=pdu_resposta, tipo=0x01)
                else:
                    self._processar_round_robin()
                
                time.sleep(0.01) 
        except KeyboardInterrupt:
            print("\n[MAIN] A desligar o servidor...")
            self.a_correr = False
            self.camada2.fechar_ligacao()

if __name__ == "__main__":
    servidor = ServidorAeroporto(porta_com='COM3')
    servidor.iniciar()