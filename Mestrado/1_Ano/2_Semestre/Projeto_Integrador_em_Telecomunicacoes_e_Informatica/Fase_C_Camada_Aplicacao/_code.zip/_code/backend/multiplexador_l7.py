"""
===============================================================================
MÓDULO: multiplexador_l7.py
===============================================================================
Descrição:
    A máquina de estados e *parser* central do protocolo de Camada 7. 
    Recebe os blocos em bruto (bytes) entregues pela Camada 2, desmonta os 
    cabeçalhos e encaminha os dados para as lógicas certas (desmultiplexagem).

Principais Funcionalidades / Serviços (API):
    - Extrai Tipos, Subtipos e payloads usando `struct`.
    - Invoca funções registadas na aplicação base 
      (Servidor ou Cliente) dependendo do Tipo/Subtipo do PDU.
    -  Controla fluxos (FlowIDs) localmente, gerindo ficheiros abertos em modo 'append' binário.
    - Compara os fragmentos previstos nos atributos com o sinal de EOF. Se o ficheiro vier com erros, limpa-o da memória 
      e do disco.
===============================================================================
"""

import os
import struct
from backend.constantes_l7 import *

class MultiplexadorL7:
    def __init__(self):
        print("[MUX] Multiplexador da Camada 7 inicializado.")
        # Registos de Callbacks a serem implementados pela aplicação superior
        self.callback_voo = None  
        self.callback_pedido_ficheiro = None 
        self.callback_pedido_lista = None
        self.callback_abort = None
        
        # Estado local de transferências L7 ativas
        self.sessoes_ativas = {} 

    def definir_callback_voo(self, funcao):
        self.callback_voo = funcao

    def definir_callback_pedido(self, funcao):
        self.callback_pedido_ficheiro = funcao

    def definir_callback_lista(self, funcao):
        self.callback_pedido_lista = funcao
        
    def definir_callback_abort(self, funcao):
        self.callback_abort = funcao

    def _notificar_interface(self, mensagem):
        """ Proxy para injetar dados na lógica aplicacional / frontend. """
        if self.callback_voo:
            self.callback_voo(mensagem)

    def processar_pdu(self, pdu: bytes):
        """ Core da desmultiplexagem: Desempacota e encaminha PDUs de receção. """
        if not pdu or len(pdu) < 2:  
            return

        tipo = pdu[0]
        subtipo = pdu[1]

        # --- MÓDULO 0x10 (VOOS E CHECK-IN) ---
        if tipo == TIPO_VOO:
            req_id = pdu[2]
            
            if subtipo == SUBTIPO_CHECKIN_PEDIDO:
                texto = pdu[3:].decode('utf-8', errors='ignore')
                if self.callback_voo:
                    self.callback_voo(f"REQ:{req_id}|{texto}")
            
            elif subtipo == SUBTIPO_CHECKIN_RESPOSTA:
                texto = pdu[3:].decode('utf-8', errors='ignore')
                self._notificar_interface(f"REQ:{req_id}|{texto}")

            elif subtipo == SUBTIPO_PAINEL_PEDIDO:
                if self.callback_pedido_lista:
                    self.callback_pedido_lista("PAINEL")

            elif subtipo == SUBTIPO_PAINEL_RESPOSTA:
                texto = pdu[3:].decode('utf-8', errors='ignore')
                self._notificar_interface(f"PAINEL:{texto}")

        # --- MÓDULO 0x20 (FICHEIROS) ---
        elif tipo == TIPO_FILE:
            
            if subtipo == SUBTIPO_FILE_PEDIDO:
                nome_pedido = pdu[2:].decode('utf-8', errors='ignore')
                print(f"\n[MUX] Recebido pedido para descarregar: '{nome_pedido}'")
                if self.callback_pedido_ficheiro:
                    self.callback_pedido_ficheiro(nome_pedido)

            elif subtipo == SUBTIPO_FILE_ATRIBUTOS:
                if len(pdu) < 7: return
                flow_id = pdu[2]
                tamanho_ficheiro = struct.unpack('!I', pdu[3:7])[0]
                nome_ficheiro = pdu[7:].decode('utf-8', errors='ignore')
                
                pasta_destino = PASTA_RECEBIDOS
                os.makedirs(pasta_destino, exist_ok=True)
                caminho = os.path.join(pasta_destino, nome_ficheiro)
                
                # Preparação para Retoma de Ficheiros
                bytes_iniciais = os.path.getsize(caminho) if os.path.exists(caminho) else 0
                frag_iniciais = bytes_iniciais // 121
                
                if bytes_iniciais == 0:
                    with open(caminho, 'wb') as f: pass 
                
                self.sessoes_ativas[flow_id] = {
                    'nome': nome_ficheiro,
                    'caminho': caminho,
                    'tamanho_total': tamanho_ficheiro,
                    'bytes_recebidos': bytes_iniciais,
                    'fragmentos_recebidos': frag_iniciais
                }
                
                percentagem = int((bytes_iniciais / tamanho_ficheiro) * 100) if tamanho_ficheiro > 0 else 0
                print(f"\n[MUX] Sincronizado L7: '{nome_ficheiro}' começa aos {percentagem}% | FlowID: {flow_id}.")
                self._notificar_interface(f"PROG:{nome_ficheiro}|{percentagem}")

            elif subtipo == SUBTIPO_FILE_DADOS:
                if len(pdu) < TAMANHO_CABECALHO_DADOS_L7: return
                flow_id = pdu[2]
                
                if flow_id not in self.sessoes_ativas: return
                
                sessao = self.sessoes_ativas[flow_id]
                num_frag = struct.unpack('!I', pdu[3:7])[0]
                dados_binarios = pdu[7:]
                
                # I/O em modo binário aditivo (append)
                with open(sessao['caminho'], 'ab') as f:
                    f.write(dados_binarios)
                
                sessao['bytes_recebidos'] += len(dados_binarios)
                sessao['fragmentos_recebidos'] += 1
                
                percentagem = int((sessao['bytes_recebidos'] / sessao['tamanho_total']) * 100)
                self._notificar_interface(f"PROG:{sessao['nome']}|{percentagem}")
                
                if num_frag % 10 == 0:
                    print(f"[MUX] Escrito Frag {num_frag} de '{sessao['nome']}' ({percentagem}%)")

            elif subtipo == SUBTIPO_FILE_FIM:
                if len(pdu) < 7: return
                flow_id = pdu[2]
                total_esperado = struct.unpack('!I', pdu[3:7])[0]
                
                # Verificação Final e Garantia de Integridade
                if flow_id in self.sessoes_ativas:
                    sessao = self.sessoes_ativas[flow_id]
                    
                    if sessao['fragmentos_recebidos'] == total_esperado:
                        print(f"\n[MUX] Sucesso! Ficheiro '{sessao['nome']}' íntegro com {total_esperado} fragmentos.")
                        self._notificar_interface(f"PROG:{sessao['nome']}|100")
                    else:
                        print(f"\n[MUX] CORROMPIDO! '{sessao['nome']}' tem {sessao['fragmentos_recebidos']} de {total_esperado} blocos.")
                        self._notificar_interface(f"ERRO:O ficheiro {sessao['nome']} ficou corrompido na rede.")
                        os.remove(sessao['caminho']) 
                        
                    del self.sessoes_ativas[flow_id]

            elif subtipo == SUBTIPO_FILE_ABORT:
                if len(pdu) < 3: return
                flow_id = pdu[2]
                if self.callback_abort:
                    self.callback_abort(flow_id)
                # Mantém ficheiro físico para retoma futura, limpa apenas estado lógico
                if flow_id in self.sessoes_ativas:
                    del self.sessoes_ativas[flow_id]

            elif subtipo == SUBTIPO_FILE_LISTA_PEDIDO:
                if self.callback_pedido_lista:
                    self.callback_pedido_lista()

            elif subtipo == SUBTIPO_FILE_LISTA_RESPOSTA:
                texto_lista = pdu[2:].decode('utf-8', errors='ignore')
                print(f"\n[MUX] Catálogo recebido: {texto_lista}")
                self._notificar_interface(f"FILELIST:{texto_lista}")

        # --- MÓDULO 0x30 (ERROS) ---
        elif tipo == TIPO_ERRO:
            if subtipo == SUBTIPO_ERRO_NOT_FOUND:
                erro_msg = pdu[2:].decode('utf-8', errors='ignore')
                print(f"\n[MUX] ERRO DO SERVIDOR: {erro_msg}")
                self._notificar_interface(f"ERRO:{erro_msg}")

        else:
            print(f"\n[MUX] Tipo desconhecido ignorado: {hex(tipo)}")