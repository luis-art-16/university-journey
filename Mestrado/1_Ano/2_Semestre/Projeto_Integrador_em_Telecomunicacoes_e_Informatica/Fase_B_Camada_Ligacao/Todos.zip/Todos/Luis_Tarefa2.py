import serial
import threading

class Camada2_FullDuplex: 
    def __init__(self, porta_com, baudrate=9600): 
        self.serial_port = serial.Serial(porta_com, baudrate, timeout=0.1) 
        self.running = False 
        self.rx_thread = None 
        # Fila simples para guardar tramas recebidas para a Tarefa 3 processar depois
        self.tramas_recebidas = [] 

    def iniciar(self): 
        """Inicia a thread de receção contínua em background (Full-Duplex)""" 
        self.running = True 
        self.rx_thread = threading.Thread(target=self._receber_continuamente, daemon=True) 
        self.rx_thread.start() 
        print(f"[Link] Comunicação Full-Duplex iniciada na porta {self.serial_port.name}") 

    def parar(self): 
        self.running = False 
        if self.rx_thread: 
            self.rx_thread.join() 
        self.serial_port.close() 
        print("[Link] Comunicação encerrada.") 

    def enviar_trama_fisica(self, pacote_fisico): 
        """Injeta os bytes na ESP32. Não analisa o que lá está.""" 
        self.serial_port.write(pacote_fisico) 
        self.serial_port.flush() 

    def _receber_continuamente(self): 
        """Fica eternamente à escuta da ESP32 (Tarefa 2 do Luis).""" 
        buffer_rx = bytearray() 
        em_rececao = False 
        SOF = b'\x7E'

        while self.running: 
            if self.serial_port.in_waiting > 0: 
                byte_lido = self.serial_port.read(1) 
            
                if byte_lido == SOF: 
                    # ---> A MAGIA DA RESSINCRONIZAÇÃO <---
                    # Sempre que vemos um SOF, se houver lixo/dados no buffer, passamos para validação.
                    if len(buffer_rx) > 0: 
                        self.tramas_recebidas.append(bytes(buffer_rx)) 
                    
                    # Em vez de ligar/desligar, o SOF LIMPA o balde e 
                    # garante que estamos SEMPRE ABERTOS a receber a próxima trama!
                    buffer_rx.clear() 
                    em_rececao = True 
                    
                else: 
                    # Se não for SOF, e estivermos a receber, apenas guardamos o byte
                    if em_rececao: 
                        buffer_rx.extend(byte_lido)