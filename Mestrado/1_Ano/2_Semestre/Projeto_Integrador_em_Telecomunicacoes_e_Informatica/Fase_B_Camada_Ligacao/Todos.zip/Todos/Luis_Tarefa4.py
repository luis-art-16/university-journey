import time
from camada_ligacao_dados import CamadaDeLigacao
from constantes_protocolo import TYPE_TEXT

def modulo_teste_desempenho(camada2, numero_tramas=100): 
    """Injeta tráfego pesado usando a arquitetura integrada para extrair estatísticas.""" 
    print(f"\n[Teste] A iniciar envio massivo de {numero_tramas} tramas de stress...") 
    
    tramas_enviadas = 0 
    tramas_entregues_sucesso = 0 
    
    # Payload dummy com 100 bytes (dados aleatórios/repetidos para testar a carga)
    payload_dados = b'\xAA' * 100

    tempo_inicio = time.time() 

    for i in range(numero_tramas): 
        print(f"\n--- A enviar trama de teste {i+1}/{numero_tramas} ---")
        
        # A MAGIA DA INTEGRAÇÃO: 
        # Chamamos a Camada 2. Ela trata do encapsulamento, CRC, Stuffing e das Retransmissões!
        sucesso = camada2.enviar_ficheiro(payload=payload_dados, tipo=TYPE_TEXT)
        
        tramas_enviadas += 1 
        
        if sucesso: 
            tramas_entregues_sucesso += 1 
        else: 
            print(f"[!] FALHA CRÍTICA: Trama {i+1} perdida permanentemente após todas as tentativas.") 

    tempo_fim = time.time() 
    
    # Cálculos Finais de Estatísticas
    duracao_total = tempo_fim - tempo_inicio
    taxa_sucesso = (tramas_entregues_sucesso / numero_tramas) * 100 
    
    # Throughput prático = (Tramas entregues * Tamanho do Payload * 8 bits) / Tempo total
    throughput = (tramas_entregues_sucesso * len(payload_dados) * 8) / duracao_total if duracao_total > 0 else 0

    print("\n" + "="*45) 
    print("      RESULTADOS DO TESTE DE STRESS      ") 
    print("="*45) 
    print(f"Tempo Total:               {duracao_total:.2f} segundos") 
    print(f"Tramas Entregues:          {tramas_entregues_sucesso}/{numero_tramas}")
    print(f"Taxa de Sucesso:           {taxa_sucesso:.1f}%") 
    print(f"Throughput Prático:        {throughput:.2f} bps") 
    print("="*45) 

# ======================================================================= 
# BLOCO DE EXECUÇÃO 
# ======================================================================= 
if __name__ == "__main__": 
    # >>> ALTERA AQUI PARA A TUA PORTA COM NO ARCH LINUX <<< 
    PORTA_ESP32 = '/dev/ttyUSB0'  
    
    camada2 = CamadaDeLigacao(porta_com=PORTA_ESP32)
    camada2.iniciar_ligacao()
    time.sleep(2)  # A ESP32 precisa de 2 segundos para estabilizar ao abrir a porta
    
    try:
        modulo_teste_desempenho(camada2, numero_tramas=100) 
    except KeyboardInterrupt:
        print("\n[Aviso] Teste interrompido manualmente.")
    finally:
        camada2.fechar_ligacao()