import time
from logger import gerar_log 

class GestorTimeout:
    def __init__(self, timeout_segundos=1.5, max_tentativas=3):
        """
        Configura os parâmetros do ARQ exigidos na Tarefa 3.
        O relatório estima ~1.3s para enviar 1KB, logo 1.5s é um bom timeout base.
        """
        self.timeout_segundos = timeout_segundos
        self.max_tentativas = max_tentativas

    def enviar_com_garantia(self, trama: bytes, rotina_enviar, rotina_escutar_ack) -> bool:
        """
        Gere o ciclo de vida de uma trama: Envia, inicia o temporizador, 
        avalia a resposta e retransmite se necessário.
        """
        tentativa_atual = 1

        while tentativa_atual <= self.max_tentativas:
            gerar_log("ARQ", f"Tentativa {tentativa_atual}/{self.max_tentativas}: A transmitir a trama...", "INFO")
            
            # 1. Envia a trama para o canal (usando a função injetada)
            rotina_enviar(trama)

            # 2. Inicia o temporizador (Timeout)
            tempo_inicio = time.time()

            # 3. Fica bloqueado à espera do ACK até o tempo esgotar
            while (time.time() - tempo_inicio) < self.timeout_segundos:
                # Verifica se chegou alguma resposta do recetor
                resposta = rotina_escutar_ack()
                
                if resposta == "ACK":
                    tempo_demora = time.time() - tempo_inicio
                    gerar_log("ARQ", f"ACK válido recebido em {tempo_demora:.2f}s.", "SUCESSO")
                    return True # Sai da função, sucesso total!
                
                elif resposta == "NACK":
                    gerar_log("ARQ", "O recetor enviou um NACK. Forçando retransmissão!", "AVISO")
                    time.sleep(0.2)
                    break # Quebra este loop de espera para forçar nova tentativa
                
                # Pequena pausa para não bloquear o processador do PC a 100%
                time.sleep(0.01) 

            # Se chegámos aqui e a resposta não foi ACK, o temporizador expirou (Timeout) ou recebemos NACK
            if resposta != "NACK":
                gerar_log("ARQ", f"TIMEOUT: Tempo limite de {self.timeout_segundos}s esgotou.", "ERRO")
            
            tentativa_atual += 1

        # 4. Número máximo de transmissões ultrapassado declara falha
        gerar_log("ARQ", f"FALHA CRÍTICA. O número máximo de tentativas foi atingido.", "ERRO")
        return False
    

    # ==========================================
# Módulo de Simulação e Teste (Para provares que funciona)
# ==========================================

# Variável global para simularmos o comportamento da rede no teste
estado_simulador = "CENARIO_A" 

def mock_enviar(trama):
    """Finge que envia dados pela porta série."""
    pass

def mock_escutar_ack():
    """Finge que está a ler a porta série à procura de uma resposta."""
    global estado_simulador
    
    # CENÁRIO A: Transmissão Ideal 
    if estado_simulador == "CENARIO_A":
        return "ACK" # Responde logo com sucesso
        
    # CENÁRIO B: Perda de Trama (Feixe interrompido) 
    elif estado_simulador == "CENARIO_B":
        # Não retorna nada, simulando que o feixe ótico foi cortado
        return None 
        
    # CENÁRIO C: Corrupção de bits (FCS inválido no recetor) 
    elif estado_simulador == "CENARIO_C":
        # Retorna NACK, forçando o emissor a retransmitir sem esperar pelo timeout
        estado_simulador = "CENARIO_A" # Na 2ª tentativa, deixamos passar o ACK
        return "NACK"

if __name__ == "__main__":
    gestor = GestorTimeout(timeout_segundos=1.0, max_tentativas=3)
    trama_ficticia = b"TRAMA_DE_DADOS"

    print("="*50)
    print("TESTE 1: Cenário A - Transmissão Ideal (Sucesso imediato)")
    estado_simulador = "CENARIO_A"
    gestor.enviar_com_garantia(trama_ficticia, mock_enviar, mock_escutar_ack)

    print("="*50)
    print("TESTE 2: Cenário C - Corrupção de bits (NACK recebido -> Retransmite e tem sucesso)")
    estado_simulador = "CENARIO_C"
    gestor.enviar_com_garantia(trama_ficticia, mock_enviar, mock_escutar_ack)

    print("="*50)
    print("TESTE 3: Cenário B - Perda Total (Timeout 3x -> Falha Crítica)")
    estado_simulador = "CENARIO_B"
    # Aqui o código vai esperar 1 segundo por tentativa, e falhar à 3ª
    gestor.enviar_com_garantia(trama_ficticia, mock_enviar, mock_escutar_ack)
    print("="*50)