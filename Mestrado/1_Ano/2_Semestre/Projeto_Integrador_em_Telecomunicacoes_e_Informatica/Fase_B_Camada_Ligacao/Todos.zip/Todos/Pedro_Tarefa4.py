import time
from camada_ligacao_dados import CamadaDeLigacao
from constantes_protocolo import TYPE_TEXT, TYPE_IMAGE

def transferir_ficheiro_grande(camada2, dados_originais: bytes, tipo_ficheiro: int):
    """
    Simula a Tarefa do Pedro: Fragmentar um ficheiro grande na emissão, 
    enviar sequencialmente e aguardar a sua reconstrução no recetor.
    """
    # 1. Limpar o balde de receção do recetor antes de começar
    camada2.buffer_rececao.clear()
    
    # 2. Definir o tamanho do fragmento (Abaixo do máximo de 256 da API do Bernardo)
    tamanho_fragmento = 200 
    
    # 3. Fragmentação (Partir o ficheiro em pedaços)
    fragmentos = [dados_originais[i:i + tamanho_fragmento] for i in range(0, len(dados_originais), tamanho_fragmento)]
    
    print(f"\n[Camada 7] Iniciando transferência. Tamanho total: {len(dados_originais)} bytes.")
    print(f"[Camada 7] O ficheiro foi dividido em {len(fragmentos)} fragmentos de {tamanho_fragmento} bytes.")
    
    tempo_inicio = time.time()
    
    # 4. Envio Sequencial
    for i, frag in enumerate(fragmentos):
        print(f"\n--- A enviar fragmento {i+1}/{len(fragmentos)} ---")
        sucesso = camada2.enviar_ficheiro(payload=frag, tipo=tipo_ficheiro)
        
        if not sucesso:
            print(f"[!] Erro fatal ao transferir o fragmento {i+1}. Abortando a transferência do ficheiro.")
            return False
            
        # O Backoff Time para não asfixiar a ESP32!
        time.sleep(0.1)

    # 5. Validação da Reconstrução (No lado do Recetor)
    tempo_total = time.time() - tempo_inicio
    ficheiro_reconstruido = bytes(camada2.buffer_rececao)
    
    print("\n" + "="*50)
    print("RESUMO DA TRANSFERÊNCIA E RECONSTRUÇÃO")
    print("="*50)
    print(f"Tempo demorado:      {tempo_total:.2f} segundos")
    print(f"Bytes enviados:      {len(dados_originais)}")
    print(f"Bytes reconstruídos: {len(ficheiro_reconstruido)}")
    
    if dados_originais == ficheiro_reconstruido:
        print("[SUCESSO] O ficheiro reconstruído no recetor é EXATAMENTE IGUAL ao original!")
    else:
        print("[ERRO] Os dados reconstruídos não coincidem com os originais.")
    print("="*50)
    
    return ficheiro_reconstruido

if __name__ == "__main__":
    PORTA_ESP32 = '/dev/ttyUSB0' # Arch Linux
    
    camada2 = CamadaDeLigacao(porta_com=PORTA_ESP32)
    camada2.iniciar_ligacao()
    time.sleep(2) # Dar tempo à placa
    
    # ==========================================
    # TESTE 1: FICHEIRO DE TEXTO LONGO
    # ==========================================
    print("\n>>> INICIANDO TESTE 1: FICHEIRO DE TEXTO <<<")
    texto_hardcoded = (
        "Este é um ficheiro de texto extremamente longo criado pelo Grupo 3. "
        "O objetivo deste ficheiro é forçar a Camada de Aplicação a realizar a "
        "fragmentação dos dados. Como o nosso protocolo de Camada 2 apenas suporta "
        "tramas com um payload máximo de 256 bytes, esta mensagem inteira não pode "
        "ser enviada de uma só vez. A tarefa do Pedro garante que tudo é cortado, "
        "enviado de forma sequencial pelo Gestor do Bernardo, validado pelo CRC "
        "do Pedro, alternado pelo Nuno e isolado pelo Luís. No final, tudo se une novamente!"
    ).encode('utf-8')
    
    transferir_ficheiro_grande(camada2, texto_hardcoded, TYPE_TEXT)
    
    time.sleep(1) # Pausa entre testes
    
    # ==========================================
    # TESTE 2: FICHEIRO DE IMAGEM (Dados Binários Hard-Coded)
    # ==========================================
    print("\n>>> INICIANDO TESTE 2: FICHEIRO DE IMAGEM BINÁRIA <<<")
    # Simulamos uma imagem PNG com o seu Header real e bytes aleatórios de imagem (500 bytes)
    imagem_hardcoded = b'\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR' + (b'\xFA\x8B\x0C' * 160)
    
    transferir_ficheiro_grande(camada2, imagem_hardcoded, TYPE_IMAGE)
    
    camada2.fechar_ligacao()