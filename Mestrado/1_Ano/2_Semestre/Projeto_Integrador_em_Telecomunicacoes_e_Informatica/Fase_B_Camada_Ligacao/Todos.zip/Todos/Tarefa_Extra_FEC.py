def codificar_nibble(nibble: int) -> int:
    """Codifica 4 bits de dados em 7 bits usando Hamming(7,4)."""
    d1 = (nibble >> 3) & 1
    d2 = (nibble >> 2) & 1
    d3 = (nibble >> 1) & 1
    d4 = nibble & 1
    
    # Cálculo dos bits de paridade
    p1 = d1 ^ d2 ^ d4
    p2 = d1 ^ d3 ^ d4
    p3 = d2 ^ d3 ^ d4
    
    # Formato: 0 | p1 | p2 | d1 | p3 | d2 | d3 | d4
    return (p1 << 6) | (p2 << 5) | (d1 << 4) | (p3 << 3) | (d2 << 2) | (d3 << 1) | d4

def decodificar_nibble(byte_val: int) -> tuple[int, bool]:
    """Decodifica 7 bits, corrigindo 1 bit errado se necessário."""
    p1 = (byte_val >> 6) & 1
    p2 = (byte_val >> 5) & 1
    d1 = (byte_val >> 4) & 1
    p3 = (byte_val >> 3) & 1
    d2 = (byte_val >> 2) & 1
    d3 = (byte_val >> 1) & 1
    d4 = byte_val & 1
    
    # Cálculo dos Síndromes (Verificação de Erros)
    s1 = p1 ^ d1 ^ d2 ^ d4
    s2 = p2 ^ d1 ^ d3 ^ d4
    s3 = p3 ^ d2 ^ d3 ^ d4
    
    sindrome = (s3 << 2) | (s2 << 1) | s1
    erro_corrigido = False
    
    if sindrome != 0:
        erro_corrigido = True
        # Corrige o bit estragado baseado no síndrome
        if sindrome == 3: d1 ^= 1
        elif sindrome == 5: d2 ^= 1
        elif sindrome == 6: d3 ^= 1
        elif sindrome == 7: d4 ^= 1
        # Se for 1, 2 ou 4, o erro foi nos bits de paridade (ignoramos)
        
    nibble_corrigido = (d1 << 3) | (d2 << 2) | (d3 << 1) | d4
    return nibble_corrigido, erro_corrigido

def codificar_hamming(dados_originais: bytes) -> bytes:
    """Transforma os dados aplicando Hamming. O tamanho duplica."""
    codificado = bytearray()
    for byte in dados_originais:
        high = (byte >> 4) & 0x0F
        low = byte & 0x0F
        codificado.append(codificar_nibble(high))
        codificado.append(codificar_nibble(low))
    return bytes(codificado)

def decodificar_hamming(dados_codificados: bytes) -> tuple[bytes, int]:
    """Reverte o Hamming e devolve os dados originais e quantos erros corrigiu."""
    decodificado = bytearray()
    erros = 0
    
    for i in range(0, len(dados_codificados), 2):
        if i + 1 >= len(dados_codificados): break
        
        high_nibble, err1 = decodificar_nibble(dados_codificados[i])
        low_nibble, err2 = decodificar_nibble(dados_codificados[i+1])
        
        if err1: erros += 1
        if err2: erros += 1
        
        decodificado.append((high_nibble << 4) | low_nibble)
        
    return bytes(decodificado), erros