def calcular_crc8(dados: bytes) -> bytes:
    """
    Tarefa 3 (Pedro - Versão Avançada): Calcula o CRC-8 de um conjunto de bytes.
    Utiliza o polinómio gerador padrão 0x07.
    """
    crc = 0x00
    polinomio = 0x07
    
    for byte in dados:
        crc ^= byte  # Faz XOR do byte atual com o valor do CRC
        
        # Processa cada um dos 8 bits do byte
        for _ in range(8):
            if crc & 0x80:  # Se o bit mais significativo (esquerda) for 1
                crc = (crc << 1) ^ polinomio
            else:
                crc = (crc << 1)
                
            crc &= 0xFF  # Garante que o valor nunca ultrapassa 8 bits (1 byte)
            
    # Retorna o valor como um objeto 'bytes' de tamanho 1
    return bytes([crc])

def verificar_crc8(dados: bytes, crc_recebido: bytes) -> bool:
    """
    Tarefa 3 (Pedro): Recalcula o CRC-8 no recetor e compara com o recebido.
    Se não corresponder, a trama tem erros.
    """
    crc_calculado = calcular_crc8(dados)
    
    if crc_calculado == crc_recebido:
        return True  # Trama válida (Sem erros detetados)
    else:
        return False # Trama corrompida (Descartar)

# ==========================================
# Módulo de Teste (Para provares que funciona)
# ==========================================
if __name__ == "__main__":
    print("="*50)
    print("TESTE 1: Trama Intacta (Sucesso esperado)")
    
    # Simulamos um cabeçalho e um payload
    cabecalho = b'\x02\x01\x01\x00\x04' # MAC_D, MAC_S, TIPO, SEQ, LEN(4)
    payload = b"Dado"
    trama_sem_fcs = cabecalho + payload
    
    # O Emissor calcula o FCS usando CRC-8
    fcs_enviado = calcular_crc8(trama_sem_fcs)
    print(f"Emissor: CRC-8 calculado = {fcs_enviado.hex().upper()}")
    
    # O Recetor verifica
    valido = verificar_crc8(trama_sem_fcs, fcs_enviado)
    print(f"Recetor: O CRC-8 é válido? -> {valido}")

    print("\n" + "="*50)
    print("TESTE 2: Trama Corrompida no Canal (Falha esperada)")
    
    # Simulamos um erro no canal: o "D" (0x44) vira "E" (0x45)
    trama_corrompida = cabecalho + b"Eado"
    
    # O Recetor tenta verificar usando o FCS original
    valido_corrompido = verificar_crc8(trama_corrompida, fcs_enviado)
    print(f"Recetor: O CRC-8 de uma trama com erros é válido? -> {valido_corrompido}")
    
    if not valido_corrompido:
        print("[!] SUCESSO DO TESTE: O erro foi detetado (CRC falhou) e a trama seria descartada!")
        
    print("\n" + "="*50)
    print("TESTE 3: Troca de ordem de bytes (A fraqueza do Checksum, a força do CRC)")
    
    # Se trocássemos "Dado" por "adoD", o Checksum antigo daria VERDADEIRO (porque a soma é igual).
    # Vamos ver o que o CRC-8 acha disto!
    trama_trocada = cabecalho + b"adoD"
    valido_trocado = verificar_crc8(trama_trocada, fcs_enviado)
    print(f"Recetor: O CRC-8 deteta se os bytes trocarem de ordem? -> Falha o CRC? {not valido_trocado}")
    print("="*50)