import struct

def encapsular_trama(payload: bytes, mac_dest: int, mac_orig: int, tipo: int, seq_num: int, fcs: bytes) -> bytes:
    """
    Tarefa 2 (Nuno): Encapsulamento da trama no emissor.
    Recebe o payload da Camada 7, insere o cabeçalho (MACs, tipo, seq, length),
    anexa o payload e fecha com a cauda (FCS). 
    """
    # 1. Definir o campo Length (1 byte). 
    # Como o payload máximo é 256, se for 256 representamos como 0 (pois 1 byte vai de 0-255).
    length_campo = len(payload) % 256 
    
    # 2. Montar o Cabeçalho (Header)
    # '>BBBBB' = 5 variáveis de 1 Byte cada (Dest, Orig, Tipo, Seq, Length)
    cabecalho = struct.pack(
        '>BBBBB', 
        mac_dest, 
        mac_orig, 
        tipo, 
        seq_num, 
        length_campo
    )
    
    # 3. Montar a Trama Final (Cabeçalho + Payload + FCS)
    # Nota: O SOF e o Byte Stuffing serão aplicados a esta trama depois.
    trama_encapsulada = cabecalho + payload + fcs
    
    return trama_encapsulada

# --- Teste isolado da Tarefa do Nuno ---
if __name__ == "__main__":
    # O payload e o FCS já vêm tratados e validados de outras funções/tarefas!
    payload_da_api = b"C" * 100  # Faz de conta que a API do Bernardo já validou isto
    fcs_do_pedro = b'\xFF'       # Faz de conta que o Pedro já calculou o Checksum (Tarefa 3)
    
    trama_pronta = encapsular_trama(
        payload=payload_da_api,
        mac_dest=0x02,
        mac_orig=0x01,
        tipo=0x01, # Ficheiro de texto
        seq_num=1,
        fcs=fcs_do_pedro
    )
    
    print(f"Tamanho total da trama: {len(trama_pronta)} bytes")
    print(f"Cabeçalho + Payload + FCS unidos com sucesso!")
    # Opcional: imprimir em hex para ver os bytes
    # print(f"Trama em Hexadecimal: {binascii.hexlify(trama_pronta)}")