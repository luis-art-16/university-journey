import serial

# ==========================================
# 1. Constantes e Estrutura da Trama
# ==========================================

# Tipos de Trama (Type) definidos no relatório
TYPE_TEXT = 0x01  # Ficheiros de texto 
TYPE_IMAGE = 0x02  # Conteúdos multimédia 
TYPE_ACK = 0x0A       # Confirmação positiva 
TYPE_NACK = 0x0B      # Confirmação negativa 
TYPE_EOF = 0x03

# Limites do Payload definidos no relatório
MIN_PAYLOAD_SIZE = 1   
MAX_PAYLOAD_SIZE = 256  

# ==========================================
# 2. Classe da API (Camada 2)
# ==========================================

class Camada2API:
    def __init__(self, porta='/dev/ttyUSB0', baudrate=9600):
        """
        Inicializa a comunicação com a ESP32.
        No Linux, altera 'porta' para algo como '/dev/ttyUSB0'.
        """
        try:
            # Configuração 8-N-1 implícita no pyserial 
            self.conexao = serial.Serial(porta, baudrate, timeout=1)
            print(f"Sucesso: Conectado à porta {porta} a {baudrate} bps.")
        except serial.SerialException as e:
            print(f"Erro ao abrir a porta série: {e}")

    def sendFrame(self, payload: bytes, frame_type: int) -> bool:
        """
        API para a Camada 7 enviar dados.
        Recebe os dados brutos, valida-os e prepara-os para a camada de ligação.
        """
        # 1. Validação do tamanho do payload para não sobrecarregar a memória 
        tamanho_payload = len(payload)
        if not (MIN_PAYLOAD_SIZE <= tamanho_payload <= MAX_PAYLOAD_SIZE):
            print(f"Erro: O payload tem {tamanho_payload} bytes. Deve estar entre {MIN_PAYLOAD_SIZE} e {MAX_PAYLOAD_SIZE} bytes.")
            return False

        print(f"API: Preparando para enviar payload de {tamanho_payload} bytes do tipo {hex(frame_type)}.")
        
        # 2. Passagem para a função de encapsulamento (Tarefa do Nuno) 
        # Aqui, chamarias a função do Nuno que junta o SOF, MACs, Sequence Number e calcula o FCS.
        # buffer_pronto = nuno_encapsula(payload, frame_type)
        # self.conexao.write(buffer_pronto)
        
        return True

    def receiveFrame(self, buffer_validado: bytes) -> bytes:
        """
        API para entregar dados à Camada 7.
        Recebe um buffer (já validado pelo FCS) e extrai apenas a informação útil. [cite: 311]
        """
        # Sabendo que o cabeçalho tem 6 bytes: SOF(1) + MAC_Dest(1) + MAC_Src(1) + Type(1) + Seq(1) + Length(1) [cite: 99]
        # O payload começa no índice 6. O tamanho exato estaria no campo Length (índice 5).
        
        tamanho_payload = buffer_validado[5]
        payload_extraido = buffer_validado[6 : 6 + tamanho_payload]
        
        print("API: Payload extraído com sucesso. A entregar à Camada de Aplicação...")
        
        return payload_extraido

if __name__ == "__main__":
    # Como vamos testar a lógica sem usar a porta série para já, 
    # podemos inicializar a classe "em seco" ou ignorar o erro da porta COM.
    api = Camada2API(porta='COM_TESTE') 
    
    print("\n--- TESTE 1: sendFrame (Validação de Tamanhos) ---")
    
    # Teste 1A: Payload demasiado pequeno (< 68 bytes)
    dados_pequenos = b"A" * 50 
    print("A tentar enviar 50 bytes...")
    api.sendFrame(dados_pequenos, TYPE_TEXT) # Deve dar erro

    # Teste 1B: Payload demasiado grande (> 256 bytes)
    dados_grandes = b"B" * 300
    print("A tentar enviar 300 bytes...")
    api.sendFrame(dados_grandes, TYPE_IMAGE) # Deve dar erro

    # Teste 1C: Payload válido (ex: 100 bytes)
    dados_validos = b"C" * 100
    print("A tentar enviar 100 bytes...")
    api.sendFrame(dados_validos, TYPE_TEXT) # Deve dar sucesso


    print("\n--- TESTE 2: receiveFrame (Extração do Payload) ---")
    
    # Vamos construir uma trama "falsa" na mão para simular o que chega do recetor.
    # Estrutura (Figura 2): SOF(1) | MAC_D(1) | MAC_S(1) | TYPE(1) | SEQ(1) | LEN(1) | PAYLOAD(N) | FCS(1)
    
    sof = b'\x7E'
    mac_d = b'\x02'
    mac_s = b'\x01'
    tipo = bytes([TYPE_TEXT])
    seq = b'\x00'
    
    # O nosso payload de teste
    payload_teste = b"Ola Mundo! Teste Grupo 3 - Ficheiro de Texto" # 28 bytes
    tamanho_payload = len(payload_teste)
    len_byte = bytes([tamanho_payload])
    
    fcs_falso = b'\xFF' # FCS inventado só para preencher o espaço

    # Junta tudo num único buffer simulado
    trama_simulada = sof + mac_d + mac_s + tipo + seq + len_byte + payload_teste + fcs_falso
    
    print(f"Trama bruta simulada (tamanho total: {len(trama_simulada)} bytes):", trama_simulada)
    
    # Testar a tua função!
    resultado = api.receiveFrame(trama_simulada)
    
    print(f"Payload extraído pela tua função: {resultado.decode('utf-8', errors='ignore')}")
    
    if resultado == payload_teste:
        print("-> SUCESSO! A função extraiu os dados corretamente.")
    else:
        print("-> ERRO! Os dados extraídos não correspondem ao original.")