import time
from camada_ligacao_dados import CamadaDeLigacao
from constantes_protocolo import TYPE_TEXT

def executar_teste_aplicacao():
    """
    Tarefa 4 (Bernardo): Script da Camada de Aplicação (Camada 7).
    Gera um ficheiro, envia-o usando a Camada 2 integrada, e mede o desempenho.
    """
    print("="*60)
    print("CAMADA DE APLICAÇÃO - INÍCIO DA TRANSFERÊNCIA DE TESTE")
    print("="*60)

    # 1. Instanciar a Camada 2 na tua porta do Arch Linux
    porta = '/dev/ttyUSB0'
    camada2 = CamadaDeLigacao(porta_com=porta)
    
    # 2. Iniciar a escuta em background
    camada2.iniciar_ligacao()
    time.sleep(1) # Dá um segundo para a porta série acordar

    # 3. Preparar os dados a enviar (Pode ser a leitura de um ficheiro .txt real)
    # Vamos criar um payload com cerca de 100 bytes para testar os limites matemáticos
    mensagem = "Ola Grupo 3! Este e o ficheiro de teste da nossa Tarefa 4. "
    mensagem += "Se lerem isto do outro lado, o projeto e um sucesso absoluto!"
    payload_aplicacao = mensagem.encode('utf-8')

    print(f"\n[App] A preparar envio de ficheiro de Texto com {len(payload_aplicacao)} bytes...")
    print(f"[App] Conteúdo: '{mensagem}'\n")

    # 4. Iniciar Cronómetro
    tempo_inicio = time.time()

    # 5. CHAMAR A TUA API! (Isto desencadeia todo o processo das Tarefas 1, 2 e 3)
    sucesso = camada2.enviar_ficheiro(payload=payload_aplicacao, tipo=TYPE_TEXT)

    # 6. Parar Cronómetro e Calcular Estatísticas
    tempo_fim = time.time()
    tempo_total = tempo_fim - tempo_inicio

    print("\n" + "="*60)
    print("ESTATÍSTICAS DA TRANSFERÊNCIA (TAREFA 4)")
    print("="*60)
    
    if sucesso:
        print("[RESULTADO] SUCESSO! Ficheiro entregue e confirmado.")
        print(f"[TEMPO] A transferência demorou: {tempo_total:.3f} segundos.")
        
        # Cálculo básico de débito (Throughput)
        bits_enviados = len(payload_aplicacao) * 8
        debito_bps = bits_enviados / tempo_total
        print(f"[DÉBITO] Velocidade efetiva: {debito_bps:.2f} bps (bits de dados por segundo).")
    else:
        print("[RESULTADO] FALHA CRÍTICA! A ligação caiu ou o limite de retransmissões foi atingido.")
        print(f"[TEMPO] O sistema desistiu após {tempo_total:.3f} segundos.")

    print("="*60)

    # 7. Fechar e arrumar a casa
    camada2.fechar_ligacao()

if __name__ == "__main__":
    executar_teste_aplicacao()