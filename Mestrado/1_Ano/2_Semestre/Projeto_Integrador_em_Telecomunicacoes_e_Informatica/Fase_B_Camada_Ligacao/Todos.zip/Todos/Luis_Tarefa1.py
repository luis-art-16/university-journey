# =======================================================================
# TAREFA 1: SINCRONIZAÇÃO, DELIMITAÇÃO E BYTE STUFFING
# =======================================================================

SOF = b'\x7E'      # Start of Frame
ESC = b'\x7D'      # Escape
ESC_SOF = b'\x5E'  # Substituta para SOF dentro dos dados
ESC_ESC = b'\x5D'  # Substituta para ESC dentro dos dados

def byte_stuffing(frame_data):
    """
    Recebe a trama limpa e aplica o Byte Stuffing para garantir
    que a flag SOF (0x7E) não aparece no meio dos dados.
    """
    stuffed_data = bytearray()
    for byte in frame_data:
        # Converter para bytes para comparação
        b = bytes([byte])
        if b == SOF:
            stuffed_data.extend(ESC + ESC_SOF)
        elif b == ESC:
            stuffed_data.extend(ESC + ESC_ESC)
        else:
            stuffed_data.extend(b)
    return bytes(stuffed_data)

def byte_destuffing(stuffed_data):
    """
    Recebe os dados brutos delimitados pelo SOF e reverte o Byte Stuffing.
    """
    destuffed_data = bytearray()
    escape_next = False
    
    for byte in stuffed_data:
        b = bytes([byte])
        if escape_next:
            if b == ESC_SOF:
                destuffed_data.extend(SOF)
            elif b == ESC_ESC:
                destuffed_data.extend(ESC)
            else:
                # Mantém o byte original em caso de erro na sequência de escape
                destuffed_data.extend(b)
            escape_next = False
        elif b == ESC:
            escape_next = True
        else:
            destuffed_data.extend(b)
            
    return bytes(destuffed_data)

# --- Exemplo de Teste ---
if __name__ == "__main__":
    dados_originais = b"Ola\x7E Mundo\x7D Teste"
    print(f"Original: {dados_originais}")
    
    stuffed = byte_stuffing(dados_originais)
    print(f"Stuffed:  {stuffed}")
    
    destuffed = byte_destuffing(stuffed)
    print(f"Destuffed: {destuffed}")
    
    assert dados_originais == destuffed
    print("Sucesso: Os dados coincidem!")