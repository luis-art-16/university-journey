import time
import os
import sys
from camada_ligacao_dados import CamadaDeLigacao
from constantes_protocolo import TYPE_TEXT, TYPE_IMAGE, TYPE_EOF, MIN_PAYLOAD_SIZE
from logger import gerar_log 

def enviar_ficheiro_real(caminho_ficheiro, tipo_ficheiro):
    PORTA = '/dev/ttyUSB0' # Substituir pela porta da ESP32 n.º 1
    camada2 = CamadaDeLigacao(porta_com=PORTA)
    camada2.iniciar_ligacao()
    time.sleep(2)
    
    # 1. Verificar se o ficheiro existe no PC
    if not os.path.exists(caminho_ficheiro):
        print(f"[ERRO] O ficheiro '{caminho_ficheiro}' não existe na pasta atual!")
        camada2.fechar_ligacao()
        return

    # 2. Ler o ficheiro real em formato Binário ('rb')
    with open(caminho_ficheiro, 'rb') as f:
        dados_completos = f.read()

    gerar_log("EMISSOR", f"Ficheiro '{caminho_ficheiro}' carregado ({len(dados_completos)} bytes).", "INFO")
    # 3. Fragmentação (dividir em pedaços de 200 bytes)
    tamanho_fragmento = 100
    fragmentos = [dados_completos[i:i + tamanho_fragmento] for i in range(0, len(dados_completos), tamanho_fragmento)]
    
    tempo_inicio = time.time()
    
    # 4. Envio Sequencial de todos os fragmentos
    sucesso_total = True
    for i, frag in enumerate(fragmentos):

        gerar_log("EMISSOR", f"A enviar fragmento {i+1}/{len(fragmentos)}...", "INFO")
        sucesso = camada2.enviar_ficheiro(payload=frag, tipo=tipo_ficheiro)
        
        if not sucesso:
            gerar_log("EMISSOR", f"Falha crítica no fragmento {i+1}. Abortando.", "ERRO")
            sucesso_total = False
            break
            
        time.sleep(0.01) # Backoff Time para a ESP32 respirar
    
    tempo_total = time.time() - tempo_inicio
    
    if sucesso_total:
        # ---> EXTRAIR A EXTENSÃO DO FICHEIRO ORIGINAL <---
        _, extensao = os.path.splitext(caminho_ficheiro)
        if not extensao: 
            extensao = ".bin" # Prevenção caso o ficheiro não tenha extensão
            
        gerar_log("EMISSOR", f"A enviar EOF com a extensão '{extensao}'...", "INFO")
        camada2.enviar_ficheiro(payload=extensao.encode('utf-8'), tipo=TYPE_EOF)
        
        gerar_log("EMISSOR", f"Ficheiro enviado em {tempo_total:.2f} segundos!", "SUCESSO")
    else:
        gerar_log("EMISSOR", "Transferência falhou.", "ERRO")
        
    camada2.fechar_ligacao()

if __name__ == "__main__":
    # Verifica se o utilizador passou o argumento no terminal
    if len(sys.argv) < 2:
        print("Uso incorreto!")
        print("Como usar: python emissor.py <nome_do_ficheiro>")
        sys.exit(1) # Aborta o programa com erro

    # O nome do ficheiro será o primeiro argumento a seguir ao nome do script
    NOME_DO_FICHEIRO = sys.argv[1]
    
    # --- BÓNUS: Detetar automaticamente se é texto ou imagem! ---
    # Colocamos tudo em minúsculas para facilitar a verificação
    nome_minusculo = NOME_DO_FICHEIRO.lower()
    
    if nome_minusculo.endswith(('.png', '.jpg', '.jpeg', '.gif', '.bmp')):
        tipo_detetado = TYPE_IMAGE
        print(f"[*] Tipo de ficheiro detetado: IMAGEM")
    else:
        tipo_detetado = TYPE_TEXT
        print(f"[*] Tipo de ficheiro detetado: TEXTO")
        
    # Inicia a transferência com os parâmetros lidos do terminal
    enviar_ficheiro_real(NOME_DO_FICHEIRO, tipo_detetado)