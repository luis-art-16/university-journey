import time
from camada_ligacao_dados import CamadaDeLigacao
from logger import gerar_log

def iniciar_recetor():
    PORTA = '/dev/ttyUSB1' # Confirma a tua porta
    camada2 = CamadaDeLigacao(porta_com=PORTA)
    camada2.iniciar_ligacao()
    time.sleep(2)
    
    camada2.buffer_rececao.clear()
    
    gerar_log("RECETOR", "SERVIDOR CONTÍNUO INICIADO", "SUCESSO")
    gerar_log("RECETOR", "À escuta no canal série. Pronto para múltiplos ficheiros...", "INFO")
    
    try:
        while True:
            camada2._escutar_canal_arq()
            
            # ---> NOVO: O WATCHDOG TIMER (Mecanismo de Sobrevivência) <---
            # Se o balde tem pacotes parados (ficheiro a meio) 
            # E já passaram mais de 10 segundos desde o último pacote...
            if len(camada2.buffer_rececao) > 0:
                tempo_silencio = time.time() - camada2.ultimo_tempo_rececao
                
                if tempo_silencio > 10.0:
                    gerar_log("WATCHDOG", "ALERTA: A ligação anterior caiu ou o emissor abortou!", "ERRO")
                    gerar_log("WATCHDOG", "A limpar buffer corrompido e a reiniciar Máquina de Estados...", "AVISO")
                    
                    # Limpa o balde e sincroniza a máquina de estados!
                    camada2.buffer_rececao.clear()
                    camada2.arq.seq_num_esperado = 0
                    
                    # Atualiza o relógio para não spammar mensagens
                    camada2.ultimo_tempo_rececao = time.time()
                    gerar_log("WATCHDOG", "Sistema limpo. À escuta novamente.", "INFO")
                    
            time.sleep(0.01)
            
    except KeyboardInterrupt:
        gerar_log("RECETOR", "Encerrado pelo utilizador.", "AVISO")
    finally:
        camada2.fechar_ligacao()

if __name__ == "__main__":
    iniciar_recetor()