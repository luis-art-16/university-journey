import time
from camada_ligacao_dados import CamadaDeLigacao
from constantes_protocolo import TYPE_TEXT

def executar_teste_caos_nuno():
    print("="*65)
    print("TAREFA 4 (NUNO) - INJEÇÃO DE FALHAS E RECUPERAÇÃO DO SISTEMA")
    print("="*65)

    # Iniciar a Camada 2 normalmente
    PORTA_ESP32 = '/dev/ttyUSB2' # Arch Linux
    camada2 = CamadaDeLigacao(porta_com=PORTA_ESP32)
    camada2.iniciar_ligacao()
    time.sleep(2)

    # 1. O TRUQUE: Guardar a função de envio original
    envio_original = camada2.link.enviar_trama_fisica
    
    # Variável para contar quantos pacotes já tentámos enviar
    contador_envios = 0

    def envio_com_falhas_injetadas(pacote_fisico):
        """Esta função substitui temporariamente o envio normal para criar o caos."""
        nonlocal contador_envios
        contador_envios += 1
        
        # A injeção do caos depende do número do pacote:
        if contador_envios == 2:
            print("\n[HACKER DO NUNO] A corromper o CRC do Pacote 2 propositadamente...")
            # Pega no pacote e soma 1 ao byte do CRC (o penúltimo, antes do SOF final)
            pacote_corrompido = bytearray(pacote_fisico)
            pacote_corrompido[-2] = (pacote_corrompido[-2] + 1) % 256 
            envio_original(bytes(pacote_corrompido))
            
        elif contador_envios == 5:
            print("\n[HACKER DO NUNO] A cortar o cabo ótico no Pacote 5 (Drop total)...")
            # Não chamamos a função envio_original. O pacote esfuma-se no ar!
            pass 
            
        else:
            # Em todos os outros pacotes, o canal funciona perfeitamente
            envio_original(pacote_fisico)

    # 2. Aplicar o Sequestro (Substituir a função na Camada 2)
    camada2.link.enviar_trama_fisica = envio_com_falhas_injetadas

    # 3. Preparar os dados para enviar (Vamos fragmentar para ver vários pacotes a passar)
    mensagem_teste = b"Mensagem secreta do Nuno para testar a recuperacao de erros! " * 3
    tamanho_fragmento = 100
    fragmentos = [mensagem_teste[i:i + tamanho_fragmento] for i in range(0, len(mensagem_teste), tamanho_fragmento)]
    
    print(f"[App] Vamos enviar {len(fragmentos)} fragmentos sob ataque informático constante!\n")
    
    tempo_inicio = time.time()
    
    # 4. Iniciar o Envio
    for i, frag in enumerate(fragmentos):
        print(f"--- A processar fragmento {i+1}/{len(fragmentos)} ---")
        sucesso = camada2.enviar_ficheiro(payload=frag, tipo=TYPE_TEXT)
        
        if not sucesso:
            print("[!] O SISTEMA FALHOU EM RECUPERAR. TRANSFERÊNCIA ABORTADA.")
            break
            
        time.sleep(0.1) # Pausa amigável para a ESP32 respirar

    tempo_total = time.time() - tempo_inicio

    print("\n" + "="*65)
    print("RESULTADO DA RECUPERAÇÃO DE FALHAS")
    print("="*65)
    print(f"Tempo demorado total: {tempo_total:.2f} segundos")
    print("[SUCESSO] O protocolo detetou os erros, forçou as retransmissões e")
    print("          entregou todos os pacotes com sucesso à Camada de Aplicação!")
    print("="*65)
    
    # Desfazer o sequestro e fechar a porta
    camada2.link.enviar_trama_fisica = envio_original
    camada2.fechar_ligacao()

if __name__ == "__main__":
    executar_teste_caos_nuno()