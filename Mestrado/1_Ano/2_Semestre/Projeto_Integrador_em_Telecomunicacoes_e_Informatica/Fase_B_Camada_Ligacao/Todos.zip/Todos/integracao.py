import time
from logger import gerar_log

# ==========================================
# IMPORTAÇÃO DAS TAREFAS 1, 2 E 3
# ==========================================
# Tarefa 1
from constantes_protocolo import TYPE_TEXT, TYPE_IMAGE, MIN_PAYLOAD_SIZE, MAX_PAYLOAD_SIZE, TYPE_EOF
from framing_hdlc import byte_stuffing, byte_destuffing, SOF

# Tarefa 2
from camada_fisica import Camada2_FullDuplex
from Nuno_Tarefa2 import encapsular_trama

# Tarefa 3
from crc8 import calcular_crc8, verificar_crc8
from maquina_estados_arq import MaquinaEstadosARQ
from temporizador_arq import GestorTimeout

from fec_hamming import codificar_hamming, decodificar_hamming

class CamadaDeLigacao:
    """
    Classe unificadora da Fase B.
    Junta todas as funções das Tarefas 1, 2 e 3 para fornecer um serviço de 
    transferência fiável à Camada 7.
    """
    def __init__(self, porta_com='/dev/ttyUSB0'):
        print(f"[*] A inicializar a Camada 2 (Ligação de Dados) na porta {porta_com}...")
        
        # Inicializa o hardware (Tarefa 2 - Luís)
        self.link = Camada2_FullDuplex(porta_com, baudrate=9600)
        
        # Inicializa a Máquina de Estados (Tarefa 3 - Nuno)
        self.arq = MaquinaEstadosARQ()
        
        # Inicializa o teu Gestor de Timeouts (Tarefa 3 - Bernardo)
        self.gestor_timeout = GestorTimeout(timeout_segundos=2.0, max_tentativas=7)

        self.buffer_rececao = bytearray()

        self.ultimo_tempo_rececao = time.time()

    def iniciar_ligacao(self):
        """Abre o canal de comunicação em background."""
        self.link.iniciar()

    def fechar_ligacao(self):
        """Encerra a porta série com segurança."""
        self.link.parar()

    # ==========================================
    # FLUXO DE EMISSÃO INTEGRADO
    # ==========================================
    def enviar_ficheiro(self, payload: bytes, tipo: int) -> bool:
        """
        Função principal para a Camada 7 chamar. 
        Valida, encapsula, envia e gere retransmissões.
        """
        # 1. Validação da API (Tarefa 1 - Bernardo)
        tamanho = len(payload)
        if not (MIN_PAYLOAD_SIZE <= tamanho <= MAX_PAYLOAD_SIZE):
            print(f"[Erro API] Tamanho inválido: {tamanho} bytes.")
            return False

        # Prepara a função de injeção no canal para o Gestor de Timeout usar
        def rotina_injetar_canal(dados):
            seq = self.arq.obter_seq_num_atual()
            
            # --- MAGIA FEC (HARQ) ---
            payload_protegido = codificar_hamming(dados)
            
            # Encapsulamento (Tarefa 2 - Nuno) agora usa o payload_protegido!
            trama_base = encapsular_trama(payload_protegido, 0x02, 0x01, tipo, seq, b'')
            
            # Continua tudo igual...
            fcs = calcular_crc8(trama_base)
            trama_completa = trama_base + fcs
            pacote_fisico = SOF + byte_stuffing(trama_completa) + SOF
            self.link.enviar_trama_fisica(pacote_fisico)

        # Entrega o processo à tua Tarefa 3 para forçar o Stop-and-Wait
        sucesso = self.gestor_timeout.enviar_com_garantia(
            payload, 
            rotina_enviar=rotina_injetar_canal, 
            rotina_escutar_ack=self._escutar_canal_arq
        )
        return sucesso

    # ==========================================
    # FLUXO DE RECEÇÃO INTEGRADO
    # ==========================================
    def _escutar_canal_arq(self):
        """
        Lê a fila de tramas recebidas, remove o stuffing, valida o CRC, 
        avalia a máquina de estados e processa ACKs ou Dados.
        """
        if self.link.tramas_recebidas:
            trama_bruta = self.link.tramas_recebidas.pop(0)
            
            # Destuffing (Tarefa 1 - Luís)
            trama_limpa = byte_destuffing(trama_bruta)
            
            if len(trama_limpa) < 6:
                return None
                
            fcs_recebido = trama_limpa[-1:]
            dados = trama_limpa[:-1]

            crc_valido = verificar_crc8(dados, fcs_recebido)
            
            if not crc_valido:
                cabecalho = dados[:5]
                payload_corrompido = dados[5:]
                
                # Tenta curar o payload
                payload_limpo, erros = decodificar_hamming(payload_corrompido)
                
                # Volta a codificar para ver se a matemática do CRC bate certo
                payload_recodificado = codificar_hamming(payload_limpo)
                dados_reconstruidos = cabecalho + payload_recodificado
                
                if verificar_crc8(dados_reconstruidos, fcs_recebido):
                    gerar_log("FEC/HARQ", f"MAGIA! O FEC corrigiu {erros} erro(s) de bit no canal!", "SUCESSO")
                    dados = dados_reconstruidos
                    crc_valido = True
                else:
                    return "NACK" # Erro gigante, o Hamming não aguentou. Pede NACK.
            
            # Validação CRC (Tarefa 3 - Pedro)
            if not verificar_crc8(dados, fcs_recebido):
                return "NACK"
                
            tipo = trama_limpa[2]
            seq = trama_limpa[3]
            
            # --- É UMA TRAMA DE CONTROLO (ACK)? ---
            if tipo == 0x0A:
                if self.arq.processar_ack_recebido(seq):
                    return "ACK"
                return None

            elif tipo in [TYPE_TEXT, TYPE_IMAGE, TYPE_EOF]: # <--- Adicionado TYPE_EOF
                acao = self.arq.avaliar_trama_recebida(seq)
                
                ack_header = self.arq.gerar_trama_ack(seq)
                ack_fcs = calcular_crc8(ack_header)
                ack_pacote = SOF + byte_stuffing(ack_header + ack_fcs) + SOF
                
                if acao == "ACEITAR_E_ENVIAR_ACK":

                    self.ultimo_tempo_rececao = time.time()
                    
                    if tipo == TYPE_EOF:
                        # 1. Extrair a extensão que vem no payload do EOF!
                        length = trama_limpa[4]
                        len_real = 256 if length == 0 else length
                        payload_protegido = trama_limpa[5:5+len_real]
                        
                        payload_extensao, _ = decodificar_hamming(payload_protegido)
                        
                        # Converte os bytes para texto (ex: ".txt" ou ".png") e remove espaços
                        extensao = payload_extensao.decode('utf-8', errors='ignore').strip()
                        
                        # Prevenção de segurança para garantir que é uma extensão válida
                        if not extensao.startswith('.'):
                            extensao = ".bin"

                        # 2. Juntar os dados do ficheiro
                        dados_finais = bytes(self.buffer_rececao)
                        tamanho = len(dados_finais)
                        
                        # 3. Gerar o nome com a extensão original aplicada!
                        nome_guardar = f"ficheiro_recebido_{int(time.time())}{extensao}"
                        
                        if tamanho > 0:
                            with open(nome_guardar, 'wb') as f:
                                f.write(dados_finais)
                            gerar_log("SISTEMA", f"EOF DETETADO! Ficheiro de {tamanho} bytes guardado como '{nome_guardar}'!", "SUCESSO")
                            
                        # Limpa o balde e reinicia a máquina de estados
                        self.buffer_rececao.clear() 
                        self.arq.seq_num_esperado = 0 
                        gerar_log("SISTEMA", "Máquina de estados reiniciada. Pronto para novo ficheiro!", "INFO")

                    # ---> LÓGICA NORMAL DE RECEBER DADOS <---
                    else:
                        length = trama_limpa[4]
                        len_real = 256 if length == 0 else length
                        payload_protegido = trama_limpa[5:5+len_real]
                        
                        payload_final, _ = decodificar_hamming(payload_protegido)
                        self.buffer_rececao.extend(payload_final)
                    
                    self.link.enviar_trama_fisica(ack_pacote)
                    return None
                    
        return None