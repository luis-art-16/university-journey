class MaquinaEstadosARQ:
    def __init__(self):
        """
        Tarefa 3 (Nuno): Inicializa a máquina de estados do protocolo Stop-and-Wait.
        Controla os números de sequência (0 e 1) tanto para o emissor como para o recetor.
        """
        self.seq_num_enviar = 0    # O número de sequência que vamos colocar na próxima trama a enviar
        self.seq_num_esperado = 0  # O número de sequência que esperamos receber do outro lado

    # ==========================================
    # LÓGICA DO EMISSOR
    # ==========================================
    def obter_seq_num_atual(self) -> int:
        """Retorna o número de sequência (0 ou 1) para anexar ao cabeçalho da trama atual."""
        return self.seq_num_enviar

    def processar_ack_recebido(self, seq_num_ack: int) -> bool:
        """
        Avalia se o ACK recebido corresponde à trama que acabámos de enviar.
        Se sim, avança a máquina de estados (alterna o bit 0 <-> 1).
        """
        if seq_num_ack == self.seq_num_enviar:
            # Sucesso! O recetor confirmou a nossa trama. Preparamos o próximo bit.
            self.seq_num_enviar = 1 - self.seq_num_enviar  # Alterna: 1 - 0 = 1; 1 - 1 = 0
            return True
        else:
            # Recebemos um ACK antigo/atrasado. Ignorar.
            return False

    # ==========================================
    # LÓGICA DO RECETOR
    # ==========================================
    def avaliar_trama_recebida(self, seq_num_recebido: int) -> str:
        """
        Verifica o Sequence Number da trama de dados que acabou de chegar.
        Retorna uma ação para o sistema principal executar.
        """
        if seq_num_recebido == self.seq_num_esperado:
            # Trama nova e legítima!
            # Avançamos o nosso estado para esperar a próxima
            self.seq_num_esperado = 1 - self.seq_num_esperado
            return "ACEITAR_E_ENVIAR_ACK"
        else:
            # Trama duplicada! O emissor não deve ter recebido o nosso ACK anterior.
            # Temos de enviar o ACK novamente, mas NÃO DEVEMOS passar o payload à Camada 7.
            return "DESCARTAR_DUPLICADO_MAS_ENVIAR_ACK"

    def gerar_trama_ack(self, seq_num_para_confirmar: int) -> bytes:
        """
        Gera a estrutura base de uma trama de controlo (ACK).
        Atenção: O FCS e o Stuffing devem ser aplicados depois, pelas outras tarefas.
        """
        # Tipo 0x0A (ACK) definido no vosso relatório
        TIPO_ACK = b'\x0A' 
        # Estrutura: MAC_D(1) + MAC_S(1) + TIPO(1) + SEQ(1) + LENGTH(1)
        # O Length é 0 porque é uma trama de controlo sem payload
        cabecalho_ack = b'\x01' + b'\x02' + TIPO_ACK + bytes([seq_num_para_confirmar]) + b'\x00'
        return cabecalho_ack


# ==========================================
# Módulo de Teste (Para provares que evita os duplicados)
# ==========================================
if __name__ == "__main__":
    arq = MaquinaEstadosARQ()

    print("="*60)
    print("TESTE 1: Fluxo Normal (Sincronizado)")
    print(f"[Emissor] A enviar trama com Seq = {arq.obter_seq_num_atual()}")
    
    # O recetor recebe a trama 0
    acao = arq.avaliar_trama_recebida(0)
    print(f"[Recetor] Recebi trama 0. Ação: {acao}")
    
    # O emissor processa o ACK 0
    sucesso = arq.processar_ack_recebido(0)
    print(f"[Emissor] Recebi ACK 0. Válido? {sucesso}. Próximo a enviar: {arq.obter_seq_num_atual()}")

    print("\n" + "="*60)
    print("TESTE 2: O Problema do Pacote Duplicado (O ACK perdeu-se!)")
    # O Emissor vai enviar a Trama 1 (porque o estado dele avançou)
    print(f"[Emissor] A enviar trama com Seq = {arq.obter_seq_num_atual()}")
    
    # O Recetor recebe a trama 1 (Correto!)
    acao = arq.avaliar_trama_recebida(1)
    print(f"[Recetor] Recebi trama 1. Ação: {acao}")
    
    # AQUI ESTÁ O ERRO NO CANAL: O ACK perdeu-se! O emissor dá timeout e retransmite a Trama 1.
    print("[Canal] Oops, o ACK perdeu-se. O emissor vai retransmitir a mesma trama.")
    print(f"[Emissor] Retransmitindo trama com Seq = {arq.obter_seq_num_atual()}")
    
    # O Recetor recebe a trama 1 OUTRA VEZ! Vamos ver a máquina de estados a salvar o dia:
    acao_duplicado = arq.avaliar_trama_recebida(1)
    print(f"[Recetor] Recebi trama 1 (DE NOVO). Ação: {acao_duplicado}")
    if acao_duplicado == "DESCARTAR_DUPLICADO_MAS_ENVIAR_ACK":
         print("          -> [SUCESSO] A inteligência do Nuno impediu o processamento do pacote duplicado!")
    print("="*60)