import serial
import time
import threading

def recetor_continuo(porta='/dev/ttyUSB0', baudrate=9600):
    """
    Tarefa 2 (Bernardo): Lê as tramas de forma contínua no recetor.
    Aguarda pelo SOF, lê o cabeçalho, usa o campo Length para extrair o payload,
    lê a cauda (FCS) e imprime no terminal.
    """
    SOF = b'\x7E'
    
    try:
        conexao = serial.Serial(porta, baudrate, timeout=0.1)
        print(f"[*] Recetor a escutar continuamente na porta {porta} a {baudrate} bps...\n")
        
        while True:
            # 1. Aguarda pelo SOF (lê 1 byte de cada vez para não perder sincronização)
            byte_lido = conexao.read(1)
            
            if byte_lido == SOF:
                print("[!] SOF detetado. A processar nova trama...")
                
                # 2. Lê os 5 bytes do cabeçalho (MAC Dest, MAC Orig, Tipo, Seq, Length)
                cabecalho = conexao.read(5)
                
                if len(cabecalho) == 5:
                    mac_dest, mac_orig, tipo, seq_num, length = cabecalho
                    print(f"    -> Cabeçalho lido. Tamanho do payload: {length} bytes")
                    
                    # 3. Lê exatamente a quantidade de bytes indicada no Length
                    payload = conexao.read(length)
                    
                    if len(payload) == length:
                        # 4. Lê a cauda (FCS - 1 byte)
                        fcs = conexao.read(1)
                        
                        # 5. Extrai o payload e imprime no terminal
                        print("    -> Trama recebida com sucesso!")
                        print(f"    -> PAYLOAD EXTRAÍDO: {payload.decode('utf-8', errors='ignore')}")
                        print("-" * 50)
                    else:
                        print("    -> Erro: Timeout a ler o payload.")
                else:
                    print("    -> Erro: Cabeçalho incompleto.")
                    
    except serial.SerialException as e:
        print(f"Erro na porta série: {e}")
    except KeyboardInterrupt:
        print("\n[*] Leitura interrompida.")
    finally:
        if 'conexao' in locals() and conexao.is_open:
            conexao.close()

# ==========================================
# Módulo de Teste (Para provares que funciona)
# ==========================================
def simular_emissor(porta):
    """Injeta uma trama válida misturada com lixo para testar a tua máquina de estados."""
    time.sleep(2) # Dá tempo para o recetor arrancar
    try:
        conexao_emissor = serial.Serial(porta, 9600)
        
        # Constrói uma trama perfeitamente válida
        payload_teste = b"Ola Grupo 3! A minha Tarefa 2 funciona as mil maravilhas."
        tamanho = bytes([len(payload_teste)])
        trama_valida = b'\x7E' + b'\x02\x01\x01\x00' + tamanho + payload_teste + b'\xFF'
        
        # Injeta lixo antes e depois para provar que o teu código ignora ruído
        dados_sujos = b"lixo_inicial" + trama_valida + b"lixo_final"
        
        conexao_emissor.write(dados_sujos)
        conexao_emissor.close()
    except Exception:
        pass

if __name__ == "__main__":
    PORTA_TESTE = '/dev/ttyUSB0' # Ajusta para o teu ambiente Arch Linux
    
    # Inicia o emissor simulado numa thread separada (apenas para teste)
    threading.Thread(target=simular_emissor, args=(PORTA_TESTE,), daemon=True).start()
    
    # Arranca o teu ciclo de leitura contínua
    recetor_continuo(PORTA_TESTE)